import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertProjectSchema, insertChapterSchema, insertCharacterSchema, 
  insertLocationSchema, insertChatMessageSchema, insertReferenceSchema,
  insertVisualSchema
} from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import { processStoryFile } from "./file-processor";
import fs from "fs";
import path from "path";
import express from "express";

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure multer for file uploads
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
    fileFilter: (req, file, cb) => {
      const allowedTypes = ['.txt', '.md', '.docx'];
      const fileExt = file.originalname.toLowerCase().slice(file.originalname.lastIndexOf('.'));
      cb(null, allowedTypes.includes(fileExt));
    }
  });

  // OpenRouter AI integration
  async function callOpenRouter(messages: any[], model: string = "openai/gpt-3.5-turbo") {
    const apiKey = process.env.OPENROUTER_API_KEY || process.env.VITE_OPENROUTER_API_KEY || "sk-or-v1-placeholder";
    
    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json",
          "X-Title": "NovelForge",
        },
        body: JSON.stringify({
          model,
          messages,
          max_tokens: 1000,
          temperature: 0.7,
        }),
      });

      if (!response.ok) {
        throw new Error(`OpenRouter API error: ${response.status}`);
      }

      const data = await response.json();
      return data.choices[0]?.message?.content || "I apologize, but I couldn't generate a response at this time.";
    } catch (error) {
      console.error("OpenRouter API error:", error);
      return "I'm currently unable to connect to the AI service. Please try again later.";
    }
  }

  // Hugging Face integration for text analysis
  async function analyzeTextWithHuggingFace(text: string) {
    const apiKey = process.env.HUGGINGFACE_API_KEY || process.env.VITE_HUGGINGFACE_API_KEY || "hf_placeholder";
    
    try {
      const response = await fetch("https://api-inference.huggingface.co/models/cardiffnlp/twitter-roberta-base-sentiment-latest", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ inputs: text }),
      });

      if (!response.ok) {
        throw new Error(`Hugging Face API error: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error("Hugging Face API error:", error);
      return null;
    }
  }

  // Projects
  app.get("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const project = await storage.getProject(id);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const validatedProject = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(validatedProject);
      res.json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid project data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  app.patch("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = insertProjectSchema.partial().parse(req.body);
      const project = await storage.updateProject(id, updates);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid update data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update project" });
    }
  });

  // Chapters
  app.get("/api/projects/:projectId/chapters", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const chapters = await storage.getChaptersByProject(projectId);
      res.json(chapters);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chapters" });
    }
  });

  app.get("/api/chapters/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const chapter = await storage.getChapter(id);
      
      if (!chapter) {
        return res.status(404).json({ message: "Chapter not found" });
      }
      
      res.json(chapter);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chapter" });
    }
  });

  app.post("/api/chapters", async (req, res) => {
    try {
      const validatedChapter = insertChapterSchema.parse(req.body);
      const chapter = await storage.createChapter(validatedChapter);
      res.json(chapter);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid chapter data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create chapter" });
    }
  });

  app.patch("/api/chapters/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = insertChapterSchema.partial().parse(req.body);
      const chapter = await storage.updateChapter(id, updates);
      
      if (!chapter) {
        return res.status(404).json({ message: "Chapter not found" });
      }
      
      res.json(chapter);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid update data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update chapter" });
    }
  });

  app.delete("/api/chapters/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteChapter(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Chapter not found" });
      }
      
      res.json({ message: "Chapter deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete chapter" });
    }
  });

  // Characters
  app.get("/api/projects/:projectId/characters", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const characters = await storage.getCharactersByProject(projectId);
      res.json(characters);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch characters" });
    }
  });

  app.post("/api/characters", async (req, res) => {
    try {
      const validatedCharacter = insertCharacterSchema.parse(req.body);
      const character = await storage.createCharacter(validatedCharacter);
      res.json(character);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid character data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create character" });
    }
  });

  app.patch("/api/characters/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = insertCharacterSchema.partial().parse(req.body);
      const character = await storage.updateCharacter(id, updates);
      
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }
      
      res.json(character);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid update data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update character" });
    }
  });

  app.delete("/api/characters/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteCharacter(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Character not found" });
      }
      
      res.json({ message: "Character deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete character" });
    }
  });

  // Locations
  app.get("/api/projects/:projectId/locations", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const locations = await storage.getLocationsByProject(projectId);
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch locations" });
    }
  });

  app.post("/api/locations", async (req, res) => {
    try {
      const validatedLocation = insertLocationSchema.parse(req.body);
      const location = await storage.createLocation(validatedLocation);
      res.json(location);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid location data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create location" });
    }
  });

  app.patch("/api/locations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = insertLocationSchema.partial().parse(req.body);
      const location = await storage.updateLocation(id, updates);
      
      if (!location) {
        return res.status(404).json({ message: "Location not found" });
      }
      
      res.json(location);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid update data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update location" });
    }
  });

  app.delete("/api/locations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteLocation(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Location not found" });
      }
      
      res.json({ message: "Location deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete location" });
    }
  });

  // Chat Messages & AI
  app.get("/api/projects/:projectId/chat", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const messages = await storage.getChatMessagesByProject(projectId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const { projectId, content, model = "openai/gpt-3.5-turbo", context = {} } = req.body;
      
      // Save user message
      const userMessage = await storage.createChatMessage({
        projectId,
        role: "user",
        content,
        context,
      });

      // Get recent chat history for context
      const recentMessages = await storage.getChatMessagesByProject(projectId);
      const chatHistory = recentMessages.slice(-10).map(msg => ({
        role: msg.role,
        content: msg.content,
      }));

      // Add system prompt for writing assistance
      const systemPrompt = {
        role: "system",
        content: "You are an expert writing assistant specializing in creative fiction. Help with story development, character creation, world-building, and writing improvement. Provide specific, actionable suggestions that enhance narrative quality."
      };

      // Call OpenRouter API
      const aiResponse = await callOpenRouter([systemPrompt, ...chatHistory], model);

      // Save AI response
      const assistantMessage = await storage.createChatMessage({
        projectId,
        role: "assistant",
        content: aiResponse,
        context,
        modelUsed: model,
      });

      res.json({
        userMessage,
        assistantMessage,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid chat data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to process chat message" });
    }
  });

  app.delete("/api/projects/:projectId/chat", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      await storage.clearChatHistory(projectId);
      res.json({ message: "Chat history cleared successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to clear chat history" });
    }
  });

  // Visuals
  app.get("/api/projects/:projectId/visuals", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const visuals = await storage.getVisualsByProject(projectId);
      res.json(visuals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch visuals" });
    }
  });

  app.post("/api/visuals", async (req, res) => {
    try {
      const validatedVisual = insertVisualSchema.parse(req.body);
      const visual = await storage.createVisual(validatedVisual);
      res.json(visual);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid visual data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create visual" });
    }
  });

  app.patch("/api/visuals/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = insertVisualSchema.partial().parse(req.body);
      const visual = await storage.updateVisual(id, updates);
      
      if (!visual) {
        return res.status(404).json({ message: "Visual not found" });
      }
      
      res.json(visual);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid update data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update visual" });
    }
  });

  app.delete("/api/visuals/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteVisual(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Visual not found" });
      }
      
      res.json({ message: "Visual deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete visual" });
    }
  });

  // Enhanced extraction functions for outline documents
  function extractCharactersFromOutline(content: string, fileName: string): any[] {
    const characters: any[] = [];
    const lines = content.split('\n');
    const seenNames = new Set<string>();

    // More aggressive patterns for finding any potential character names
    const allPatterns = [
      // Direct character labels
      /(?:Character|Name|Protagonist|Antagonist|Main|Supporting|Cast|Person|People):\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/gi,
      // Character with description
      /^([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s*[-–—:]\s*(.+)/gm,
      // Character in parentheses or brackets
      /^([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s*[\(\[](.+?)[\)\]]/gm,
      // Bullet points
      /^[•\-\*]\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/gm,
      // Numbered lists
      /^\d+\.\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/gm,
      // Known surnames from Wrecked story
      /\b([A-Z][a-z]+)\s+(Carter|Reeves|Thompson|Martinez|Williams|Davis|Johnson|Brown|Miller|Wilson|Moore|Taylor|Anderson|Thomas|Jackson|White|Harris|Martin|Garcia|Robinson|Clark|Rodriguez|Lewis|Lee|Walker|Hall|Allen|Young|Hernandez|King|Wright|Lopez|Hill|Scott|Green|Adams|Baker|Gonzalez|Nelson|Mitchell|Perez|Roberts|Turner|Phillips|Campbell|Parker|Evans|Edwards|Collins|Stewart|Sanchez|Morris|Rogers|Reed|Cook|Morgan|Bell|Murphy|Bailey|Rivera|Cooper|Richardson|Cox|Howard|Ward|Torres|Peterson|Gray|Ramirez|James|Watson|Brooks|Kelly|Sanders|Price|Bennett|Wood|Barnes|Ross|Henderson|Coleman|Jenkins|Perry|Powell|Long|Patterson|Hughes|Flores|Washington|Butler|Simmons|Foster|Gonzales|Bryant|Alexander|Russell|Griffin|Diaz|Hayes)/i,
      // First and last name patterns (any capitalized words that could be names)
      /\b([A-Z][a-z]{2,})\s+([A-Z][a-z]{2,})\b/g,
      // Single names that appear multiple times (likely characters)
      /\b([A-Z][a-z]{3,})\b/g
    ];

    // First pass: Look for obvious character sections
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line.length < 2) continue;

      // Character section headers
      if (line.match(/^(Character|Cast|People|Main|Supporting|Protagonist|Antagonist|Person)/i)) {
        for (let j = i + 1; j < Math.min(lines.length, i + 30); j++) {
          const charLine = lines[j].trim();
          if (charLine.length < 2) continue;
          if (charLine.match(/^(Chapter|Scene|Location|Plot|Theme|Setting|Act|Part)/i)) break;

          // Extract character names, cleaning up "Chapter" suffixes
          const nameMatches = charLine.match(/([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/g);
          if (nameMatches) {
            nameMatches.forEach(rawName => {
              // Clean up names that have "Chapter" attached
              let name = rawName.replace(/\s+Chapter$/i, '').trim();
              
              if (name.length > 2 && !seenNames.has(name.toLowerCase()) && 
                  !name.match(/^(The|A|An|This|That|When|Where|Chapter|Scene|Plot|Setting|Location|Theme|Story|Book|Part|Act|Section|Number|Title)$/i)) {
                seenNames.add(name.toLowerCase());
                
                let description = charLine.replace(rawName, '').replace(/^[\s\-–—:]+/, '').trim();
                let age = null;
                
                const ageMatch = description.match(/(?:age|aged|years?\s+old)[\s:]*(\d+)/i);
                if (ageMatch) {
                  age = ageMatch[1];
                  description = description.replace(ageMatch[0], '').trim();
                }

                characters.push({
                  name,
                  description: description || 'Character from story outline',
                  age,
                  notes: `Extracted from ${fileName} - CANON source`
                });
              }
            });
          }
        }
      }
    }

    // Removed broad extraction patterns that create noise
    // Only keeping explicit character sections and core character detection

    // Focus only on your core characters and explicit mentions
    const coreCharacters = [
      { name: 'Lilah', fullName: 'Lilah Carter', description: 'Main protagonist' },
      { name: 'Lucas', fullName: 'Lucas Reeves', description: 'Main male lead' },
      { name: 'Mara', fullName: 'Mara', description: 'Supporting character' }
    ];
    
    coreCharacters.forEach(char => {
      if (!seenNames.has(char.name.toLowerCase()) && 
          (content.toLowerCase().includes(char.name.toLowerCase()) || 
           content.toLowerCase().includes(char.fullName.toLowerCase()))) {
        seenNames.add(char.name.toLowerCase());
        characters.push({
          name: char.name,
          description: char.description,
          age: null,
          notes: `CORE CHARACTER - Extracted from ${fileName}`
        });
      }
    });

    // Only extract high-confidence explicit character mentions to avoid noise
    // Remove the broad word scanning that creates too much irrelevant content

    console.log(`Character extraction found ${characters.length} potential characters`);
    return characters.slice(0, 30); // Limit but allow more characters
  }

  function extractLocationsFromOutline(content: string, fileName: string): any[] {
    const locations: any[] = [];
    const seenNames = new Set<string>();

    // Main story locations for "Wrecked"
    const canonLocations = [
      { keywords: ['cliff', 'cliffs'], name: 'The Cliffs', description: 'Main location overlooking the sea' },
      { keywords: ['bar', 'pub'], name: 'The Bar', description: 'Local gathering place' },
      { keywords: ['lilah', 'childhood', 'home'], name: "Lilah's Childhood Home", description: "Where Lilah grew up" },
      { keywords: ['lucas', 'garage', 'apartment'], name: "Lucas's Garage/Apartment", description: "Lucas's living and working space" },
      { keywords: ['mara', 'home', 'house'], name: "Mara's Home", description: "Mara's residence" },
      { keywords: ['unkept', 'hour'], name: 'The Unkept Hour', description: 'Significant story location' }
    ];

    const contentLower = content.toLowerCase();

    // Only extract canonical locations that are explicitly mentioned
    canonLocations.forEach(canonLoc => {
      // Look for very specific mentions of these exact locations
      const hasExactMention = canonLoc.keywords.some(keyword => {
        const regex = new RegExp(`\\b${keyword}\\b`, 'i');
        return regex.test(content);
      });
      
      if (hasExactMention && !seenNames.has(canonLoc.name.toLowerCase())) {
        seenNames.add(canonLoc.name.toLowerCase());
        locations.push({
          name: canonLoc.name,
          description: canonLoc.description,
          notes: `CANON LOCATION - Explicitly mentioned in ${fileName}`
        });
      }
    });

    // Remove broad location scanning that picks up irrelevant words

    return locations;
  }

  function extractChaptersFromOutline(content: string, fileName: string): any[] {
    const chapters: any[] = [];
    const lines = content.split('\n');

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line.length < 3) continue;

      const patterns = [
        /^(?:Chapter|Ch\.?)\s*(\d+):?\s*(.+)?/i,
        /^(?:Scene|Part|Section)\s*(\d+):?\s*(.+)?/i,
        /^(\d+)\.\s*(.+)/,
        /^([A-Z][A-Z\s]{5,})$/  // All caps titles
      ];

      patterns.forEach(pattern => {
        const match = pattern.exec(line);
        if (match && chapters.length < 15) {
          const title = match[2] ? `Chapter ${match[1]}: ${match[2]}` : match[2] || `Chapter ${match[1]}`;
          let content = '';

          // Collect content from following lines
          for (let j = i + 1; j < Math.min(lines.length, i + 10); j++) {
            const contentLine = lines[j].trim();
            if (contentLine.match(/^(?:Chapter|Scene|Part)/i)) break;
            if (contentLine.length > 5) {
              content += contentLine + '\n';
            }
          }

          chapters.push({
            title,
            content: content.trim(),
            notes: `Extracted from ${fileName}`
          });
        }
      });
    }

    return chapters;
  }

  // AI File Analysis for Database Review
  app.post("/api/ai/analyze-file", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const projectId = parseInt(req.body.projectId);
      const analysisOnly = req.body.analysisOnly === 'true';
      
      if (!projectId) {
        return res.status(400).json({ message: "Project ID is required" });
      }

      let fileContent = '';
      const fileName = req.file.originalname;

      // Handle different file types
      if (fileName.endsWith('.docx')) {
        // For .docx files, extract text content
        try {
          const mammoth = await import('mammoth');
          const result = await mammoth.extractRawText({ buffer: req.file.buffer });
          fileContent = result.value;
        } catch (error) {
          // Fallback to buffer conversion if mammoth fails
          fileContent = req.file.buffer.toString('utf-8');
        }
      } else {
        fileContent = req.file.buffer.toString('utf-8');
      }

      console.log(`Processing file: ${fileName}, content length: ${fileContent.length}`);

      // Use advanced extractor for comprehensive analysis
      const { AdvancedStoryExtractor } = await import('./advanced-extractor');
      const extractor = new AdvancedStoryExtractor(fileContent, fileName, projectId);
      const analysis = await extractor.extract();

      console.log(`Advanced extraction completed:`);
      console.log(`- Characters: ${analysis.characters.length}`);
      console.log(`- Locations: ${analysis.locations.length}`);
      console.log(`- Symbols: ${analysis.symbols.length}`);
      console.log(`- Motifs: ${analysis.motifs.length}`);
      console.log(`- Themes: ${analysis.themes.length}`);
      console.log(`- Emotional Patterns: ${analysis.emotionalPatterns.length}`);
      console.log(`- Lore: ${analysis.lore.length}`);

      // Get existing data for comparison
      const existingCharacters = await storage.getCharactersByProject(projectId);
      const existingLocations = await storage.getLocationsByProject(projectId);
      const existingChapters = await storage.getChaptersByProject(projectId);

      const suggestions: any[] = [];

      const isCanonSource = fileName.toLowerCase().includes('canon') || fileName.toLowerCase().includes('outline');

      // Process characters
      analysis.characters.forEach((newChar, index) => {
        const existing = existingCharacters.find(c => 
          c.name.toLowerCase() === newChar.name.toLowerCase()
        );

        if (existing) {
          suggestions.push({
            id: `file-char-update-${index}`,
            type: "character",
            action: "update",
            current: existing,
            suggested: {
              ...existing,
              description: newChar.description || existing.description,
              occupation: newChar.occupation || existing.occupation,
              notes: `${existing.notes || ''}\n\n${isCanonSource ? 'CANON UPDATE' : 'Updated'} from ${fileName}`
            },
            reasoning: isCanonSource ? 
              `CANON character update for ${newChar.name}` :
              `Enhanced character information for ${newChar.name}`,
            confidence: isCanonSource ? 0.95 : 0.85
          });
        } else {
          suggestions.push({
            id: `file-char-create-${index}`,
            type: "character", 
            action: "create",
            current: null,
            suggested: newChar,
            reasoning: isCanonSource ? 
              `CANON character "${newChar.name}" from authoritative source` :
              `New character "${newChar.name}" found in file`,
            confidence: isCanonSource ? 0.95 : 0.9
          });
        }
      });

      // Process locations
      analysis.locations.forEach((newLoc, index) => {
        const existing = existingLocations.find(l => 
          l.name.toLowerCase() === newLoc.name.toLowerCase()
        );

        if (!existing) {
          suggestions.push({
            id: `file-loc-create-${index}`,
            type: "location",
            action: "create", 
            current: null,
            suggested: newLoc,
            reasoning: isCanonSource ? 
              `CANON location "${newLoc.name}"` :
              `New location "${newLoc.name}" found in file`,
            confidence: isCanonSource ? 0.95 : 0.85
          });
        }
      });

      // Process symbols - these are new literary elements
      analysis.symbols.forEach((symbol, index) => {
        suggestions.push({
          id: `file-symbol-create-${index}`,
          type: "symbol",
          action: "create",
          current: null,
          suggested: symbol,
          reasoning: `Symbol "${symbol.name}" represents: ${symbol.meaning}`,
          confidence: 0.8
        });
      });

      // Process motifs
      analysis.motifs.forEach((motif, index) => {
        suggestions.push({
          id: `file-motif-create-${index}`,
          type: "motif", 
          action: "create",
          current: null,
          suggested: motif,
          reasoning: `Motif "${motif.name}" - ${motif.function}`,
          confidence: 0.8
        });
      });

      // Process themes
      analysis.themes.forEach((theme, index) => {
        suggestions.push({
          id: `file-theme-create-${index}`,
          type: "theme",
          action: "create", 
          current: null,
          suggested: theme,
          reasoning: `Theme "${theme.name}" - ${theme.description}`,
          confidence: 0.85
        });
      });

      // Process emotional patterns
      analysis.emotionalPatterns.forEach((pattern, index) => {
        suggestions.push({
          id: `file-pattern-create-${index}`,
          type: "emotional_pattern",
          action: "create",
          current: null, 
          suggested: pattern,
          reasoning: `Emotional pattern "${pattern.name}" - ${pattern.significance}`,
          confidence: 0.8
        });
      });

      // Process lore
      analysis.lore.forEach((lore, index) => {
        suggestions.push({
          id: `file-lore-create-${index}`,
          type: "lore",
          action: "create",
          current: null,
          suggested: lore,
          reasoning: `Background lore "${lore.name}" - ${lore.category}`,
          confidence: 0.75
        });
      });

      const result = {
        suggestions: suggestions.slice(0, 20), // Allow more suggestions for comprehensive analysis
        extractedData: {
          characters: analysis.characters,
          locations: analysis.locations,
          chapters: analysis.chapters,
          symbols: analysis.symbols,
          motifs: analysis.motifs,
          themes: analysis.themes,
          emotionalPatterns: analysis.emotionalPatterns,
          lore: analysis.lore
        },
        analysis: {
          fileName,
          fileSize: req.file.size,
          charactersFound: analysis.characters.length,
          locationsFound: analysis.locations.length,
          chaptersFound: analysis.chapters.length,
          symbolsFound: analysis.symbols.length,
          motifsFound: analysis.motifs.length,
          themesFound: analysis.themes.length,
          emotionalPatternsFound: analysis.emotionalPatterns.length,
          loreFound: analysis.lore.length,
          conflictsDetected: suggestions.filter(s => s.action === "update").length,
          newItemsFound: suggestions.filter(s => s.action === "create").length
        }
      };

      res.json(result);
    } catch (error) {
      console.error('File analysis error:', error);
      res.status(500).json({ message: "Failed to analyze file" });
    }
  });



  // AI Database Analysis
  app.post("/api/ai/analyze-database", async (req, res) => {
    try {
      const { projectId, characters, locations, chapters, customPrompt } = req.body;
      
      const suggestions = [];
      
      // Analyze characters for inconsistencies
      for (const character of characters) {
        if (!character.description || character.description.length < 20) {
          suggestions.push({
            id: `char-desc-${character.id}`,
            type: "character",
            action: "update",
            current: character,
            suggested: {
              ...character,
              description: `${character.name} is a complex character in the "Wrecked" story. Their role and personality need further development to enhance the narrative depth.`
            },
            reasoning: "Character needs a more detailed description to improve story consistency",
            confidence: 0.8
          });
        }
        
        // Check for duplicate or similar characters
        const similarChars = characters.filter(c => 
          c.id !== character.id && 
          c.name.toLowerCase().includes(character.name.toLowerCase().substring(0, 3))
        );
        
        if (similarChars.length > 0) {
          suggestions.push({
            id: `char-merge-${character.id}`,
            type: "character",
            action: "merge",
            current: character,
            suggested: {
              ...character,
              description: `${character.description || ''} (Merged traits from similar characters for consistency)`
            },
            reasoning: `Potential duplicate or similar character found: ${similarChars.map(c => c.name).join(', ')}`,
            confidence: 0.6
          });
        }
      }
      
      // Analyze locations
      for (const location of locations) {
        if (!location.description || location.description.length < 20) {
          suggestions.push({
            id: `loc-desc-${location.id}`,
            type: "location",
            action: "update",
            current: location,
            suggested: {
              ...location,
              description: `${location.name} is a significant location in the "Wrecked" story, serving as a backdrop for important character interactions and plot developments.`
            },
            reasoning: "Location needs more descriptive detail for better world-building",
            confidence: 0.7
          });
        }
      }
      
      // Custom prompt analysis
      if (customPrompt) {
        if (customPrompt.toLowerCase().includes('age')) {
          // Age consistency suggestions
          const ageIssues = characters.filter(c => !c.age || c.age === 'Unknown');
          for (const char of ageIssues) {
            suggestions.push({
              id: `age-fix-${char.id}`,
              type: "character",
              action: "update",
              current: char,
              suggested: {
                ...char,
                age: char.name === "Lilah Carter" ? "24" : 
                     char.name === "Lucas Reeves" ? "25" : 
                     char.name === "Mara Thompson" ? "23" : "Unknown"
              },
              reasoning: "Added consistent age based on story timeline and character relationships",
              confidence: 0.9
            });
          }
        }
        
        if (customPrompt.toLowerCase().includes('duplicate')) {
          // Find potential duplicates
          const nameGroups = {};
          characters.forEach(char => {
            const key = char.name.toLowerCase().substring(0, 5);
            if (!nameGroups[key]) nameGroups[key] = [];
            nameGroups[key].push(char);
          });
          
          Object.values(nameGroups).forEach((group: any) => {
            if (group.length > 1) {
              suggestions.push({
                id: `dup-merge-${group[0].id}`,
                type: "character",
                action: "merge",
                current: group[0],
                suggested: {
                  ...group[0],
                  description: group.map(c => c.description).filter(Boolean).join(' ')
                },
                reasoning: `Potential duplicates found: ${group.map(c => c.name).join(', ')}`,
                confidence: 0.7
              });
            }
          });
        }
      }
      
      res.json({ suggestions: suggestions.slice(0, 10) }); // Limit suggestions
    } catch (error) {
      console.error('Database analysis error:', error);
      res.status(500).json({ message: "Failed to analyze database" });
    }
  });

  // File Upload and Processing
  app.post("/api/upload/story-content", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const projectId = parseInt(req.body.projectId);
      if (!projectId) {
        return res.status(400).json({ message: "Project ID is required" });
      }

      const fileContent = req.file.buffer.toString('utf-8');
      const fileName = req.file.originalname;

      const result = await processStoryFile(fileContent, fileName, projectId);

      res.json(result);
    } catch (error) {
      console.error('File processing error:', error);
      res.status(500).json({ message: "Failed to process file" });
    }
  });

  // File upload endpoint for images and videos
  app.post("/api/upload", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      // Validate file type
      const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'video/mp4', 'video/webm', 'video/mov'];
      if (!validTypes.includes(req.file.mimetype)) {
        return res.status(400).json({ message: "Invalid file type" });
      }

      // Create uploads directory if it doesn't exist
      const uploadDir = './uploads';
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }

      // Generate unique filename
      const timestamp = Date.now();
      const originalName = req.file.originalname;
      const extension = originalName.substring(originalName.lastIndexOf('.'));
      const filename = `${timestamp}-${Math.random().toString(36).substring(2)}${extension}`;
      const filepath = path.join(uploadDir, filename);

      // Save file
      fs.writeFileSync(filepath, req.file.buffer);

      // Return file URL
      const fileUrl = `/uploads/${filename}`;
      res.json({ url: fileUrl });
    } catch (error) {
      console.error('File upload error:', error);
      res.status(500).json({ message: "Failed to upload file" });
    }
  });

  // Serve uploaded files
  app.use('/uploads', express.static('./uploads'));

  // API routes for new literary elements
  app.get("/api/projects/:id/symbols", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const symbols = await storage.getSymbolsByProject(projectId);
      res.json(symbols);
    } catch (error) {
      res.status(500).json({ message: "Failed to get symbols" });
    }
  });

  app.get("/api/projects/:id/motifs", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const motifs = await storage.getMotifsByProject(projectId);
      res.json(motifs);
    } catch (error) {
      res.status(500).json({ message: "Failed to get motifs" });
    }
  });

  app.get("/api/projects/:id/themes", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const themes = await storage.getThemesByProject(projectId);
      res.json(themes);
    } catch (error) {
      res.status(500).json({ message: "Failed to get themes" });
    }
  });

  app.get("/api/projects/:id/emotional-patterns", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const patterns = await storage.getEmotionalPatternsByProject(projectId);
      res.json(patterns);
    } catch (error) {
      res.status(500).json({ message: "Failed to get emotional patterns" });
    }
  });

  app.get("/api/projects/:id/lore", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const lore = await storage.getLoreByProject(projectId);
      res.json(lore);
    } catch (error) {
      res.status(500).json({ message: "Failed to get lore" });
    }
  });

  // Collaboration endpoints
  app.get("/api/collaboration/:chapterId/session", async (req, res) => {
    try {
      const chapterId = parseInt(req.params.chapterId);
      // In a real implementation, you'd get this from the collaboration manager
      res.json({
        users: [],
        lockOwner: null,
        isLocked: false,
        currentVersion: "main"
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get session info" });
    }
  });

  app.get("/api/collaboration/:chapterId/versions", async (req, res) => {
    try {
      const chapterId = parseInt(req.params.chapterId);
      const branchName = req.query.branch as string || "main";
      // In a real implementation, you'd get this from the collaboration manager
      res.json([]);
    } catch (error) {
      res.status(500).json({ message: "Failed to get version history" });
    }
  });

  app.get("/api/collaboration/:chapterId/branches", async (req, res) => {
    try {
      const chapterId = parseInt(req.params.chapterId);
      // In a real implementation, you'd get this from the collaboration manager
      res.json(["main"]);
    } catch (error) {
      res.status(500).json({ message: "Failed to get branches" });
    }
  });

  // AI Writing Assistance
  app.post("/api/ai/suggestions", async (req, res) => {
    try {
      const { text, context, model = "openai/gpt-3.5-turbo" } = req.body;
      
      const prompt = {
        role: "system",
        content: "You are a writing assistant. Provide 3 brief, specific suggestions to improve the given text. Focus on narrative flow, character development, or sensory details. Keep each suggestion under 20 words."
      };

      const userPrompt = {
        role: "user",
        content: `Please suggest improvements for this text: "${text}"`
      };

      const suggestions = await callOpenRouter([prompt, userPrompt], model);
      
      res.json({ suggestions });
    } catch (error) {
      res.status(500).json({ message: "Failed to generate suggestions" });
    }
  });

  app.post("/api/ai/autocomplete", async (req, res) => {
    try {
      const { text, model = "openai/gpt-3.5-turbo" } = req.body;
      
      const prompt = {
        role: "system",
        content: "You are a creative writing assistant. Complete the given text with 1-2 sentences that naturally continue the narrative. Match the existing tone and style."
      };

      const userPrompt = {
        role: "user",
        content: `Please continue this text: "${text}"`
      };

      const completion = await callOpenRouter([prompt, userPrompt], model);
      
      res.json({ completion });
    } catch (error) {
      res.status(500).json({ message: "Failed to generate completion" });
    }
  });

  // Text Analysis
  app.post("/api/analyze/sentiment", async (req, res) => {
    try {
      const { text } = req.body;
      const analysis = await analyzeTextWithHuggingFace(text);
      res.json({ analysis });
    } catch (error) {
      res.status(500).json({ message: "Failed to analyze text sentiment" });
    }
  });

  // Export functionality
  app.get("/api/chapters/:id/export", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const chapter = await storage.getChapter(id);
      
      if (!chapter) {
        return res.status(404).json({ message: "Chapter not found" });
      }

      const exportData = {
        title: chapter.title,
        content: chapter.content,
        wordCount: chapter.wordCount,
        exportedAt: new Date(),
      };

      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="${chapter.title}.json"`);
      res.json(exportData);
    } catch (error) {
      res.status(500).json({ message: "Failed to export chapter" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
