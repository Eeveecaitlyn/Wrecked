import { storage } from "./storage";
import type { InsertCharacter, InsertLocation, InsertChapter } from "@shared/schema";

export interface ProcessedContent {
  charactersAdded: number;
  locationsAdded: number;
  chaptersAdded: number;
  extractedData: {
    characters: any[];
    locations: any[];
    chapters: any[];
  };
}

export async function processStoryFile(
  content: string,
  fileName: string,
  projectId: number
): Promise<ProcessedContent> {
  const result: ProcessedContent = {
    charactersAdded: 0,
    locationsAdded: 0,
    chaptersAdded: 0,
    extractedData: {
      characters: [],
      locations: [],
      chapters: []
    }
  };

  try {
    // Extract all story elements using enhanced patterns
    const extractedCharacters = extractCharactersEnhanced(content, fileName);
    const extractedLocations = extractLocationsEnhanced(content, fileName);
    const extractedChapters = extractChaptersEnhanced(content, fileName);

    result.extractedData = {
      characters: extractedCharacters,
      locations: extractedLocations,
      chapters: extractedChapters
    };

    // Add characters to database
    for (const charData of extractedCharacters) {
      try {
        const character: InsertCharacter = {
          projectId,
          name: charData.name,
          description: charData.description,
          age: charData.age,
          notes: `${charData.notes || ''}\nSource: ${fileName}`
        };

        await storage.createCharacter(character);
        result.charactersAdded++;
      } catch (error) {
        console.error(`Failed to create character ${charData.name}:`, error);
      }
    }

    // Add locations to database
    for (const locData of extractedLocations) {
      try {
        const location: InsertLocation = {
          projectId,
          name: locData.name,
          description: locData.description,
          notes: `${locData.notes || ''}\nSource: ${fileName}`
        };

        await storage.createLocation(location);
        result.locationsAdded++;
      } catch (error) {
        console.error(`Failed to create location ${locData.name}:`, error);
      }
    }

    // Add chapters to database
    for (const chapData of extractedChapters) {
      try {
        const chapter: InsertChapter = {
          projectId,
          title: chapData.title,
          content: chapData.content,
          notes: `${chapData.notes || ''}\nSource: ${fileName}`,
          orderIndex: result.chaptersAdded + 1
        };

        await storage.createChapter(chapter);
        result.chaptersAdded++;
      } catch (error) {
        console.error(`Failed to create chapter ${chapData.title}:`, error);
      }
    }

  } catch (error) {
    console.error('Error processing story file:', error);
  }

  return result;
}

function extractCharactersEnhanced(content: string, fileName: string): any[] {
  const characters = [];
  const lines = content.split('\n');
  const seenNames = new Set();

  // Enhanced patterns for character detection in outlines
  const characterPatterns = [
    // Direct character labels
    /(?:Character|Name|Protagonist|Antagonist|Main|Supporting|Cast):\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/gi,
    // Character with dash description
    /^([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s*[-–—]\s*(.+)/gm,
    // Character in parentheses or brackets
    /^([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s*[\(\[](.+?)[\)\]]/gm,
    // Bullet point characters
    /^[•\-\*]\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/gm,
    // Numbered characters
    /^\d+\.\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/gm,
    // Known surnames from Wrecked
    /\b([A-Z][a-z]+)\s+(Carter|Reeves|Thompson|Martinez|Williams|Davis|Johnson|Brown|Miller)/gi,
    // Character actions in narrative
    /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s+(?:said|says|thinks|feels|realizes|remembers|walks|runs|looks|is|was|has|had|will|would|could|should)/gi
  ];

  // Process each line
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (line.length < 2) continue;

    // Check for character section headers
    if (line.match(/^(Character|Cast|People|Main|Supporting|Protagonist)/i)) {
      // Extract characters from following lines
      for (let j = i + 1; j < Math.min(lines.length, i + 15); j++) {
        const charLine = lines[j].trim();
        if (charLine.length < 2) continue;
        if (charLine.match(/^(Chapter|Scene|Act|Plot|Location|Setting|Theme)/i)) break;

        const nameMatch = charLine.match(/^([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/);
        if (nameMatch) {
          const name = nameMatch[1];
          if (!seenNames.has(name.toLowerCase())) {
            seenNames.add(name.toLowerCase());
            
            let description = charLine.replace(nameMatch[1], '').replace(/^[\s\-–—:]+/, '').trim();
            let age = null;
            
            // Extract age
            const ageMatch = description.match(/(?:age|aged|years?\s+old)[\s:]*(\d+)/i);
            if (ageMatch) {
              age = ageMatch[1];
              description = description.replace(ageMatch[0], '').trim();
            }

            characters.push({
              name,
              description: description || 'Character from story outline',
              age,
              notes: `Extracted from ${fileName}`
            });
          }
        }
      }
      continue;
    }

    // Apply all patterns to current line
    characterPatterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(line)) !== null && characters.length < 20) {
        const name = match[1];
        const extraInfo = match[2] || '';

        // Skip obvious false positives
        if (name.match(/^(The|A|An|This|That|When|Where|Chapter|Act|Scene|Part|Plot|Story|Book|And|But|Or|So|Then|Now|Here|There|What|How|Why|Who|Are|Was|Were)$/i)) {
          continue;
        }

        if (!seenNames.has(name.toLowerCase())) {
          seenNames.add(name.toLowerCase());

          let description = extraInfo;
          let age = null;

          // Look for more context if description is short
          if (!description || description.length < 10) {
            for (let k = Math.max(0, i - 1); k <= Math.min(lines.length - 1, i + 2); k++) {
              if (k === i) continue;
              const contextLine = lines[k].trim();
              if (contextLine.length > 15 && contextLine.toLowerCase().includes(name.toLowerCase())) {
                description = contextLine;
                break;
              }
            }
          }

          // Extract age from description or context
          const ageMatch = (description || line).match(/(?:age|aged|years?\s+old)[\s:]*(\d+)/i);
          if (ageMatch) {
            age = ageMatch[1];
          }

          characters.push({
            name,
            description: description || 'Character from uploaded content',
            age,
            notes: `Extracted from ${fileName}`
          });
        }
      }
    });
  }

  return characters.slice(0, 20);
}

function extractLocationsEnhanced(content: string, fileName: string): any[] {
  const locations: any[] = [];
  const lines = content.split('\n');
  const seenNames = new Set();

  const locationPatterns = [
    // Direct location labels
    /(?:Location|Place|Setting|Scene):\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)/gi,
    // Location with description
    /^([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s*[-–—]\s*(.+location|.+place|.+building|.+room|.+house|.+school|.+office)/gi,
    // "At/In/On" constructions
    /(?:at|in|on)\s+(?:the\s+)?([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*(?:\s+(?:House|School|Hospital|Office|Building|Park|Store|Restaurant|Cafe|Library|Church|Theater|Mall|Center|Station)))/gi,
    // Common location types
    /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(House|School|Hospital|Office|Building|Park|Store|Restaurant|Cafe|Library|Church|Theater|Mall|Center|Station|Avenue|Street|Road|Drive|Lane)\b/gi,
    // Geographic locations
    /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(City|Town|Village|County|State|Beach|Mountain|Forest|Lake|River)\b/gi
  ];

  // Process each line
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (line.length < 3) continue;

    // Check for location section headers
    if (line.match(/^(Location|Place|Setting|Scene|Where)/i)) {
      for (let j = i + 1; j < Math.min(lines.length, i + 10); j++) {
        const locLine = lines[j].trim();
        if (locLine.length < 2) continue;
        if (locLine.match(/^(Chapter|Character|Plot|Theme)/i)) break;

        const nameMatch = locLine.match(/^([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)/);
        if (nameMatch) {
          const name = nameMatch[1];
          if (!seenNames.has(name.toLowerCase())) {
            seenNames.add(name.toLowerCase());
            
            let description = locLine.replace(nameMatch[1], '').replace(/^[\s\-–—:]+/, '').trim();
            
            locations.push({
              name,
              description: description || 'Location from story outline',
              notes: `Extracted from ${fileName}`
            });
          }
        }
      }
      continue;
    }

    // Apply location patterns
    locationPatterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(line)) !== null && locations.length < 15) {
        const name = match[1];
        if (!seenNames.has(name.toLowerCase())) {
          seenNames.add(name.toLowerCase());

          let description = match[2] || '';
          if (!description) {
            // Look for context
            for (let k = Math.max(0, i - 1); k <= Math.min(lines.length - 1, i + 2); k++) {
              if (k === i) continue;
              const contextLine = lines[k].trim();
              if (contextLine.length > 15 && contextLine.toLowerCase().includes(name.toLowerCase())) {
                description = contextLine;
                break;
              }
            }
          }

          locations.push({
            name,
            description: description || 'Location from uploaded content',
            notes: `Extracted from ${fileName}`
          });
        }
      }
    });
  }

  return locations.slice(0, 15);
}

function extractChaptersEnhanced(content: string, fileName: string): any[] {
  const chapters: any[] = [];
  const lines = content.split('\n');

  const chapterPatterns = [
    /^(?:Chapter|Ch\.?)\s*(\d+):?\s*(.+)?/i,
    /^(?:Scene|Part|Section)\s*(\d+):?\s*(.+)?/i,
    /^(\d+)\.\s*(.+)/,
    /^([A-Z][A-Z\s]+)$/  // All caps titles
  ];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (line.length < 3) continue;

    chapterPatterns.forEach(pattern => {
      const match = pattern.exec(line);
      if (match) {
        const title = match[2] ? `Chapter ${match[1]}: ${match[2]}` : `Chapter ${match[1]}`;
        let content = '';
        let summary = '';

        // Collect content from following lines
        for (let j = i + 1; j < Math.min(lines.length, i + 20); j++) {
          const contentLine = lines[j].trim();
          if (contentLine.match(/^(?:Chapter|Scene|Part)/i)) break;
          if (contentLine.length > 10) {
            content += contentLine + '\n';
          }
        }

        // Create summary from first 100 chars of content
        if (content.length > 100) {
          summary = content.substring(0, 100) + '...';
        }

        chapters.push({
          title,
          content: content.trim(),
          summary: summary || 'Chapter from outline',
          notes: `Extracted from ${fileName}`
        });
      }
    });
  }

  return chapters.slice(0, 10);
}