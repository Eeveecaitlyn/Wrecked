import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { nanoid } from 'nanoid';

interface CollaborationUser {
  id: string;
  name: string;
  email?: string;
  color: string;
  cursor?: { line: number; column: number };
  selection?: { start: { line: number; column: number }; end: { line: number; column: number } };
  isActive: boolean;
  lastSeen: Date;
}

interface DocumentVersion {
  id: string;
  chapterId: number;
  content: string;
  authorId: string;
  timestamp: Date;
  changes: DocumentChange[];
  parentVersionId?: string;
  branchName: string;
  commitMessage?: string;
}

interface DocumentChange {
  id: string;
  type: 'insert' | 'delete' | 'replace';
  position: number;
  length?: number;
  content?: string;
  authorId: string;
  timestamp: Date;
}

interface ActiveSession {
  chapterId: number;
  users: Map<string, CollaborationUser>;
  currentVersion: string;
  lockOwner?: string;
  lockExpires?: Date;
}

export class CollaborationManager {
  private wss: WebSocketServer;
  private sessions: Map<number, ActiveSession> = new Map();
  private userConnections: Map<string, WebSocket> = new Map();
  private versions: Map<string, DocumentVersion> = new Map();
  private branches: Map<number, Map<string, string[]>> = new Map(); // chapterId -> branchName -> versionIds

  constructor(server: Server) {
    this.wss = new WebSocketServer({ 
      server,
      path: '/collaboration'
    });

    this.wss.on('connection', this.handleConnection.bind(this));
    this.setupCleanupInterval();
  }

  private handleConnection(ws: WebSocket) {
    let userId: string | null = null;
    let currentChapterId: number | null = null;

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        switch (message.type) {
          case 'join':
            userId = message.userId || nanoid();
            currentChapterId = message.chapterId;
            if (userId && currentChapterId) {
              await this.handleUserJoin(ws, userId, message.user, currentChapterId);
            }
            break;
            
          case 'edit':
            if (userId && currentChapterId) {
              await this.handleEdit(userId, currentChapterId, message.changes);
            }
            break;
            
          case 'cursor':
            if (userId && currentChapterId) {
              await this.handleCursorUpdate(userId, currentChapterId, message.cursor);
            }
            break;
            
          case 'lock':
            if (userId && currentChapterId) {
              await this.handleLockRequest(ws, userId, currentChapterId);
            }
            break;
            
          case 'unlock':
            if (userId && currentChapterId) {
              await this.handleUnlock(userId, currentChapterId);
            }
            break;
            
          case 'create_version':
            if (userId && currentChapterId) {
              await this.createVersion(userId, currentChapterId, message.content, message.commitMessage);
            }
            break;
            
          case 'create_branch':
            if (userId && currentChapterId) {
              await this.createBranch(userId, currentChapterId, message.branchName, message.fromVersion);
            }
            break;
            
          case 'merge_branch':
            if (userId && currentChapterId) {
              await this.mergeBranch(userId, currentChapterId, message.fromBranch, message.toBranch);
            }
            break;
        }
      } catch (error) {
        console.error('Collaboration error:', error);
        ws.send(JSON.stringify({ type: 'error', message: 'Invalid message format' }));
      }
    });

    ws.on('close', () => {
      if (userId && currentChapterId) {
        this.handleUserLeave(userId, currentChapterId);
      }
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });
  }

  private async handleUserJoin(ws: WebSocket, userId: string, userData: any, chapterId: number) {
    if (!this.sessions.has(chapterId)) {
      this.sessions.set(chapterId, {
        chapterId,
        users: new Map(),
        currentVersion: nanoid()
      });
    }

    const session = this.sessions.get(chapterId)!;
    const user: CollaborationUser = {
      id: userId,
      name: userData.name || 'Anonymous',
      email: userData.email,
      color: userData.color || this.generateUserColor(),
      isActive: true,
      lastSeen: new Date()
    };

    session.users.set(userId, user);
    this.userConnections.set(userId, ws);

    // Send current session state to the new user
    ws.send(JSON.stringify({
      type: 'session_state',
      users: Array.from(session.users.values()),
      currentVersion: session.currentVersion,
      lockOwner: session.lockOwner
    }));

    // Notify other users
    this.broadcastToSession(chapterId, {
      type: 'user_joined',
      user
    }, userId);
  }

  private handleUserLeave(userId: string, chapterId: number) {
    const session = this.sessions.get(chapterId);
    if (session) {
      session.users.delete(userId);
      
      // Release lock if user had it
      if (session.lockOwner === userId) {
        session.lockOwner = undefined;
        session.lockExpires = undefined;
        this.broadcastToSession(chapterId, { type: 'document_unlocked' });
      }

      this.broadcastToSession(chapterId, {
        type: 'user_left',
        userId
      });

      // Clean up empty sessions
      if (session.users.size === 0) {
        this.sessions.delete(chapterId);
      }
    }

    this.userConnections.delete(userId);
  }

  private async handleEdit(userId: string, chapterId: number, changes: DocumentChange[]) {
    const session = this.sessions.get(chapterId);
    if (!session) return;

    // Check if document is locked by another user
    if (session.lockOwner && session.lockOwner !== userId) {
      const userWs = this.userConnections.get(userId);
      if (userWs) {
        userWs.send(JSON.stringify({
          type: 'edit_rejected',
          reason: 'Document is locked by another user'
        }));
      }
      return;
    }

    // Apply changes and broadcast to other users
    this.broadcastToSession(chapterId, {
      type: 'document_changes',
      changes,
      authorId: userId
    }, userId);

    // Update user activity
    const user = session.users.get(userId);
    if (user) {
      user.lastSeen = new Date();
    }
  }

  private async handleCursorUpdate(userId: string, chapterId: number, cursor: any) {
    const session = this.sessions.get(chapterId);
    if (!session) return;

    const user = session.users.get(userId);
    if (user) {
      user.cursor = cursor.position;
      user.selection = cursor.selection;
      user.lastSeen = new Date();

      this.broadcastToSession(chapterId, {
        type: 'cursor_update',
        userId,
        cursor: cursor.position,
        selection: cursor.selection
      }, userId);
    }
  }

  private async handleLockRequest(ws: WebSocket, userId: string, chapterId: number) {
    const session = this.sessions.get(chapterId);
    if (!session) return;

    if (session.lockOwner && session.lockOwner !== userId) {
      ws.send(JSON.stringify({
        type: 'lock_denied',
        reason: 'Document is already locked',
        lockOwner: session.lockOwner
      }));
      return;
    }

    session.lockOwner = userId;
    session.lockExpires = new Date(Date.now() + 30 * 60 * 1000); // 30 minutes

    this.broadcastToSession(chapterId, {
      type: 'document_locked',
      lockOwner: userId
    });
  }

  private async handleUnlock(userId: string, chapterId: number) {
    const session = this.sessions.get(chapterId);
    if (!session || session.lockOwner !== userId) return;

    session.lockOwner = undefined;
    session.lockExpires = undefined;

    this.broadcastToSession(chapterId, {
      type: 'document_unlocked'
    });
  }

  private async createVersion(userId: string, chapterId: number, content: string, commitMessage?: string) {
    const versionId = nanoid();
    const version: DocumentVersion = {
      id: versionId,
      chapterId,
      content,
      authorId: userId,
      timestamp: new Date(),
      changes: [],
      branchName: 'main',
      commitMessage
    };

    this.versions.set(versionId, version);

    // Update branch tracking
    if (!this.branches.has(chapterId)) {
      this.branches.set(chapterId, new Map());
    }
    const chapterBranches = this.branches.get(chapterId)!;
    if (!chapterBranches.has('main')) {
      chapterBranches.set('main', []);
    }
    chapterBranches.get('main')!.push(versionId);

    this.broadcastToSession(chapterId, {
      type: 'version_created',
      version: {
        id: versionId,
        authorId: userId,
        timestamp: version.timestamp,
        commitMessage,
        branchName: 'main'
      }
    });

    return versionId;
  }

  private async createBranch(userId: string, chapterId: number, branchName: string, fromVersionId?: string) {
    if (!this.branches.has(chapterId)) {
      this.branches.set(chapterId, new Map());
    }

    const chapterBranches = this.branches.get(chapterId)!;
    if (chapterBranches.has(branchName)) {
      const userWs = this.userConnections.get(userId);
      if (userWs) {
        userWs.send(JSON.stringify({
          type: 'branch_error',
          message: 'Branch already exists'
        }));
      }
      return;
    }

    chapterBranches.set(branchName, fromVersionId ? [fromVersionId] : []);

    this.broadcastToSession(chapterId, {
      type: 'branch_created',
      branchName,
      authorId: userId,
      fromVersionId
    });
  }

  private async mergeBranch(userId: string, chapterId: number, fromBranch: string, toBranch: string) {
    const chapterBranches = this.branches.get(chapterId);
    if (!chapterBranches || !chapterBranches.has(fromBranch) || !chapterBranches.has(toBranch)) {
      return;
    }

    // Simplified merge - in a real implementation, you'd handle conflicts
    const fromVersions = chapterBranches.get(fromBranch)!;
    const toVersions = chapterBranches.get(toBranch)!;
    
    if (fromVersions.length > 0) {
      const latestFromVersion = this.versions.get(fromVersions[fromVersions.length - 1]);
      if (latestFromVersion) {
        const mergeVersionId = await this.createVersion(
          userId,
          chapterId,
          latestFromVersion.content,
          `Merge ${fromBranch} into ${toBranch}`
        );

        this.broadcastToSession(chapterId, {
          type: 'branch_merged',
          fromBranch,
          toBranch,
          mergeVersionId,
          authorId: userId
        });
      }
    }
  }

  private broadcastToSession(chapterId: number, message: any, excludeUserId?: string) {
    const session = this.sessions.get(chapterId);
    if (!session) return;

    session.users.forEach((user, userId) => {
      if (userId !== excludeUserId) {
        const ws = this.userConnections.get(userId);
        if (ws && ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify(message));
        }
      }
    });
  }

  private generateUserColor(): string {
    const colors = [
      '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', 
      '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F'
    ];
    return colors[Math.floor(Math.random() * colors.length)];
  }

  private setupCleanupInterval() {
    setInterval(() => {
      const now = new Date();
      
      this.sessions.forEach((session, chapterId) => {
        // Remove inactive users
        session.users.forEach((user, userId) => {
          if (now.getTime() - user.lastSeen.getTime() > 5 * 60 * 1000) { // 5 minutes
            this.handleUserLeave(userId, chapterId);
          }
        });

        // Release expired locks
        if (session.lockExpires && now > session.lockExpires) {
          session.lockOwner = undefined;
          session.lockExpires = undefined;
          this.broadcastToSession(chapterId, { type: 'document_unlocked' });
        }
      });
    }, 60000); // Run every minute
  }

  public getSessionInfo(chapterId: number) {
    const session = this.sessions.get(chapterId);
    if (!session) return null;

    return {
      users: Array.from(session.users.values()),
      lockOwner: session.lockOwner,
      isLocked: !!session.lockOwner
    };
  }

  public getVersionHistory(chapterId: number, branchName: string = 'main') {
    const chapterBranches = this.branches.get(chapterId);
    if (!chapterBranches || !chapterBranches.has(branchName)) return [];

    const versionIds = chapterBranches.get(branchName)!;
    return versionIds.map(id => this.versions.get(id)).filter(v => v);
  }

  public getBranches(chapterId: number) {
    const chapterBranches = this.branches.get(chapterId);
    if (!chapterBranches) return [];

    return Array.from(chapterBranches.keys());
  }
}