import { storage } from "./storage";
import type { InsertCharacter, InsertLocation, InsertChapter } from "@shared/schema";

export interface ProcessedContent {
  charactersAdded: number;
  locationsAdded: number;
  chaptersAdded: number;
  extractedData: {
    characters: any[];
    locations: any[];
    chapters: any[];
  };
}

export async function processStoryFile(
  fileContent: string,
  fileName: string,
  projectId: number
): Promise<ProcessedContent> {
  const result: ProcessedContent = {
    charactersAdded: 0,
    locationsAdded: 0,
    chaptersAdded: 0,
    extractedData: {
      characters: [],
      locations: [],
      chapters: []
    }
  };

  // Extract characters from the content
  const characterMatches = extractCharacters(fileContent);
  for (const charData of characterMatches) {
    try {
      const character: InsertCharacter = {
        projectId,
        name: charData.name,
        description: charData.description,
        age: charData.age,
        notes: charData.notes
      };
      
      const created = await storage.createCharacter(character);
      result.extractedData.characters.push(created);
      result.charactersAdded++;
    } catch (error) {
      console.error('Failed to create character:', charData.name, error);
    }
  }

  // Extract locations from the content
  const locationMatches = extractLocations(fileContent);
  for (const locData of locationMatches) {
    try {
      const location: InsertLocation = {
        projectId,
        name: locData.name,
        description: locData.description,
        notes: locData.notes
      };
      
      const created = await storage.createLocation(location);
      result.extractedData.locations.push(created);
      result.locationsAdded++;
    } catch (error) {
      console.error('Failed to create location:', locData.name, error);
    }
  }

  // Extract chapters from the content
  const chapterMatches = extractChapters(fileContent);
  for (const chapterData of chapterMatches) {
    try {
      const chapter: InsertChapter = {
        projectId,
        title: chapterData.title,
        content: chapterData.content,
        orderIndex: chapterData.orderIndex,
        status: 'draft'
      };
      
      const created = await storage.createChapter(chapter);
      result.extractedData.chapters.push(created);
      result.chaptersAdded++;
    } catch (error) {
      console.error('Failed to create chapter:', chapterData.title, error);
    }
  }

  return result;
}

function extractCharacters(content: string): any[] {
  const characters = [];
  const lines = content.split('\n');
  
  // Look for character sections or patterns
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    // Pattern: "CHARACTER: Name" or "Name (character)"
    if (line.match(/^(CHARACTER|CHAR):\s*(.+)$/i) || 
        line.match(/^(.+)\s*\(character\)/i)) {
      
      const nameMatch = line.match(/^(?:CHARACTER|CHAR):\s*(.+)$/i) || 
                       line.match(/^(.+)\s*\(character\)/i);
      
      if (nameMatch) {
        const name = nameMatch[1].trim();
        
        // Look ahead for description
        let description = '';
        let age = null;
        let notes = '';
        
        for (let j = i + 1; j < Math.min(i + 10, lines.length); j++) {
          const nextLine = lines[j].trim();
          if (!nextLine) continue;
          
          if (nextLine.match(/^(CHARACTER|CHAR|LOCATION|LOC):/i)) break;
          
          if (nextLine.match(/age:\s*(\d+)/i)) {
            age = parseInt(nextLine.match(/age:\s*(\d+)/i)![1]);
          } else if (nextLine.length > 20) {
            description = description ? `${description} ${nextLine}` : nextLine;
          } else {
            notes = notes ? `${notes}\n${nextLine}` : nextLine;
          }
        }
        
        characters.push({
          name,
          description: description || `Character from ${content.slice(0, 50)}...`,
          age,
          notes
        });
      }
    }
    
    // Pattern: Look for names in quotes followed by descriptive text
    const quotedNameMatch = line.match(/"([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)"/);
    if (quotedNameMatch && characters.length < 10) {
      const name = quotedNameMatch[1];
      
      // Check if it's likely a character name (not a place or title)
      if (!name.match(/^(The|A|An)\s/) && 
          !characters.some(c => c.name === name)) {
        
        // Look for context around the name
        let description = '';
        const contextStart = Math.max(0, i - 2);
        const contextEnd = Math.min(lines.length, i + 3);
        
        for (let k = contextStart; k < contextEnd; k++) {
          if (k !== i && lines[k].trim().length > 10) {
            description = lines[k].trim();
            break;
          }
        }
        
        characters.push({
          name,
          description: description || `Character mentioned in uploaded content`,
          age: null,
          notes: `Extracted from uploaded file`
        });
      }
    }
  }
  
  return characters.slice(0, 10); // Limit to prevent spam
}

function extractLocations(content: string): any[] {
  const locations: any[] = [];
  const lines = content.split('\n');
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    // Pattern: "LOCATION: Name" or "Name (location)"
    if (line.match(/^(LOCATION|LOC|PLACE):\s*(.+)$/i) || 
        line.match(/^(.+)\s*\(location\)/i)) {
      
      const nameMatch = line.match(/^(?:LOCATION|LOC|PLACE):\s*(.+)$/i) || 
                       line.match(/^(.+)\s*\(location\)/i);
      
      if (nameMatch) {
        const name = nameMatch[1].trim();
        
        // Look ahead for description
        let description = '';
        let notes = '';
        
        for (let j = i + 1; j < Math.min(i + 5, lines.length); j++) {
          const nextLine = lines[j].trim();
          if (!nextLine) continue;
          
          if (nextLine.match(/^(CHARACTER|CHAR|LOCATION|LOC):/i)) break;
          
          if (nextLine.length > 20) {
            description = description ? `${description} ${nextLine}` : nextLine;
          } else {
            notes = notes ? `${notes}\n${nextLine}` : nextLine;
          }
        }
        
        locations.push({
          name,
          description: description || `Location from uploaded content`,
          notes
        });
      }
    }
    
    // Pattern: Common location indicators
    const locationPatterns = [
      /\b(at|in|near|by)\s+(?:the\s+)?([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2})\b/g,
      /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s+(Street|Avenue|Road|Lane|Boulevard|Drive|Plaza|Square|Park|Beach|Harbor|Station)\b/g
    ];
    
    locationPatterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(line)) !== null && locations.length < 8) {
        const name = match[2] || match[1];
        if (name && !locations.some((l: any) => l.name === name)) {
          locations.push({
            name,
            description: `Location mentioned in uploaded content`,
            notes: `Context: ${line.slice(Math.max(0, match.index - 20), match.index + 50)}`
          });
        }
      }
    });
  }
  
  return locations.slice(0, 8);
}

function extractChapters(content: string): any[] {
  const chapters = [];
  const lines = content.split('\n');
  
  // Look for chapter headings
  let currentChapter = null;
  let chapterContent = '';
  let orderIndex = 1;
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    // Chapter patterns
    const chapterMatch = line.match(/^(Chapter|Ch\.?)\s*(\d+)(?:\s*[:\-\—]\s*(.+))?$/i) ||
                        line.match(/^(\d+)\.\s*(.+)$/) ||
                        line.match(/^(Part|Section)\s*(\d+)(?:\s*[:\-\—]\s*(.+))?$/i);
    
    if (chapterMatch) {
      // Save previous chapter if exists
      if (currentChapter && chapterContent.trim()) {
        chapters.push({
          title: currentChapter,
          content: chapterContent.trim(),
          orderIndex: orderIndex++
        });
      }
      
      // Start new chapter
      const chapterNum = chapterMatch[2] || chapterMatch[1];
      const chapterTitle = chapterMatch[3] || chapterMatch[2] || '';
      currentChapter = chapterTitle ? 
        `Chapter ${chapterNum}: ${chapterTitle}` : 
        `Chapter ${chapterNum}`;
      chapterContent = '';
    } else if (currentChapter) {
      // Add to current chapter content
      chapterContent += line + '\n';
    } else if (line.length > 50 && chapters.length === 0) {
      // If no chapter headers found, treat as single chapter
      currentChapter = 'Imported Content';
      chapterContent = content;
      break;
    }
  }
  
  // Don't forget the last chapter
  if (currentChapter && chapterContent.trim()) {
    chapters.push({
      title: currentChapter,
      content: chapterContent.trim(),
      orderIndex: orderIndex
    });
  }
  
  return chapters.slice(0, 20); // Reasonable limit
}