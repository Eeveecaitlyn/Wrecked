import type { 
  InsertCharacter, InsertLocation, InsertChapter, InsertSymbol, 
  InsertMotif, InsertTheme, InsertEmotionalPattern, InsertLore 
} from "@shared/schema";

export interface ComprehensiveAnalysis {
  characters: InsertCharacter[];
  locations: InsertLocation[];
  chapters: InsertChapter[];
  symbols: InsertSymbol[];
  motifs: InsertMotif[];
  themes: InsertTheme[];
  emotionalPatterns: InsertEmotionalPattern[];
  lore: InsertLore[];
}

export class AdvancedStoryExtractor {
  private content: string;
  private fileName: string;
  private projectId: number;

  constructor(content: string, fileName: string, projectId: number) {
    this.content = content;
    this.fileName = fileName;
    this.projectId = projectId;
  }

  public async extract(): Promise<ComprehensiveAnalysis> {
    const analysis: ComprehensiveAnalysis = {
      characters: this.extractCharacters(),
      locations: this.extractLocations(),
      chapters: this.extractChapters(),
      symbols: this.extractSymbols(),
      motifs: this.extractMotifs(),
      themes: this.extractThemes(),
      emotionalPatterns: this.extractEmotionalPatterns(),
      lore: this.extractLore()
    };

    return analysis;
  }

  private extractCharacters(): InsertCharacter[] {
    const characters: InsertCharacter[] = [];
    const seenNames = new Set<string>();

    // Core Wrecked characters with enriched descriptions
    const coreCharacters = [
      { 
        name: 'Lilah Carter', 
        description: 'Main protagonist dealing with trauma and complex emotions',
        occupation: 'Unknown',
        notes: 'Central character - childhood connection to Lucas'
      },
      { 
        name: 'Lucas Reeves', 
        description: 'Male lead with deep emotional connection to Lilah', 
        occupation: 'Mechanic/garage work',
        notes: 'Central character - childhood connection to Lilah'
      },
      { 
        name: 'Mara', 
        description: 'Supporting character in the emotional landscape',
        notes: 'Important supporting role'
      }
    ];

    // Extract core characters if mentioned
    for (const char of coreCharacters) {
      const variations = [char.name, char.name.split(' ')[0]];
      for (const variation of variations) {
        if (this.content.toLowerCase().includes(variation.toLowerCase()) && 
            !seenNames.has(variation.toLowerCase())) {
          seenNames.add(variation.toLowerCase());
          characters.push({
            projectId: this.projectId,
            name: char.name,
            description: char.description,
            occupation: char.occupation || null,
            relationships: [],
            appearances: [],
            notes: `${char.notes} - Extracted from ${this.fileName}`,
            imageUrl: null
          });
          break;
        }
      }
    }

    // Extract explicitly mentioned characters in structured sections
    const characterSections = this.content.match(/(?:Character|Cast|People|Main|Supporting)[\s\S]*?(?=\n\n|\n[A-Z]|$)/gi);
    if (characterSections) {
      characterSections.forEach(section => {
        const lines = section.split('\n');
        lines.forEach(line => {
          const nameMatch = line.match(/^([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s*[-–—:]\s*(.+)/);
          if (nameMatch && !seenNames.has(nameMatch[1].toLowerCase())) {
            seenNames.add(nameMatch[1].toLowerCase());
            characters.push({
              projectId: this.projectId,
              name: nameMatch[1],
              description: nameMatch[2],
              relationships: [],
              appearances: [],
              notes: `Extracted from ${this.fileName} - character section`,
              imageUrl: null
            });
          }
        });
      });
    }

    return characters;
  }

  private extractLocations(): InsertLocation[] {
    const locations: InsertLocation[] = [];
    const seenNames = new Set<string>();

    // Core Wrecked locations
    const coreLocations = [
      { 
        name: 'The Cliffs', 
        description: 'Dramatic clifftop location overlooking the sea - significant for emotional moments',
        type: 'natural landscape'
      },
      { 
        name: 'The Bar', 
        description: 'Local gathering place where characters interact',
        type: 'social venue'
      },
      { 
        name: "Lilah's Childhood Home", 
        description: 'Where Lilah grew up - holds memories and emotional significance',
        type: 'residence'
      },
      { 
        name: "Lucas's Garage", 
        description: "Lucas's workplace and living space - represents his identity",
        type: 'workplace/residence'
      },
      { 
        name: "Mara's Home", 
        description: "Mara's residence",
        type: 'residence'
      },
      { 
        name: 'The Unkept Hour', 
        description: 'Mysterious or significant location in the story',
        type: 'symbolic location'
      }
    ];

    // Extract core locations if explicitly mentioned
    for (const loc of coreLocations) {
      const keywords = loc.name.toLowerCase().split(/\s+|'s/);
      const hasExactMention = keywords.some(keyword => {
        if (keyword.length > 2) {
          const regex = new RegExp(`\\b${keyword}\\b`, 'i');
          return regex.test(this.content);
        }
        return false;
      });

      if (hasExactMention && !seenNames.has(loc.name.toLowerCase())) {
        seenNames.add(loc.name.toLowerCase());
        locations.push({
          projectId: this.projectId,
          name: loc.name,
          description: loc.description,
          type: loc.type,
          connections: [],
          appearances: [],
          notes: `CORE LOCATION - Extracted from ${this.fileName}`,
          imageUrl: null
        });
      }
    }

    return locations;
  }

  private extractChapters(): InsertChapter[] {
    const chapters: InsertChapter[] = [];
    
    // Extract chapter headings and summaries
    const chapterMatches = this.content.match(/Chapter\s+(\d+|[IVX]+)\s*[-–—:]?\s*([^\n]+)?\n?([\s\S]*?)(?=Chapter\s+|\n\n[A-Z]|$)/gi);
    
    if (chapterMatches) {
      chapterMatches.forEach((match, index) => {
        const titleMatch = match.match(/Chapter\s+(\d+|[IVX]+)\s*[-–—:]?\s*([^\n]+)?/i);
        if (titleMatch) {
          const chapterNum = titleMatch[1];
          const title = titleMatch[2] || `Chapter ${chapterNum}`;
          const content = match.replace(titleMatch[0], '').trim();
          
          chapters.push({
            projectId: this.projectId,
            title: title.trim(),
            content: content.substring(0, 5000), // Limit content length
            wordCount: content.split(/\s+/).length,
            orderIndex: index + 1,
            status: 'draft'
          });
        }
      });
    }

    return chapters;
  }

  private extractSymbols(): InsertSymbol[] {
    const symbols: InsertSymbol[] = [];
    
    // Wrecked-specific symbolic elements
    const potentialSymbols = [
      { name: 'Cliffs', category: 'nature', meaning: 'Represents emotional precipice, danger, and transformation' },
      { name: 'Ocean/Sea', category: 'nature', meaning: 'Vastness of emotion, depth of feeling, uncertainty' },
      { name: 'Garage/Mechanics', category: 'object', meaning: 'Fixing what is broken, working with hands, practical vs emotional' },
      { name: 'Childhood Home', category: 'place', meaning: 'Past, innocence, what was lost or left behind' },
      { name: 'Broken/Wrecked', category: 'concept', meaning: 'Central metaphor for damaged relationships and people' },
      { name: 'Tools/Hands', category: 'object', meaning: 'Capability, creation, destruction, touch, connection' },
      { name: 'Time/Hour', category: 'concept', meaning: 'Moments lost, time passing, urgency, regret' }
    ];

    potentialSymbols.forEach(symbol => {
      const occurrences = this.findSymbolOccurrences(symbol.name);
      if (occurrences.length > 0) {
        symbols.push({
          projectId: this.projectId,
          name: symbol.name,
          description: `Symbolic element found in the narrative`,
          meaning: symbol.meaning,
          category: symbol.category,
          occurrences: occurrences,
          connections: [],
          significance: occurrences.length > 2 ? 'major' : 'minor',
          notes: `Extracted from ${this.fileName} - found ${occurrences.length} occurrences`
        });
      }
    });

    return symbols;
  }

  private extractMotifs(): InsertMotif[] {
    const motifs: InsertMotif[] = [];

    // Emotional and thematic motifs for Wrecked
    const potentialMotifs = [
      {
        name: 'Return/Homecoming',
        pattern: 'Characters returning to places or people from their past',
        function: 'Explores themes of reconciliation and confronting the past'
      },
      {
        name: 'Repair/Fixing',
        pattern: 'References to repairing objects, relationships, or people',
        function: 'Central metaphor for healing and restoration'
      },
      {
        name: 'Memory/Remembering',
        pattern: 'Recollections of the past, especially childhood',
        function: 'Connects past trauma to present emotional state'
      },
      {
        name: 'Touch/Physical Connection',
        pattern: 'Physical contact between characters, especially Lilah and Lucas',
        function: 'Represents intimacy, healing, and emotional breakthrough'
      },
      {
        name: 'Breaking/Destruction',
        pattern: 'Things being broken, destroyed, or falling apart',
        function: 'Reflects internal emotional states and relationship damage'
      }
    ];

    potentialMotifs.forEach(motif => {
      const examples = this.findMotifExamples(motif.name, motif.pattern);
      if (examples.length > 0) {
        motifs.push({
          projectId: this.projectId,
          name: motif.name,
          description: `Recurring thematic element in the narrative`,
          pattern: motif.pattern,
          function: motif.function,
          examples: examples,
          evolution: 'To be analyzed as story progresses',
          connections: [],
          notes: `Extracted from ${this.fileName} - found ${examples.length} examples`
        });
      }
    });

    return motifs;
  }

  private extractThemes(): InsertTheme[] {
    const themes: InsertTheme[] = [];

    // Major themes for Wrecked
    const potentialThemes = [
      {
        name: 'Trauma and Healing',
        category: 'psychological',
        description: 'The impact of past trauma on present relationships and the journey toward healing'
      },
      {
        name: 'Lost Love/Second Chances',
        category: 'romantic',
        description: 'The possibility of rekindling love after separation and hurt'
      },
      {
        name: 'Identity and Self-Worth',
        category: 'personal growth',
        description: 'Characters discovering who they are beyond their trauma and past'
      },
      {
        name: 'Trust and Vulnerability',
        category: 'emotional',
        description: 'Learning to open up and trust again after being hurt'
      },
      {
        name: 'Past vs Present',
        category: 'temporal',
        description: 'The tension between who characters were and who they are now'
      }
    ];

    potentialThemes.forEach(theme => {
      const manifestations = this.findThemeManifestations(theme.name);
      if (manifestations.length > 0) {
        themes.push({
          projectId: this.projectId,
          name: theme.name,
          description: theme.description,
          category: theme.category,
          development: 'Developed through character interactions and internal conflicts',
          manifestations: manifestations,
          conflicts: [],
          resolution: 'To be determined as story progresses',
          notes: `Extracted from ${this.fileName} - found ${manifestations.length} manifestations`
        });
      }
    });

    return themes;
  }

  private extractEmotionalPatterns(): InsertEmotionalPattern[] {
    const patterns: InsertEmotionalPattern[] = [];

    // Emotional patterns specific to trauma romance
    const potentialPatterns = [
      {
        name: 'Emotional Withdrawal',
        trigger: 'Memories of past trauma or fear of vulnerability',
        response: 'Characters pulling away or shutting down emotionally'
      },
      {
        name: 'Protective Anger',
        trigger: 'Perceived threats to self or loved ones',
        response: 'Using anger as a shield against deeper hurt'
      },
      {
        name: 'Intimacy Resistance',
        trigger: 'Physical or emotional closeness',
        response: 'Fear-based reactions to intimacy and connection'
      },
      {
        name: 'Guilt and Self-Blame',
        trigger: 'Reminders of past events or current happiness',
        response: 'Internal self-punishment and unworthiness feelings'
      }
    ];

    potentialPatterns.forEach(pattern => {
      const contexts = this.findEmotionalContexts(pattern.name);
      if (contexts.length > 0) {
        patterns.push({
          projectId: this.projectId,
          name: pattern.name,
          description: `Recurring emotional response pattern in the narrative`,
          trigger: pattern.trigger,
          response: pattern.response,
          characters: ['Lilah', 'Lucas'], // Default to main characters
          progression: 'Pattern evolves from destructive to healing throughout story',
          context: contexts,
          significance: 'Central to character development and relationship arc',
          notes: `Extracted from ${this.fileName} - found ${contexts.length} contexts`
        });
      }
    });

    return patterns;
  }

  private extractLore(): InsertLore[] {
    const lore: InsertLore[] = [];

    // Backstory and world elements
    const loreCategories = [
      'childhood history',
      'family background',
      'past trauma events',
      'community history',
      'relationship history',
      'character backstory'
    ];

    // Extract any sections that contain backstory or world-building information
    const loreMatches = this.content.match(/(?:History|Background|Past|Backstory|Before|Years ago|Childhood)[\s\S]*?(?=\n\n|\n[A-Z]|$)/gi);
    
    if (loreMatches) {
      loreMatches.forEach((match, index) => {
        const title = match.split('\n')[0].trim();
        const content = match.substring(title.length).trim();
        
        if (content.length > 50) { // Only include substantial content
          lore.push({
            projectId: this.projectId,
            name: title || `Background Information ${index + 1}`,
            description: content.substring(0, 500),
            category: this.categorizeLore(content),
            importance: 'relevant',
            connections: [],
            sources: [this.fileName],
            timeline: 'past',
            impact: 'Influences current character motivations and relationships',
            notes: `Extracted from ${this.fileName}`
          });
        }
      });
    }

    return lore;
  }

  // Helper methods for finding specific patterns
  private findSymbolOccurrences(symbolName: string): any[] {
    const occurrences: any[] = [];
    const keywords = symbolName.toLowerCase().split(/\s+/);
    
    keywords.forEach(keyword => {
      const regex = new RegExp(`\\b${keyword}\\w*\\b`, 'gi');
      let match;
      while ((match = regex.exec(this.content)) !== null) {
        const context = this.getContext(match.index, 100);
        occurrences.push({
          context: context,
          position: match.index,
          chapter: 'Unknown'
        });
      }
    });

    return occurrences.slice(0, 10); // Limit to 10 occurrences
  }

  private findMotifExamples(motifName: string, pattern: string): any[] {
    const examples: any[] = [];
    
    // Create search terms based on motif type
    let searchTerms: string[] = [];
    
    switch (motifName) {
      case 'Return/Homecoming':
        searchTerms = ['return', 'home', 'back', 'again', 'homecoming'];
        break;
      case 'Repair/Fixing':
        searchTerms = ['repair', 'fix', 'broken', 'mend', 'heal'];
        break;
      case 'Memory/Remembering':
        searchTerms = ['remember', 'memory', 'recall', 'past', 'childhood'];
        break;
      case 'Touch/Physical Connection':
        searchTerms = ['touch', 'hand', 'fingers', 'skin', 'embrace'];
        break;
      case 'Breaking/Destruction':
        searchTerms = ['break', 'broken', 'shatter', 'destroy', 'wreck'];
        break;
    }

    searchTerms.forEach(term => {
      const regex = new RegExp(`\\b${term}\\w*\\b`, 'gi');
      let match;
      while ((match = regex.exec(this.content)) !== null && examples.length < 5) {
        const context = this.getContext(match.index, 150);
        examples.push({
          text: context,
          chapter: 'Unknown',
          significance: 'To be analyzed'
        });
      }
    });

    return examples;
  }

  private findThemeManifestations(themeName: string): any[] {
    const manifestations: any[] = [];
    
    // Search for theme-related content
    let searchTerms: string[] = [];
    
    switch (themeName) {
      case 'Trauma and Healing':
        searchTerms = ['trauma', 'hurt', 'pain', 'heal', 'recovery'];
        break;
      case 'Lost Love/Second Chances':
        searchTerms = ['love', 'second chance', 'again', 'together'];
        break;
      case 'Identity and Self-Worth':
        searchTerms = ['worth', 'identity', 'who am i', 'self'];
        break;
      case 'Trust and Vulnerability':
        searchTerms = ['trust', 'vulnerable', 'open', 'guard'];
        break;
      case 'Past vs Present':
        searchTerms = ['past', 'present', 'now', 'then', 'before'];
        break;
    }

    searchTerms.forEach(term => {
      const regex = new RegExp(`\\b${term}\\w*\\b`, 'gi');
      let match;
      while ((match = regex.exec(this.content)) !== null && manifestations.length < 3) {
        const context = this.getContext(match.index, 200);
        manifestations.push({
          description: context,
          chapter: 'Unknown',
          characters: ['Lilah', 'Lucas']
        });
      }
    });

    return manifestations;
  }

  private findEmotionalContexts(patternName: string): any[] {
    const contexts: any[] = [];
    
    // Search for emotional language and contexts
    const emotionalTerms = ['feel', 'emotion', 'fear', 'anger', 'hurt', 'love', 'pain', 'joy', 'sad', 'happy'];
    
    emotionalTerms.forEach(term => {
      const regex = new RegExp(`\\b${term}\\w*\\b`, 'gi');
      let match;
      while ((match = regex.exec(this.content)) !== null && contexts.length < 3) {
        const context = this.getContext(match.index, 180);
        contexts.push({
          situation: context,
          chapter: 'Unknown',
          intensity: 'moderate'
        });
      }
    });

    return contexts;
  }

  private categorizeLore(content: string): string {
    const contentLower = content.toLowerCase();
    
    if (contentLower.includes('childhood') || contentLower.includes('child')) return 'childhood history';
    if (contentLower.includes('family') || contentLower.includes('parent')) return 'family background';
    if (contentLower.includes('trauma') || contentLower.includes('accident')) return 'past trauma events';
    if (contentLower.includes('town') || contentLower.includes('community')) return 'community history';
    if (contentLower.includes('relationship') || contentLower.includes('together')) return 'relationship history';
    
    return 'character backstory';
  }

  private getContext(position: number, length: number): string {
    const start = Math.max(0, position - length / 2);
    const end = Math.min(this.content.length, position + length / 2);
    return this.content.substring(start, end).trim();
  }
}