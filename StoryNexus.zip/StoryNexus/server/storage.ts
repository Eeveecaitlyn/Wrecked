import {
  projects, chapters, characters, locations, chatMessages, references, visuals,
  symbols, motifs, themes, emotionalPatterns, lore,
  type Project, type InsertProject,
  type Chapter, type InsertChapter,
  type Character, type InsertCharacter,
  type Location, type InsertLocation,
  type ChatMessage, type InsertChatMessage,
  type Reference, type InsertReference,
  type Visual, type InsertVisual,
  type Symbol, type InsertSymbol,
  type Motif, type InsertMotif,
  type Theme, type InsertTheme,
  type EmotionalPattern, type InsertEmotionalPattern,
  type Lore, type InsertLore
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Projects
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, updates: Partial<InsertProject>): Promise<Project | undefined>;
  
  // Chapters
  getChaptersByProject(projectId: number): Promise<Chapter[]>;
  getChapter(id: number): Promise<Chapter | undefined>;
  createChapter(chapter: InsertChapter): Promise<Chapter>;
  updateChapter(id: number, updates: Partial<InsertChapter>): Promise<Chapter | undefined>;
  deleteChapter(id: number): Promise<boolean>;
  
  // Characters
  getCharactersByProject(projectId: number): Promise<Character[]>;
  getCharacter(id: number): Promise<Character | undefined>;
  createCharacter(character: InsertCharacter): Promise<Character>;
  updateCharacter(id: number, updates: Partial<InsertCharacter>): Promise<Character | undefined>;
  deleteCharacter(id: number): Promise<boolean>;
  
  // Locations
  getLocationsByProject(projectId: number): Promise<Location[]>;
  getLocation(id: number): Promise<Location | undefined>;
  createLocation(location: InsertLocation): Promise<Location>;
  updateLocation(id: number, updates: Partial<InsertLocation>): Promise<Location | undefined>;
  deleteLocation(id: number): Promise<boolean>;
  
  // Chat Messages
  getChatMessagesByProject(projectId: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  clearChatHistory(projectId: number): Promise<boolean>;
  
  // References
  getReferencesByChapter(chapterId: number): Promise<Reference[]>;
  createReference(reference: InsertReference): Promise<Reference>;
  deleteReference(id: number): Promise<boolean>;
  
  // Visuals
  getVisualsByProject(projectId: number): Promise<Visual[]>;
  getVisual(id: number): Promise<Visual | undefined>;
  createVisual(visual: InsertVisual): Promise<Visual>;
  updateVisual(id: number, updates: Partial<InsertVisual>): Promise<Visual | undefined>;
  deleteVisual(id: number): Promise<boolean>;

  // Symbols
  getSymbolsByProject(projectId: number): Promise<Symbol[]>;
  getSymbol(id: number): Promise<Symbol | undefined>;
  createSymbol(symbol: InsertSymbol): Promise<Symbol>;
  updateSymbol(id: number, updates: Partial<InsertSymbol>): Promise<Symbol | undefined>;
  deleteSymbol(id: number): Promise<boolean>;

  // Motifs
  getMotifsByProject(projectId: number): Promise<Motif[]>;
  getMotif(id: number): Promise<Motif | undefined>;
  createMotif(motif: InsertMotif): Promise<Motif>;
  updateMotif(id: number, updates: Partial<InsertMotif>): Promise<Motif | undefined>;
  deleteMotif(id: number): Promise<boolean>;

  // Themes
  getThemesByProject(projectId: number): Promise<Theme[]>;
  getTheme(id: number): Promise<Theme | undefined>;
  createTheme(theme: InsertTheme): Promise<Theme>;
  updateTheme(id: number, updates: Partial<InsertTheme>): Promise<Theme | undefined>;
  deleteTheme(id: number): Promise<boolean>;

  // Emotional Patterns
  getEmotionalPatternsByProject(projectId: number): Promise<EmotionalPattern[]>;
  getEmotionalPattern(id: number): Promise<EmotionalPattern | undefined>;
  createEmotionalPattern(pattern: InsertEmotionalPattern): Promise<EmotionalPattern>;
  updateEmotionalPattern(id: number, updates: Partial<InsertEmotionalPattern>): Promise<EmotionalPattern | undefined>;
  deleteEmotionalPattern(id: number): Promise<boolean>;

  // Lore
  getLoreByProject(projectId: number): Promise<Lore[]>;
  getLoreItem(id: number): Promise<Lore | undefined>;
  createLore(lore: InsertLore): Promise<Lore>;
  updateLore(id: number, updates: Partial<InsertLore>): Promise<Lore | undefined>;
  deleteLore(id: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project || undefined;
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const [project] = await db
      .insert(projects)
      .values(insertProject)
      .returning();
    return project;
  }

  async updateProject(id: number, updates: Partial<InsertProject>): Promise<Project | undefined> {
    const [project] = await db
      .update(projects)
      .set(updates)
      .where(eq(projects.id, id))
      .returning();
    return project || undefined;
  }

  async getChaptersByProject(projectId: number): Promise<Chapter[]> {
    return await db.select().from(chapters).where(eq(chapters.projectId, projectId));
  }

  async getChapter(id: number): Promise<Chapter | undefined> {
    const [chapter] = await db.select().from(chapters).where(eq(chapters.id, id));
    return chapter || undefined;
  }

  async createChapter(insertChapter: InsertChapter): Promise<Chapter> {
    const [chapter] = await db
      .insert(chapters)
      .values(insertChapter)
      .returning();
    return chapter;
  }

  async updateChapter(id: number, updates: Partial<InsertChapter>): Promise<Chapter | undefined> {
    const [chapter] = await db
      .update(chapters)
      .set(updates)
      .where(eq(chapters.id, id))
      .returning();
    return chapter || undefined;
  }

  async deleteChapter(id: number): Promise<boolean> {
    const result = await db.delete(chapters).where(eq(chapters.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getCharactersByProject(projectId: number): Promise<Character[]> {
    return await db.select().from(characters).where(eq(characters.projectId, projectId));
  }

  async getCharacter(id: number): Promise<Character | undefined> {
    const [character] = await db.select().from(characters).where(eq(characters.id, id));
    return character || undefined;
  }

  async createCharacter(insertCharacter: InsertCharacter): Promise<Character> {
    const [character] = await db
      .insert(characters)
      .values(insertCharacter)
      .returning();
    return character;
  }

  async updateCharacter(id: number, updates: Partial<InsertCharacter>): Promise<Character | undefined> {
    const [character] = await db
      .update(characters)
      .set(updates)
      .where(eq(characters.id, id))
      .returning();
    return character || undefined;
  }

  async deleteCharacter(id: number): Promise<boolean> {
    const result = await db.delete(characters).where(eq(characters.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getLocationsByProject(projectId: number): Promise<Location[]> {
    return await db.select().from(locations).where(eq(locations.projectId, projectId));
  }

  async getLocation(id: number): Promise<Location | undefined> {
    const [location] = await db.select().from(locations).where(eq(locations.id, id));
    return location || undefined;
  }

  async createLocation(insertLocation: InsertLocation): Promise<Location> {
    const [location] = await db
      .insert(locations)
      .values(insertLocation)
      .returning();
    return location;
  }

  async updateLocation(id: number, updates: Partial<InsertLocation>): Promise<Location | undefined> {
    const [location] = await db
      .update(locations)
      .set(updates)
      .where(eq(locations.id, id))
      .returning();
    return location || undefined;
  }

  async deleteLocation(id: number): Promise<boolean> {
    const result = await db.delete(locations).where(eq(locations.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getChatMessagesByProject(projectId: number): Promise<ChatMessage[]> {
    return await db.select().from(chatMessages).where(eq(chatMessages.projectId, projectId));
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const [message] = await db
      .insert(chatMessages)
      .values(insertMessage)
      .returning();
    return message;
  }

  async clearChatHistory(projectId: number): Promise<boolean> {
    const result = await db.delete(chatMessages).where(eq(chatMessages.projectId, projectId));
    return (result.rowCount ?? 0) >= 0;
  }

  async getReferencesByChapter(chapterId: number): Promise<Reference[]> {
    return await db.select().from(references).where(eq(references.chapterId, chapterId));
  }

  async createReference(insertReference: InsertReference): Promise<Reference> {
    const [reference] = await db
      .insert(references)
      .values(insertReference)
      .returning();
    return reference;
  }

  async deleteReference(id: number): Promise<boolean> {
    const result = await db.delete(references).where(eq(references.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getVisualsByProject(projectId: number): Promise<Visual[]> {
    return await db.select().from(visuals).where(eq(visuals.projectId, projectId));
  }

  async getVisual(id: number): Promise<Visual | undefined> {
    const [visual] = await db.select().from(visuals).where(eq(visuals.id, id));
    return visual || undefined;
  }

  async createVisual(insertVisual: InsertVisual): Promise<Visual> {
    const [visual] = await db
      .insert(visuals)
      .values(insertVisual)
      .returning();
    return visual;
  }

  async updateVisual(id: number, updates: Partial<InsertVisual>): Promise<Visual | undefined> {
    const [visual] = await db
      .update(visuals)
      .set(updates)
      .where(eq(visuals.id, id))
      .returning();
    return visual || undefined;
  }

  async deleteVisual(id: number): Promise<boolean> {
    const result = await db.delete(visuals).where(eq(visuals.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Symbols implementation
  async getSymbolsByProject(projectId: number): Promise<Symbol[]> {
    return await db.select().from(symbols).where(eq(symbols.projectId, projectId));
  }

  async getSymbol(id: number): Promise<Symbol | undefined> {
    const [symbol] = await db.select().from(symbols).where(eq(symbols.id, id));
    return symbol || undefined;
  }

  async createSymbol(insertSymbol: InsertSymbol): Promise<Symbol> {
    const [symbol] = await db
      .insert(symbols)
      .values(insertSymbol)
      .returning();
    return symbol;
  }

  async updateSymbol(id: number, updates: Partial<InsertSymbol>): Promise<Symbol | undefined> {
    const [symbol] = await db
      .update(symbols)
      .set(updates)
      .where(eq(symbols.id, id))
      .returning();
    return symbol || undefined;
  }

  async deleteSymbol(id: number): Promise<boolean> {
    const result = await db.delete(symbols).where(eq(symbols.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Motifs implementation
  async getMotifsByProject(projectId: number): Promise<Motif[]> {
    return await db.select().from(motifs).where(eq(motifs.projectId, projectId));
  }

  async getMotif(id: number): Promise<Motif | undefined> {
    const [motif] = await db.select().from(motifs).where(eq(motifs.id, id));
    return motif || undefined;
  }

  async createMotif(insertMotif: InsertMotif): Promise<Motif> {
    const [motif] = await db
      .insert(motifs)
      .values(insertMotif)
      .returning();
    return motif;
  }

  async updateMotif(id: number, updates: Partial<InsertMotif>): Promise<Motif | undefined> {
    const [motif] = await db
      .update(motifs)
      .set(updates)
      .where(eq(motifs.id, id))
      .returning();
    return motif || undefined;
  }

  async deleteMotif(id: number): Promise<boolean> {
    const result = await db.delete(motifs).where(eq(motifs.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Themes implementation
  async getThemesByProject(projectId: number): Promise<Theme[]> {
    return await db.select().from(themes).where(eq(themes.projectId, projectId));
  }

  async getTheme(id: number): Promise<Theme | undefined> {
    const [theme] = await db.select().from(themes).where(eq(themes.id, id));
    return theme || undefined;
  }

  async createTheme(insertTheme: InsertTheme): Promise<Theme> {
    const [theme] = await db
      .insert(themes)
      .values(insertTheme)
      .returning();
    return theme;
  }

  async updateTheme(id: number, updates: Partial<InsertTheme>): Promise<Theme | undefined> {
    const [theme] = await db
      .update(themes)
      .set(updates)
      .where(eq(themes.id, id))
      .returning();
    return theme || undefined;
  }

  async deleteTheme(id: number): Promise<boolean> {
    const result = await db.delete(themes).where(eq(themes.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Emotional Patterns implementation
  async getEmotionalPatternsByProject(projectId: number): Promise<EmotionalPattern[]> {
    return await db.select().from(emotionalPatterns).where(eq(emotionalPatterns.projectId, projectId));
  }

  async getEmotionalPattern(id: number): Promise<EmotionalPattern | undefined> {
    const [pattern] = await db.select().from(emotionalPatterns).where(eq(emotionalPatterns.id, id));
    return pattern || undefined;
  }

  async createEmotionalPattern(insertPattern: InsertEmotionalPattern): Promise<EmotionalPattern> {
    const [pattern] = await db
      .insert(emotionalPatterns)
      .values(insertPattern)
      .returning();
    return pattern;
  }

  async updateEmotionalPattern(id: number, updates: Partial<InsertEmotionalPattern>): Promise<EmotionalPattern | undefined> {
    const [pattern] = await db
      .update(emotionalPatterns)
      .set(updates)
      .where(eq(emotionalPatterns.id, id))
      .returning();
    return pattern || undefined;
  }

  async deleteEmotionalPattern(id: number): Promise<boolean> {
    const result = await db.delete(emotionalPatterns).where(eq(emotionalPatterns.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Lore implementation
  async getLoreByProject(projectId: number): Promise<Lore[]> {
    return await db.select().from(lore).where(eq(lore.projectId, projectId));
  }

  async getLoreItem(id: number): Promise<Lore | undefined> {
    const [loreItem] = await db.select().from(lore).where(eq(lore.id, id));
    return loreItem || undefined;
  }

  async createLore(insertLore: InsertLore): Promise<Lore> {
    const [loreItem] = await db
      .insert(lore)
      .values(insertLore)
      .returning();
    return loreItem;
  }

  async updateLore(id: number, updates: Partial<InsertLore>): Promise<Lore | undefined> {
    const [loreItem] = await db
      .update(lore)
      .set(updates)
      .where(eq(lore.id, id))
      .returning();
    return loreItem || undefined;
  }

  async deleteLore(id: number): Promise<boolean> {
    const result = await db.delete(lore).where(eq(lore.id, id));
    return (result.rowCount ?? 0) > 0;
  }
}

export class MemStorage implements IStorage {
  private projects: Map<number, Project>;
  private chapters: Map<number, Chapter>;
  private characters: Map<number, Character>;
  private locations: Map<number, Location>;
  private chatMessages: Map<number, ChatMessage>;
  private references: Map<number, Reference>;
  private symbols: Map<number, Symbol>;
  private motifs: Map<number, Motif>;
  private themes: Map<number, Theme>;
  private emotionalPatterns: Map<number, EmotionalPattern>;
  private lore: Map<number, Lore>;
  private currentIds: {
    project: number;
    chapter: number;
    character: number;
    location: number;
    chatMessage: number;
    reference: number;
    symbol: number;
    motif: number;
    theme: number;
    emotionalPattern: number;
    lore: number;
  };

  constructor() {
    this.projects = new Map();
    this.chapters = new Map();
    this.characters = new Map();
    this.locations = new Map();
    this.chatMessages = new Map();
    this.references = new Map();
    this.symbols = new Map();
    this.motifs = new Map();
    this.themes = new Map();
    this.emotionalPatterns = new Map();
    this.lore = new Map();
    this.currentIds = {
      project: 1,
      chapter: 1,
      character: 1,
      location: 1,
      chatMessage: 1,
      reference: 1,
      symbol: 1,
      motif: 1,
      theme: 1,
      emotionalPattern: 1,
      lore: 1,
    };

    // Initialize with a default project
    this.initializeDefaultProject();
  }

  private initializeDefaultProject() {
    const defaultProject: Project = {
      id: 1,
      title: "The Chronicles of Aetheria",
      description: "An epic fantasy novel set in a world of floating cities and ancient magic",
      wordCount: 47329,
      chapterCount: 12,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.projects.set(1, defaultProject);
    this.currentIds.project = 2;
  }

  // Projects
  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.currentIds.project++;
    const project: Project = {
      id,
      title: insertProject.title,
      description: insertProject.description || null,
      wordCount: insertProject.wordCount || null,
      chapterCount: insertProject.chapterCount || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: number, updates: Partial<InsertProject>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    
    const updated: Project = {
      ...project,
      ...updates,
      updatedAt: new Date(),
    };
    this.projects.set(id, updated);
    return updated;
  }

  // Chapters
  async getChaptersByProject(projectId: number): Promise<Chapter[]> {
    return Array.from(this.chapters.values())
      .filter(chapter => chapter.projectId === projectId)
      .sort((a, b) => a.orderIndex - b.orderIndex);
  }

  async getChapter(id: number): Promise<Chapter | undefined> {
    return this.chapters.get(id);
  }

  async createChapter(insertChapter: InsertChapter): Promise<Chapter> {
    const id = this.currentIds.chapter++;
    const chapter: Chapter = {
      id,
      title: insertChapter.title,
      content: insertChapter.content || null,
      projectId: insertChapter.projectId,
      wordCount: insertChapter.wordCount || null,
      orderIndex: insertChapter.orderIndex,
      status: insertChapter.status || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.chapters.set(id, chapter);
    return chapter;
  }

  async updateChapter(id: number, updates: Partial<InsertChapter>): Promise<Chapter | undefined> {
    const chapter = this.chapters.get(id);
    if (!chapter) return undefined;
    
    const updated: Chapter = {
      ...chapter,
      ...updates,
      updatedAt: new Date(),
    };
    this.chapters.set(id, updated);
    return updated;
  }

  async deleteChapter(id: number): Promise<boolean> {
    return this.chapters.delete(id);
  }

  // Characters
  async getCharactersByProject(projectId: number): Promise<Character[]> {
    return Array.from(this.characters.values())
      .filter(character => character.projectId === projectId);
  }

  async getCharacter(id: number): Promise<Character | undefined> {
    return this.characters.get(id);
  }

  async createCharacter(insertCharacter: InsertCharacter): Promise<Character> {
    const id = this.currentIds.character++;
    const character: Character = {
      id,
      name: insertCharacter.name,
      projectId: insertCharacter.projectId,
      description: insertCharacter.description || null,
      age: insertCharacter.age || null,
      occupation: insertCharacter.occupation || null,
      relationships: insertCharacter.relationships || [],
      appearances: insertCharacter.appearances || [],
      notes: insertCharacter.notes || null,
      imageUrl: insertCharacter.imageUrl || null,
      createdAt: new Date(),
    };
    this.characters.set(id, character);
    return character;
  }

  async updateCharacter(id: number, updates: Partial<InsertCharacter>): Promise<Character | undefined> {
    const character = this.characters.get(id);
    if (!character) return undefined;
    
    const updated: Character = { ...character, ...updates };
    this.characters.set(id, updated);
    return updated;
  }

  async deleteCharacter(id: number): Promise<boolean> {
    return this.characters.delete(id);
  }

  // Locations
  async getLocationsByProject(projectId: number): Promise<Location[]> {
    return Array.from(this.locations.values())
      .filter(location => location.projectId === projectId);
  }

  async getLocation(id: number): Promise<Location | undefined> {
    return this.locations.get(id);
  }

  async createLocation(insertLocation: InsertLocation): Promise<Location> {
    const id = this.currentIds.location++;
    const location: Location = {
      id,
      name: insertLocation.name,
      projectId: insertLocation.projectId,
      description: insertLocation.description || null,
      type: insertLocation.type || null,
      connections: insertLocation.connections || [],
      appearances: insertLocation.appearances || [],
      notes: insertLocation.notes || null,
      imageUrl: insertLocation.imageUrl || null,
      createdAt: new Date(),
    };
    this.locations.set(id, location);
    return location;
  }

  async updateLocation(id: number, updates: Partial<InsertLocation>): Promise<Location | undefined> {
    const location = this.locations.get(id);
    if (!location) return undefined;
    
    const updated: Location = { ...location, ...updates };
    this.locations.set(id, updated);
    return updated;
  }

  async deleteLocation(id: number): Promise<boolean> {
    return this.locations.delete(id);
  }

  // Chat Messages
  async getChatMessagesByProject(projectId: number): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter(message => message.projectId === projectId)
      .sort((a, b) => a.createdAt!.getTime() - b.createdAt!.getTime());
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = this.currentIds.chatMessage++;
    const message: ChatMessage = {
      id,
      projectId: insertMessage.projectId,
      role: insertMessage.role,
      content: insertMessage.content,
      context: insertMessage.context || {},
      modelUsed: insertMessage.modelUsed || null,
      createdAt: new Date(),
    };
    this.chatMessages.set(id, message);
    return message;
  }

  async clearChatHistory(projectId: number): Promise<boolean> {
    const messagesToDelete = Array.from(this.chatMessages.entries())
      .filter(([_, message]) => message.projectId === projectId);
    
    messagesToDelete.forEach(([id]) => this.chatMessages.delete(id));
    return true;
  }

  // References
  async getReferencesByChapter(chapterId: number): Promise<Reference[]> {
    return Array.from(this.references.values())
      .filter(reference => reference.chapterId === chapterId);
  }

  async createReference(insertReference: InsertReference): Promise<Reference> {
    const id = this.currentIds.reference++;
    const reference: Reference = {
      ...insertReference,
      id,
      createdAt: new Date(),
    };
    this.references.set(id, reference);
    return reference;
  }

  async deleteReference(id: number): Promise<boolean> {
    return this.references.delete(id);
  }

  // Visuals (placeholder implementation for MemStorage)
  async getVisualsByProject(projectId: number): Promise<Visual[]> {
    return [];
  }

  async getVisual(id: number): Promise<Visual | undefined> {
    return undefined;
  }

  async createVisual(visual: InsertVisual): Promise<Visual> {
    throw new Error("Visuals not implemented in MemStorage");
  }

  async updateVisual(id: number, updates: Partial<InsertVisual>): Promise<Visual | undefined> {
    return undefined;
  }

  async deleteVisual(id: number): Promise<boolean> {
    return false;
  }

  // Symbols implementation for MemStorage
  async getSymbolsByProject(projectId: number): Promise<Symbol[]> {
    return Array.from(this.symbols.values())
      .filter(symbol => symbol.projectId === projectId);
  }

  async getSymbol(id: number): Promise<Symbol | undefined> {
    return this.symbols.get(id);
  }

  async createSymbol(insertSymbol: InsertSymbol): Promise<Symbol> {
    const id = this.currentIds.symbol++;
    const symbol: Symbol = {
      ...insertSymbol,
      id,
      createdAt: new Date(),
    };
    this.symbols.set(id, symbol);
    return symbol;
  }

  async updateSymbol(id: number, updates: Partial<InsertSymbol>): Promise<Symbol | undefined> {
    const existing = this.symbols.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.symbols.set(id, updated);
    return updated;
  }

  async deleteSymbol(id: number): Promise<boolean> {
    return this.symbols.delete(id);
  }

  // Motifs implementation for MemStorage
  async getMotifsByProject(projectId: number): Promise<Motif[]> {
    return Array.from(this.motifs.values())
      .filter(motif => motif.projectId === projectId);
  }

  async getMotif(id: number): Promise<Motif | undefined> {
    return this.motifs.get(id);
  }

  async createMotif(insertMotif: InsertMotif): Promise<Motif> {
    const id = this.currentIds.motif++;
    const motif: Motif = {
      ...insertMotif,
      id,
      createdAt: new Date(),
    };
    this.motifs.set(id, motif);
    return motif;
  }

  async updateMotif(id: number, updates: Partial<InsertMotif>): Promise<Motif | undefined> {
    const existing = this.motifs.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.motifs.set(id, updated);
    return updated;
  }

  async deleteMotif(id: number): Promise<boolean> {
    return this.motifs.delete(id);
  }

  // Themes implementation for MemStorage
  async getThemesByProject(projectId: number): Promise<Theme[]> {
    return Array.from(this.themes.values())
      .filter(theme => theme.projectId === projectId);
  }

  async getTheme(id: number): Promise<Theme | undefined> {
    return this.themes.get(id);
  }

  async createTheme(insertTheme: InsertTheme): Promise<Theme> {
    const id = this.currentIds.theme++;
    const theme: Theme = {
      ...insertTheme,
      id,
      createdAt: new Date(),
    };
    this.themes.set(id, theme);
    return theme;
  }

  async updateTheme(id: number, updates: Partial<InsertTheme>): Promise<Theme | undefined> {
    const existing = this.themes.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.themes.set(id, updated);
    return updated;
  }

  async deleteTheme(id: number): Promise<boolean> {
    return this.themes.delete(id);
  }

  // Emotional Patterns implementation for MemStorage
  async getEmotionalPatternsByProject(projectId: number): Promise<EmotionalPattern[]> {
    return Array.from(this.emotionalPatterns.values())
      .filter(pattern => pattern.projectId === projectId);
  }

  async getEmotionalPattern(id: number): Promise<EmotionalPattern | undefined> {
    return this.emotionalPatterns.get(id);
  }

  async createEmotionalPattern(insertPattern: InsertEmotionalPattern): Promise<EmotionalPattern> {
    const id = this.currentIds.emotionalPattern++;
    const pattern: EmotionalPattern = {
      ...insertPattern,
      id,
      createdAt: new Date(),
    };
    this.emotionalPatterns.set(id, pattern);
    return pattern;
  }

  async updateEmotionalPattern(id: number, updates: Partial<InsertEmotionalPattern>): Promise<EmotionalPattern | undefined> {
    const existing = this.emotionalPatterns.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.emotionalPatterns.set(id, updated);
    return updated;
  }

  async deleteEmotionalPattern(id: number): Promise<boolean> {
    return this.emotionalPatterns.delete(id);
  }

  // Lore implementation for MemStorage
  async getLoreByProject(projectId: number): Promise<Lore[]> {
    return Array.from(this.lore.values())
      .filter(loreItem => loreItem.projectId === projectId);
  }

  async getLoreItem(id: number): Promise<Lore | undefined> {
    return this.lore.get(id);
  }

  async createLore(insertLore: InsertLore): Promise<Lore> {
    const id = this.currentIds.lore++;
    const loreItem: Lore = {
      ...insertLore,
      id,
      createdAt: new Date(),
    };
    this.lore.set(id, loreItem);
    return loreItem;
  }

  async updateLore(id: number, updates: Partial<InsertLore>): Promise<Lore | undefined> {
    const existing = this.lore.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.lore.set(id, updated);
    return updated;
  }

  async deleteLore(id: number): Promise<boolean> {
    return this.lore.delete(id);
  }
}

export const storage = new DatabaseStorage();
