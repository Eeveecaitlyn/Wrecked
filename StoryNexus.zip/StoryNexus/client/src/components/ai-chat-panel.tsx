import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Bot, User, Send, Minus, Paperclip, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import type { ChatMessage } from "@shared/schema";

interface AiChatPanelProps {
  projectId: number;
  onToggle: () => void;
}

const aiModels = [
  { value: "openai/gpt-4o-mini", label: "GPT-4o Mini (Fast & Creative)" },
  { value: "anthropic/claude-3-haiku", label: "Claude-3 Haiku (Quick Analysis)" },
  { value: "anthropic/claude-3-sonnet", label: "Claude-3 Sonnet (Balanced)" },
  { value: "meta-llama/llama-3.1-8b-instruct", label: "Llama-3.1 8B (Fast)" },
  { value: "meta-llama/llama-3.1-70b-instruct", label: "Llama-3.1 70B (Advanced)" },
  { value: "meta-llama/llama-3.2-3b-instruct", label: "Llama-3.2 3B (Efficient)" },
  { value: "mistralai/mistral-7b-instruct", label: "Mistral-7B (Efficient)" },
  { value: "mistralai/mixtral-8x7b-instruct", label: "Mixtral 8x7B (Powerful)" },
  { value: "google/gemini-flash-1.5", label: "Gemini Flash (Google)" },
  { value: "qwen/qwen-2-7b-instruct", label: "Qwen-2 7B (Alibaba)" },
  { value: "microsoft/wizardlm-2-8x22b", label: "WizardLM-2 (Microsoft)" },
  { value: "nvidia/nemotron-4-340b-instruct", label: "Nemotron-4 340B (NVIDIA)" },
];

export default function AiChatPanel({ projectId, onToggle }: AiChatPanelProps) {
  const { toast } = useToast();
  const [message, setMessage] = useState("");
  const [selectedModel, setSelectedModel] = useState("openai/gpt-4o-mini");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: messages = [], isLoading } = useQuery<ChatMessage[]>({
    queryKey: [`/api/projects/${projectId}/chat`],
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (messageData: { content: string; model: string }) => {
      return apiRequest("POST", "/api/chat", {
        projectId,
        content: messageData.content,
        model: messageData.model,
        context: {},
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/chat`] });
      setMessage("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const clearChatMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("DELETE", `/api/projects/${projectId}/chat`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/chat`] });
      toast({
        title: "Chat cleared",
        description: "Your conversation history has been cleared.",
      });
    },
  });

  const handleSendMessage = () => {
    if (!message.trim() || sendMessageMutation.isPending) return;
    
    sendMessageMutation.mutate({
      content: message,
      model: selectedModel,
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  return (
    <div className="w-96 bg-white border-l border-gray-200 flex flex-col">
      {/* Chat Header */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center">
              <Bot className="h-4 w-4 text-white" />
            </div>
            <div>
              <h3 className="font-medium text-charcoal">AI Writing Assistant</h3>
              <p className="text-xs text-gray-500">Powered by OpenRouter</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={onToggle}>
            <Minus className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="mt-3">
          <Select value={selectedModel} onValueChange={setSelectedModel}>
            <SelectTrigger className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {aiModels.map((model) => (
                <SelectItem key={model.value} value={model.value}>
                  {model.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
          </div>
        ) : messages.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Bot className="h-8 w-8 mx-auto mb-2 text-gray-400" />
            <p className="text-sm">Start a conversation with your AI writing assistant!</p>
            <p className="text-xs mt-1">Ask about characters, plot development, or get writing suggestions.</p>
          </div>
        ) : (
          messages.map((msg) => (
            <div key={msg.id} className={`flex items-start space-x-2 ${msg.role === "user" ? "flex-row-reverse space-x-reverse" : ""}`}>
              <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                msg.role === "user" 
                  ? "bg-charcoal" 
                  : "bg-gradient-to-r from-primary to-secondary"
              }`}>
                {msg.role === "user" ? (
                  <User className="h-3 w-3 text-white" />
                ) : (
                  <Bot className="h-3 w-3 text-white" />
                )}
              </div>
              <div className={`chat-message ${msg.role}`}>
                <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                <div className="flex items-center justify-between mt-2">
                  <span className={`text-xs ${msg.role === "user" ? "text-blue-200" : "text-gray-500"}`}>
                    {new Date(msg.createdAt!).toLocaleTimeString()}
                  </span>
                  {msg.modelUsed && (
                    <span className="text-xs text-gray-400">
                      {aiModels.find(m => m.value === msg.modelUsed)?.label.split(" ")[0] || msg.modelUsed}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
        
        {sendMessageMutation.isPending && (
          <div className="flex items-start space-x-2">
            <div className="w-6 h-6 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center flex-shrink-0">
              <Bot className="h-3 w-3 text-white" />
            </div>
            <div className="chat-message assistant">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex space-x-2 mb-2">
          <Input
            type="text"
            placeholder="Ask about your story, characters, or get writing help..."
            className="flex-1"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            disabled={sendMessageMutation.isPending}
          />
          <Button 
            size="sm"
            onClick={handleSendMessage}
            disabled={!message.trim() || sendMessageMutation.isPending}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="text-xs text-gray-500 hover:text-charcoal p-1">
              <Paperclip className="h-3 w-3 mr-1" />
              Add Context
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs text-gray-500 hover:text-charcoal p-1"
              onClick={() => clearChatMutation.mutate()}
              disabled={clearChatMutation.isPending || messages.length === 0}
            >
              <Trash2 className="h-3 w-3 mr-1" />
              Clear Chat
            </Button>
          </div>
          <span className="text-xs text-gray-400">Shift+Enter for new line</span>
        </div>
      </div>
    </div>
  );
}
