import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Clock, Users, MapPin, Zap, Plus, Upload, FileText, BookOpen
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Chapter, Character, Location } from "@shared/schema";

interface StoryOutlineProps {
  projectId: number;
}

interface OutlineSection {
  id: string;
  title: string;
  description: string;
  chapterIds: number[];
  type: "act" | "arc" | "book";
  orderIndex: number;
}

export default function StoryOutline({ projectId }: StoryOutlineProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const { data: chapters = [], isLoading } = useQuery<Chapter[]>({
    queryKey: [`/api/projects/${projectId}/chapters`],
  });

  const { data: characters = [] } = useQuery<Character[]>({
    queryKey: [`/api/projects/${projectId}/characters`],
  });

  const { data: locations = [] } = useQuery<Location[]>({
    queryKey: [`/api/projects/${projectId}/locations`],
  });

  // Story outline structure for "Wrecked"
  const storyOutline: OutlineSection[] = [
    {
      id: "setup",
      title: "Act I: Return & Recognition",
      description: "Lilah returns to her hometown after six years, confronting the life and people she left behind. Initial reunion with Lucas and the weight of their shared past.",
      chapterIds: chapters.slice(0, 8).map(ch => ch.id),
      type: "act",
      orderIndex: 1
    },
    {
      id: "rising-action",
      title: "Act II: Confrontation & Revelation", 
      description: "The emotional barriers between Lilah and Lucas begin to crack. Past traumas surface, forcing them to face what really happened six years ago.",
      chapterIds: chapters.slice(8, 24).map(ch => ch.id),
      type: "act",
      orderIndex: 2
    },
    {
      id: "climax",
      title: "Act III: Breaking Point & Truth",
      description: "The traumatic event that drove them apart is fully revealed. Both must decide whether to remain broken by the past or fight for their future together.",
      chapterIds: chapters.slice(24, 30).map(ch => ch.id),
      type: "act",
      orderIndex: 3
    },
    {
      id: "resolution",
      title: "Act IV: Healing & New Beginning",
      description: "Lilah and Lucas navigate the difficult path of healing together. Learning to love each other's damaged parts and building something new from the wreckage.",
      chapterIds: chapters.slice(30).map(ch => ch.id),
      type: "act",
      orderIndex: 4
    }
  ];

  const uploadFileMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('projectId', projectId.toString());
      
      const response = await fetch('/api/upload/story-content', {
        method: 'POST',
        body: formData
      });
      
      if (!response.ok) throw new Error('Upload failed');
      return response.json();
    },
    onSuccess: (data: any) => {
      toast({
        title: "File processed",
        description: `Extracted ${data.charactersAdded || 0} characters, ${data.locationsAdded || 0} locations, and ${data.chaptersAdded || 0} chapters.`
      });
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/chapters`] });
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/characters`] });
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/locations`] });
      setSelectedFile(null);
      setIsUploadOpen(false);
    },
    onError: () => {
      toast({
        title: "Upload failed",
        description: "Failed to process the uploaded file.",
        variant: "destructive"
      });
    }
  });

  const handleFileUpload = () => {
    if (selectedFile) {
      uploadFileMutation.mutate(selectedFile);
    }
  };

  const getChaptersByAct = (actId: string) => {
    const act = storyOutline.find(section => section.id === actId);
    return act ? chapters.filter(ch => act.chapterIds.includes(ch.id)) : [];
  };

  const getActProgress = (actId: string) => {
    const actChapters = getChaptersByAct(actId);
    const completedChapters = actChapters.filter(ch => 
      ch.content && ch.content.length > 100
    ).length;
    return actChapters.length > 0 ? (completedChapters / actChapters.length) * 100 : 0;
  };

  const extractThemes = (content: string) => {
    const themes = [];
    if (content.toLowerCase().includes('emotion')) themes.push('Emotional');
    if (content.toLowerCase().includes('power')) themes.push('Power');
    if (content.toLowerCase().includes('trust')) themes.push('Trust');
    if (content.toLowerCase().includes('trauma')) themes.push('Trauma');
    if (content.toLowerCase().includes('intimacy')) themes.push('Intimacy');
    if (content.toLowerCase().includes('confrontation')) themes.push('Confrontation');
    return themes.slice(0, 3);
  };

  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-500">Loading story outline...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-charcoal">Story Outline</h2>
            <p className="text-sm text-gray-500">
              Structural view of your novel with act progression and chapter organization
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <Dialog open={isUploadOpen} onOpenChange={setIsUploadOpen}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Upload className="h-4 w-4 mr-2" />
                  Import Content
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Import Story Content</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <p className="text-sm text-gray-600">
                    Upload story documents to automatically extract characters, locations, and plot structure.
                    Supports .docx, .txt, and .md files.
                  </p>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    {selectedFile ? (
                      <div>
                        <FileText className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                        <p className="text-sm font-medium">{selectedFile.name}</p>
                        <p className="text-xs text-gray-500">
                          {(selectedFile.size / 1024).toFixed(1)} KB
                        </p>
                      </div>
                    ) : (
                      <div>
                        <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-sm text-gray-600">Choose a file to upload</p>
                      </div>
                    )}
                    <input
                      type="file"
                      accept=".docx,.txt,.md"
                      onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                      className="mt-4"
                    />
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setIsUploadOpen(false)}>
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleFileUpload}
                      disabled={!selectedFile || uploadFileMutation.isPending}
                    >
                      {uploadFileMutation.isPending ? "Processing..." : "Import Content"}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      {/* Story Structure */}
      <div className="flex-1 p-6">
        <Tabs defaultValue="acts" className="space-y-6">
          <TabsList>
            <TabsTrigger value="acts">Act Structure</TabsTrigger>
            <TabsTrigger value="timeline">Chapter Timeline</TabsTrigger>
            <TabsTrigger value="themes">Theme Analysis</TabsTrigger>
          </TabsList>

          <TabsContent value="acts" className="space-y-6">
            {storyOutline.map((act) => {
              const actChapters = getChaptersByAct(act.id);
              const progress = getActProgress(act.id);
              
              return (
                <Card key={act.id} className="overflow-hidden">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-xl">{act.title}</CardTitle>
                        <CardDescription className="mt-2">{act.description}</CardDescription>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-blue-600">{Math.round(progress)}%</div>
                        <div className="text-xs text-gray-500">Complete</div>
                      </div>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2 mt-3">
                      <div 
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-medium">Chapters in this act:</span>
                        <span>{actChapters.length} chapters</span>
                      </div>
                      
                      {actChapters.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {actChapters.map((chapter) => (
                            <div key={chapter.id} className="bg-gray-50 rounded-lg p-3">
                              <div className="flex items-center justify-between">
                                <h4 className="font-medium text-sm">{chapter.title}</h4>
                                <div className="flex items-center space-x-2">
                                  {chapter.content && chapter.content.length > 100 ? (
                                    <Badge className="text-xs bg-green-100 text-green-800">
                                      Complete
                                    </Badge>
                                  ) : (
                                    <Badge variant="outline" className="text-xs">
                                      Draft
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              <p className="text-xs text-gray-600 mt-1">
                                {chapter.wordCount?.toLocaleString() || 0} words
                              </p>
                              {chapter.content && (
                                <div className="flex flex-wrap gap-1 mt-2">
                                  {extractThemes(chapter.content).map((theme, themeIndex) => (
                                    <Badge key={themeIndex} variant="outline" className="text-xs">
                                      {theme}
                                    </Badge>
                                  ))}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-6 text-gray-500">
                          <BookOpen className="h-8 w-8 mx-auto mb-2 opacity-50" />
                          <p className="text-sm">No chapters assigned to this act yet</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </TabsContent>

          <TabsContent value="timeline">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Chapter Timeline</h3>
              <div className="space-y-3">
                {chapters.map((chapter, index) => {
                  const act = storyOutline.find(section => 
                    section.chapterIds.includes(chapter.id)
                  );
                  
                  return (
                    <Card key={chapter.id} className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="text-2xl font-bold text-gray-400">
                            {index + 1}
                          </div>
                          <div>
                            <h4 className="font-medium">{chapter.title}</h4>
                            <p className="text-sm text-gray-600">
                              {chapter.wordCount?.toLocaleString() || 0} words • {chapter.status}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          {act && (
                            <Badge variant="outline" className="text-xs">
                              {act.title.split(':')[0]}
                            </Badge>
                          )}
                          <div className="text-xs text-gray-500">
                            {chapter.updatedAt ? 
                              new Date(chapter.updatedAt).toLocaleDateString() : 
                              'Not started'
                            }
                          </div>
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="themes">
            <div className="space-y-6">
              <h3 className="text-lg font-semibold">Theme Analysis</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {['Trauma', 'Intimacy', 'Trust', 'Power', 'Healing', 'Confrontation'].map((theme) => {
                  const themeChapters = chapters.filter(ch => 
                    ch.content && extractThemes(ch.content).includes(theme)
                  );
                  
                  return (
                    <Card key={theme}>
                      <CardHeader>
                        <CardTitle className="text-lg">{theme}</CardTitle>
                        <CardDescription>
                          Appears in {themeChapters.length} chapters
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {themeChapters.slice(0, 5).map((chapter) => (
                            <div key={chapter.id} className="text-sm">
                              <span className="font-medium">{chapter.title}</span>
                            </div>
                          ))}
                          {themeChapters.length > 5 && (
                            <div className="text-xs text-gray-500">
                              +{themeChapters.length - 5} more chapters
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}