import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Image, Tag, Users, MapPin, Eye } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Visual, Character, Location } from "@shared/schema";

interface VisualsGalleryProps {
  projectId: number;
}

export default function VisualsGallery({ projectId }: VisualsGalleryProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedVisual, setSelectedVisual] = useState<Visual | null>(null);
  const [newVisual, setNewVisual] = useState({
    title: "",
    description: "",
    imageUrl: "",
    visualType: "",
    tags: "",
    connections: "",
    notes: ""
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);

  const { data: visuals = [], isLoading } = useQuery<Visual[]>({
    queryKey: [`/api/projects/${projectId}/visuals`],
  });

  const { data: characters = [] } = useQuery<Character[]>({
    queryKey: [`/api/projects/${projectId}/characters`],
  });

  const { data: locations = [] } = useQuery<Location[]>({
    queryKey: [`/api/projects/${projectId}/locations`],
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check file type
      const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'video/mp4', 'video/webm', 'video/mov'];
      if (!validTypes.includes(file.type)) {
        toast({
          title: "Invalid file type",
          description: "Please select an image (JPG, PNG, GIF, WebP) or video (MP4, WebM, MOV) file.",
          variant: "destructive",
        });
        return;
      }
      
      // Check file size (10MB limit)
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Please select a file smaller than 10MB.",
          variant: "destructive",
        });
        return;
      }
      
      setSelectedFile(file);
      setNewVisual(prev => ({
        ...prev,
        visualType: file.type.startsWith('image/') ? 'image' : 'video'
      }));
    }
  };

  const uploadFile = async (file: File): Promise<string> => {
    const formData = new FormData();
    formData.append('file', file);
    
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      
      xhr.upload.addEventListener('progress', (event) => {
        if (event.lengthComputable) {
          const progress = (event.loaded / event.total) * 100;
          setUploadProgress(progress);
        }
      });
      
      xhr.addEventListener('load', () => {
        if (xhr.status === 200) {
          const response = JSON.parse(xhr.responseText);
          resolve(response.url);
        } else {
          reject(new Error('Upload failed'));
        }
      });
      
      xhr.addEventListener('error', () => {
        reject(new Error('Upload failed'));
      });
      
      xhr.open('POST', '/api/upload');
      xhr.send(formData);
    });
  };

  const createVisualMutation = useMutation({
    mutationFn: async () => {
      let imageUrl = newVisual.imageUrl;
      
      // Upload file if selected
      if (selectedFile) {
        try {
          imageUrl = await uploadFile(selectedFile);
        } catch (error) {
          throw new Error('Failed to upload file');
        }
      }
      
      const tags = newVisual.tags.split(',').map(tag => tag.trim()).filter(Boolean);
      const connections = newVisual.connections ? JSON.parse(newVisual.connections) : {};
      
      return apiRequest("/api/visuals", "POST", {
        projectId,
        title: newVisual.title,
        description: newVisual.description,
        imageUrl: imageUrl,
        visualType: newVisual.visualType,
        tags,
        connections,
        notes: newVisual.notes
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/visuals`] });
      setIsCreateOpen(false);
      setNewVisual({
        title: "",
        description: "",
        imageUrl: "",
        visualType: "",
        tags: "",
        connections: "",
        notes: ""
      });
      toast({
        title: "Visual added",
        description: "Your visual has been added to the gallery.",
      });
    },
  });

  const visualTypes = [
    { value: "character_ref", label: "Character Reference", icon: Users },
    { value: "location_ref", label: "Location Reference", icon: MapPin },
    { value: "mood_board", label: "Mood Board", icon: Image },
    { value: "scene_inspiration", label: "Scene Inspiration", icon: Eye },
  ];

  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-500">Loading visuals...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-charcoal">Visuals & Art</h2>
            <p className="text-sm text-gray-500">
              Collect visual inspiration, character references, and mood boards
            </p>
          </div>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Visual
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add New Visual</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Title</label>
                    <Input
                      value={newVisual.title}
                      onChange={(e) => setNewVisual(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Visual title"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Type</label>
                    <select
                      value={newVisual.visualType}
                      onChange={(e) => setNewVisual(prev => ({ ...prev, visualType: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    >
                      <option value="">Select type</option>
                      {visualTypes.map(type => (
                        <option key={type.value} value={type.value}>{type.label}</option>
                      ))}
                    </select>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Upload File</label>
                  <div className="space-y-3">
                    <Input
                      type="file"
                      accept="image/*,video/*"
                      onChange={handleFileSelect}
                      className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                    />
                    {selectedFile && (
                      <div className="text-sm text-gray-600">
                        Selected: {selectedFile.name} ({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)
                      </div>
                    )}
                    {uploadProgress > 0 && uploadProgress < 100 && (
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${uploadProgress}%` }}
                        />
                      </div>
                    )}
                    <div className="text-center text-sm text-gray-500">OR</div>
                    <Input
                      value={newVisual.imageUrl}
                      onChange={(e) => setNewVisual(prev => ({ ...prev, imageUrl: e.target.value }))}
                      placeholder="https://example.com/image.jpg (external URL)"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Description</label>
                  <Textarea
                    value={newVisual.description}
                    onChange={(e) => setNewVisual(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Describe this visual..."
                    rows={3}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Tags (comma-separated)</label>
                  <Input
                    value={newVisual.tags}
                    onChange={(e) => setNewVisual(prev => ({ ...prev, tags: e.target.value }))}
                    placeholder="character, mood, dark, mysterious"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Notes</label>
                  <Textarea
                    value={newVisual.notes}
                    onChange={(e) => setNewVisual(prev => ({ ...prev, notes: e.target.value }))}
                    placeholder="Additional notes about this visual..."
                    rows={2}
                  />
                </div>

                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                    Cancel
                  </Button>
                  <Button
                    onClick={() => createVisualMutation.mutate()}
                    disabled={createVisualMutation.isPending || !newVisual.title}
                  >
                    Add Visual
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Gallery */}
      <div className="flex-1 p-6">
        {visuals.length === 0 ? (
          <div className="text-center py-12">
            <Image className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No visuals yet</h3>
            <p className="text-gray-500 mb-6">
              Start building your visual library with character references, mood boards, and scene inspiration.
            </p>
            <Button onClick={() => setIsCreateOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add Your First Visual
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {visuals.map((visual) => {
              const typeConfig = visualTypes.find(t => t.value === visual.visualType);
              const TypeIcon = typeConfig?.icon || Image;
              
              return (
                <Card key={visual.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  {visual.imageUrl && (
                    <div className="aspect-video bg-gray-100">
                      <img
                        src={visual.imageUrl}
                        alt={visual.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                    </div>
                  )}
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{visual.title}</CardTitle>
                      {typeConfig && (
                        <Badge variant="secondary" className="flex items-center gap-1">
                          <TypeIcon className="h-3 w-3" />
                          {typeConfig.label}
                        </Badge>
                      )}
                    </div>
                    {visual.description && (
                      <CardDescription>{visual.description}</CardDescription>
                    )}
                  </CardHeader>
                  <CardContent className="pt-0">
                    {visual.tags && Array.isArray(visual.tags) && visual.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-3">
                        {(visual.tags as string[]).map((tag: string, index: number) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            <Tag className="h-2 w-2 mr-1" />
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    )}
                    {visual.notes && (
                      <p className="text-sm text-gray-600 mt-2">{visual.notes}</p>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}