import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { MenuIcon, Download, Save, Users, MapPin, Gem, GitBranch, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import TipTapEditor from "@/lib/tiptap-config";
import CollaborativeEditor from "@/components/collaborative-editor";
import type { Chapter, Character, Location } from "@shared/schema";

interface ManuscriptEditorProps {
  projectId: number;
  selectedChapterId: number | null;
  onChapterSelect: (chapterId: number) => void;
  onReferenceClick: (type: string, id: number) => void;
}

export default function ManuscriptEditor({ 
  projectId, 
  selectedChapterId, 
  onChapterSelect,
  onReferenceClick 
}: ManuscriptEditorProps) {
  const { toast } = useToast();
  const [selectedChapter, setSelectedChapter] = useState<Chapter | null>(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [isAutoSaving, setIsAutoSaving] = useState(false);
  const [collaborativeMode, setCollaborativeMode] = useState(false);

  const { data: chapters = [] } = useQuery<Chapter[]>({
    queryKey: [`/api/projects/${projectId}/chapters`],
  });

  const { data: characters = [] } = useQuery<Character[]>({
    queryKey: [`/api/projects/${projectId}/characters`],
  });

  const { data: locations = [] } = useQuery<Location[]>({
    queryKey: [`/api/projects/${projectId}/locations`],
  });

  const { data: currentChapter } = useQuery<Chapter>({
    queryKey: [`/api/chapters/${selectedChapterId}`],
    enabled: !!selectedChapterId,
  });

  // Auto-save mutation
  const autoSaveMutation = useMutation({
    mutationFn: async (updates: { title?: string; content?: string }) => {
      if (!selectedChapter) return;
      
      const wordCount = updates.content ? updates.content.split(/\s+/).filter(word => word.length > 0).length : 0;
      
      return apiRequest("PATCH", `/api/chapters/${selectedChapter.id}`, {
        ...updates,
        wordCount,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/chapters`] });
      queryClient.invalidateQueries({ queryKey: [`/api/chapters/${selectedChapter?.id}`] });
    },
  });

  // Export mutation
  const exportMutation = useMutation({
    mutationFn: async (chapterId: number) => {
      const response = await fetch(`/api/chapters/${chapterId}/export`);
      if (!response.ok) throw new Error("Export failed");
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${selectedChapter?.title || 'chapter'}.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Chapter exported",
        description: "Your chapter has been downloaded successfully.",
      });
    },
  });

  // Create new chapter mutation
  const createChapterMutation = useMutation({
    mutationFn: async () => {
      const orderIndex = chapters.length;
      return apiRequest("POST", "/api/chapters", {
        projectId,
        title: "New Chapter",
        content: "",
        orderIndex,
        status: "draft",
      });
    },
    onSuccess: (response) => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/chapters`] });
      const newChapter = response.json();
      onChapterSelect(newChapter.id);
      toast({
        title: "Chapter created",
        description: "A new chapter has been added to your manuscript.",
      });
    },
  });

  // Load chapter data when selection changes
  useEffect(() => {
    if (currentChapter) {
      setSelectedChapter(currentChapter);
      setTitle(currentChapter.title);
      setContent(currentChapter.content || "");
    }
  }, [currentChapter]);

  // Auto-save functionality
  useEffect(() => {
    if (!selectedChapter) return;

    const timeoutId = setTimeout(() => {
      if (title !== selectedChapter.title || content !== selectedChapter.content) {
        setIsAutoSaving(true);
        autoSaveMutation.mutate({ title, content }, {
          onSettled: () => setIsAutoSaving(false),
        });
      }
    }, 2000);

    return () => clearTimeout(timeoutId);
  }, [title, content, selectedChapter]);

  const referencedElements = [
    ...characters.slice(0, 3).map(char => ({
      type: "character",
      id: char.id,
      name: char.name,
      description: char.description,
      icon: Users,
      bgColor: "bg-green-50",
      textColor: "text-success",
    })),
    ...locations.slice(0, 3).map(loc => ({
      type: "location", 
      id: loc.id,
      name: loc.name,
      description: loc.description,
      icon: MapPin,
      bgColor: "bg-blue-50",
      textColor: "text-primary",
    })),
  ];

  if (!selectedChapter && chapters.length === 0) {
    return (
      <div className="flex-1 flex flex-col">
        {/* Toolbar */}
        <div className="bg-white border-b border-gray-200 px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h2 className="font-medium text-charcoal">Welcome to your manuscript</h2>
            </div>
            <Button 
              onClick={() => createChapterMutation.mutate()}
              disabled={createChapterMutation.isPending}
            >
              Create First Chapter
            </Button>
          </div>
        </div>

        {/* Empty state */}
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center max-w-md">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <MenuIcon className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold text-charcoal mb-2">Start Writing Your Novel</h3>
            <p className="text-gray-600 mb-6">
              Create your first chapter to begin crafting your story. Your AI writing assistant will be here to help every step of the way.
            </p>
            <Button 
              onClick={() => createChapterMutation.mutate()}
              disabled={createChapterMutation.isPending}
              size="lg"
            >
              {createChapterMutation.isPending ? "Creating..." : "Create First Chapter"}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (!selectedChapter && chapters.length > 0) {
    return (
      <div className="flex-1 flex flex-col">
        {/* Toolbar */}
        <div className="bg-white border-b border-gray-200 px-6 py-3">
          <div className="flex items-center justify-between">
            <h2 className="font-medium text-charcoal">Select a chapter to edit</h2>
            <Button 
              onClick={() => createChapterMutation.mutate()}
              disabled={createChapterMutation.isPending}
            >
              Add New Chapter
            </Button>
          </div>
        </div>

        {/* Chapter list */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="max-w-4xl mx-auto space-y-4">
            {chapters.map((chapter) => (
              <Card key={chapter.id} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardContent className="p-6" onClick={() => onChapterSelect(chapter.id)}>
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold text-charcoal">{chapter.title}</h3>
                      <p className="text-sm text-gray-500 mt-1">
                        {chapter.wordCount?.toLocaleString() || 0} words • {chapter.status}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-500">
                        Last modified: {new Date(chapter.updatedAt!).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      {/* Toolbar */}
      <div className="bg-white border-b border-gray-200 px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <button className="p-2 text-gray-400 hover:text-charcoal rounded-lg hover:bg-gray-50">
                <MenuIcon className="h-4 w-4" />
              </button>
              <div className="h-6 w-px bg-gray-200"></div>
            </div>
            <div className="flex items-center space-x-2">
              <h2 className="font-medium text-charcoal">{title}</h2>
              <span className="text-sm text-gray-500">• {selectedChapter?.status}</span>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <span>{content.split(/\s+/).filter(word => word.length > 0).length} words</span>
              <span>•</span>
              <span className={isAutoSaving ? "text-amber-600" : "text-success"}>
                {isAutoSaving ? "Saving..." : "Auto-saved"}
              </span>
            </div>
            <Button
              variant={collaborativeMode ? "default" : "outline"}
              size="sm"
              onClick={() => setCollaborativeMode(!collaborativeMode)}
            >
              <UserPlus className="h-4 w-4 mr-1" />
              {collaborativeMode ? "Exit Collab" : "Collaborate"}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => selectedChapter && exportMutation.mutate(selectedChapter.id)}
              disabled={exportMutation.isPending}
            >
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
      </div>

      {/* Editor Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-6 py-8">
          {/* Chapter Header */}
          <div className="mb-8">
            <Input
              type="text"
              className="w-full text-3xl font-bold font-serif bg-transparent border-none outline-none shadow-none text-charcoal placeholder-gray-400 p-0 focus-visible:ring-0"
              placeholder="Chapter Title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
            <div className="flex items-center mt-2 space-x-4 text-sm text-gray-500">
              <span>{content.split(/\s+/).filter(word => word.length > 0).length} words</span>
              <span>Last edited {selectedChapter?.updatedAt ? new Date(selectedChapter.updatedAt).toLocaleTimeString() : 'Never'}</span>
              <div className="flex items-center space-x-1">
                <Users className="h-3 w-3" />
                <span>{referencedElements.filter(el => el.type === "character").length} characters referenced</span>
              </div>
            </div>
          </div>

          {/* Editor */}
          <div className="mb-8">
            {collaborativeMode && selectedChapterId ? (
              <CollaborativeEditor 
                chapterId={selectedChapterId}
                projectId={projectId}
              />
            ) : (
              <div className="border border-gray-200 rounded-lg min-h-[400px] focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-blue-500">
                <textarea
                  className="w-full h-full min-h-[400px] p-4 border-0 outline-none resize-none font-serif text-lg leading-relaxed"
                  placeholder="Start writing your chapter..."
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                />
              </div>
            )}
          </div>

          {/* Cross-References Panel */}
          {referencedElements.length > 0 && (
            <Card>
              <CardContent className="p-6">
                <h3 className="font-medium text-charcoal mb-4 flex items-center">
                  <Gem className="h-4 w-4 mr-2 text-primary" />
                  Referenced Elements
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {referencedElements.map((element) => (
                    <div
                      key={`${element.type}-${element.id}`}
                      className="bg-white p-3 rounded border hover:border-primary cursor-pointer transition-colors"
                      onClick={() => onReferenceClick(element.type, element.id)}
                    >
                      <div className="flex items-center space-x-2 mb-2">
                        <element.icon className={`h-4 w-4 ${element.textColor}`} />
                        <span className="font-medium text-sm capitalize">{element.type}</span>
                      </div>
                      <h4 className="font-medium text-charcoal">{element.name}</h4>
                      <p className="text-xs text-gray-500 mt-1 line-clamp-2">
                        {element.description}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
