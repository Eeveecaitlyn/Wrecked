import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { FileText, Upload, CheckCircle, XCircle, AlertCircle, Users, MapPin, BookOpen } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Character, Location, Chapter } from "@shared/schema";

interface OutlineComparisonProps {
  projectId: number;
}

interface ComparisonResult {
  type: 'character' | 'location' | 'chapter';
  name: string;
  status: 'match' | 'conflict' | 'missing_in_outline' | 'missing_in_database';
  databaseVersion?: any;
  outlineVersion?: any;
  confidence: number;
  differences?: string[];
}

export default function OutlineComparison({ projectId }: OutlineComparisonProps) {
  const { toast } = useToast();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [comparisonResults, setComparisonResults] = useState<ComparisonResult[]>([]);
  const [uploadProgress, setUploadProgress] = useState(0);

  const { data: characters = [] } = useQuery<Character[]>({
    queryKey: [`/api/projects/${projectId}/characters`],
  });

  const { data: locations = [] } = useQuery<Location[]>({
    queryKey: [`/api/projects/${projectId}/locations`],
  });

  const { data: chapters = [] } = useQuery<Chapter[]>({
    queryKey: [`/api/projects/${projectId}/chapters`],
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const validTypes = ['.txt', '.md', '.docx'];
      const fileExt = file.name.toLowerCase().slice(file.name.lastIndexOf('.'));
      
      if (!validTypes.includes(fileExt)) {
        toast({
          title: "Invalid file type",
          description: "Please select a text (.txt), markdown (.md), or Word (.docx) file.",
          variant: "destructive",
        });
        return;
      }
      
      setSelectedFile(file);
    }
  };

  const compareOutlineMutation = useMutation({
    mutationFn: async () => {
      if (!selectedFile) throw new Error("No file selected");
      
      setIsAnalyzing(true);
      setUploadProgress(0);
      
      const formData = new FormData();
      formData.append('file', selectedFile);
      formData.append('projectId', projectId.toString());
      formData.append('analysisOnly', 'true');
      
      return new Promise<any>((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        
        xhr.upload.addEventListener('progress', (event) => {
          if (event.lengthComputable) {
            const progress = (event.loaded / event.total) * 50; // Upload is 50% of progress
            setUploadProgress(progress);
          }
        });
        
        xhr.addEventListener('load', () => {
          if (xhr.status === 200) {
            setUploadProgress(75); // Analysis starts
            const response = JSON.parse(xhr.responseText);
            resolve(response);
          } else {
            reject(new Error('Upload failed'));
          }
        });
        
        xhr.addEventListener('error', () => {
          reject(new Error('Upload failed'));
        });
        
        xhr.open('POST', '/api/ai/analyze-file');
        xhr.send(formData);
      });
    },
    onSuccess: (data) => {
      setUploadProgress(90);
      
      // Compare extracted data with existing database
      const results = performComparison(data.extractedData);
      setComparisonResults(results);
      setUploadProgress(100);
      
      toast({
        title: "Comparison complete",
        description: `Found ${results.length} items to compare between outline and database.`,
      });
    },
    onError: (error) => {
      console.error('Comparison error:', error);
      toast({
        title: "Comparison failed",
        description: "Failed to analyze outline file. Please try again.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsAnalyzing(false);
    }
  });

  const performComparison = (extractedData: any): ComparisonResult[] => {
    const results: ComparisonResult[] = [];
    
    // Compare characters
    if (extractedData.characters) {
      extractedData.characters.forEach((outlineChar: any) => {
        const dbChar = characters.find(c => 
          c.name.toLowerCase() === outlineChar.name.toLowerCase()
        );
        
        if (dbChar) {
          const differences = [];
          if (dbChar.description !== outlineChar.description) {
            differences.push('Description differs');
          }
          if (dbChar.occupation !== outlineChar.occupation) {
            differences.push('Occupation differs');
          }
          
          results.push({
            type: 'character',
            name: outlineChar.name,
            status: differences.length > 0 ? 'conflict' : 'match',
            databaseVersion: dbChar,
            outlineVersion: outlineChar,
            confidence: 0.9,
            differences
          });
        } else {
          results.push({
            type: 'character',
            name: outlineChar.name,
            status: 'missing_in_database',
            outlineVersion: outlineChar,
            confidence: 0.85
          });
        }
      });
    }
    
    // Find characters in database but not in outline
    characters.forEach(dbChar => {
      const found = extractedData.characters?.find((c: any) => 
        c.name.toLowerCase() === dbChar.name.toLowerCase()
      );
      if (!found) {
        results.push({
          type: 'character',
          name: dbChar.name,
          status: 'missing_in_outline',
          databaseVersion: dbChar,
          confidence: 0.8
        });
      }
    });
    
    // Compare locations
    if (extractedData.locations) {
      extractedData.locations.forEach((outlineLoc: any) => {
        const dbLoc = locations.find(l => 
          l.name.toLowerCase() === outlineLoc.name.toLowerCase()
        );
        
        if (dbLoc) {
          const differences = [];
          if (dbLoc.description !== outlineLoc.description) {
            differences.push('Description differs');
          }
          
          results.push({
            type: 'location',
            name: outlineLoc.name,
            status: differences.length > 0 ? 'conflict' : 'match',
            databaseVersion: dbLoc,
            outlineVersion: outlineLoc,
            confidence: 0.9,
            differences
          });
        } else {
          results.push({
            type: 'location',
            name: outlineLoc.name,
            status: 'missing_in_database',
            outlineVersion: outlineLoc,
            confidence: 0.85
          });
        }
      });
    }
    
    // Find locations in database but not in outline
    locations.forEach(dbLoc => {
      const found = extractedData.locations?.find((l: any) => 
        l.name.toLowerCase() === dbLoc.name.toLowerCase()
      );
      if (!found) {
        results.push({
          type: 'location',
          name: dbLoc.name,
          status: 'missing_in_outline',
          databaseVersion: dbLoc,
          confidence: 0.8
        });
      }
    });

    return results;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'match':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'conflict':
        return <AlertCircle className="h-4 w-4 text-yellow-500" />;
      case 'missing_in_database':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'missing_in_outline':
        return <XCircle className="h-4 w-4 text-blue-500" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'match': return 'bg-green-100 text-green-800';
      case 'conflict': return 'bg-yellow-100 text-yellow-800';
      case 'missing_in_database': return 'bg-red-100 text-red-800';
      case 'missing_in_outline': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filterResults = (type: string) => 
    comparisonResults.filter(r => r.type === type);

  const stats = {
    total: comparisonResults.length,
    matches: comparisonResults.filter(r => r.status === 'match').length,
    conflicts: comparisonResults.filter(r => r.status === 'conflict').length,
    missingInDb: comparisonResults.filter(r => r.status === 'missing_in_database').length,
    missingInOutline: comparisonResults.filter(r => r.status === 'missing_in_outline').length,
  };

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Header */}
      <div className="border-b bg-card/50 backdrop-blur supports-[backdrop-filter]:bg-card/50 flex-shrink-0">
        <div className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Outline Comparison</h1>
              <p className="text-muted-foreground mt-1">
                Compare your outline with existing database content
              </p>
            </div>
          </div>
          
          {/* Upload Section */}
          <div className="mt-6 space-y-4">
            <div className="flex items-center gap-4">
              <input
                type="file"
                accept=".txt,.md,.docx"
                onChange={handleFileSelect}
                className="hidden"
                id="outline-upload"
              />
              <label htmlFor="outline-upload" className="cursor-pointer">
                <div className="flex items-center gap-2 px-4 py-2 border border-dashed border-gray-300 rounded-lg hover:border-gray-400 transition-colors">
                  <Upload className="h-4 w-4" />
                  <span>Choose outline file</span>
                </div>
              </label>
              
              {selectedFile && (
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-blue-500" />
                  <span className="text-sm">{selectedFile.name}</span>
                  <Button
                    onClick={() => compareOutlineMutation.mutate()}
                    disabled={isAnalyzing}
                    size="sm"
                  >
                    {isAnalyzing ? 'Analyzing...' : 'Compare'}
                  </Button>
                </div>
              )}
            </div>
            
            {isAnalyzing && (
              <div className="space-y-2">
                <Progress value={uploadProgress} className="w-full" />
                <p className="text-sm text-muted-foreground">
                  {uploadProgress < 50 ? 'Uploading...' : 
                   uploadProgress < 90 ? 'Analyzing content...' : 
                   'Generating comparison...'}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="flex-1 overflow-auto">
        <div className="p-6">
          {comparisonResults.length > 0 && (
            <>
              {/* Stats Overview */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold">{stats.total}</div>
                    <div className="text-sm text-muted-foreground">Total Items</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-green-600">{stats.matches}</div>
                    <div className="text-sm text-muted-foreground">Matches</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-yellow-600">{stats.conflicts}</div>
                    <div className="text-sm text-muted-foreground">Conflicts</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-red-600">{stats.missingInDb}</div>
                    <div className="text-sm text-muted-foreground">Missing in DB</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-blue-600">{stats.missingInOutline}</div>
                    <div className="text-sm text-muted-foreground">Missing in Outline</div>
                  </CardContent>
                </Card>
              </div>

              {/* Detailed Results */}
              <Tabs defaultValue="all" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="all">All ({stats.total})</TabsTrigger>
                  <TabsTrigger value="character">
                    <Users className="h-4 w-4 mr-1" />
                    Characters ({filterResults('character').length})
                  </TabsTrigger>
                  <TabsTrigger value="location">
                    <MapPin className="h-4 w-4 mr-1" />
                    Locations ({filterResults('location').length})
                  </TabsTrigger>
                  <TabsTrigger value="chapter">
                    <BookOpen className="h-4 w-4 mr-1" />
                    Chapters ({filterResults('chapter').length})
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="all" className="space-y-4">
                  {comparisonResults.map((result, index) => (
                    <ComparisonCard key={index} result={result} />
                  ))}
                </TabsContent>
                
                <TabsContent value="character" className="space-y-4">
                  {filterResults('character').map((result, index) => (
                    <ComparisonCard key={index} result={result} />
                  ))}
                </TabsContent>
                
                <TabsContent value="location" className="space-y-4">
                  {filterResults('location').map((result, index) => (
                    <ComparisonCard key={index} result={result} />
                  ))}
                </TabsContent>
                
                <TabsContent value="chapter" className="space-y-4">
                  {filterResults('chapter').map((result, index) => (
                    <ComparisonCard key={index} result={result} />
                  ))}
                </TabsContent>
              </Tabs>
            </>
          )}
          
          {comparisonResults.length === 0 && !isAnalyzing && (
            <div className="text-center py-12">
              <FileText className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No comparison yet</h3>
              <p className="text-muted-foreground mb-4">
                Upload your outline file to compare it with your existing database
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

interface ComparisonCardProps {
  result: ComparisonResult;
}

function ComparisonCard({ result }: ComparisonCardProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'match':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'conflict':
        return <AlertCircle className="h-4 w-4 text-yellow-500" />;
      case 'missing_in_database':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'missing_in_outline':
        return <XCircle className="h-4 w-4 text-blue-500" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'match': return 'bg-green-100 text-green-800';
      case 'conflict': return 'bg-yellow-100 text-yellow-800';
      case 'missing_in_database': return 'bg-red-100 text-red-800';
      case 'missing_in_outline': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'match': return 'Perfect Match';
      case 'conflict': return 'Needs Review';
      case 'missing_in_database': return 'Missing in Database';
      case 'missing_in_outline': return 'Missing in Outline';
      default: return status;
    }
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            {result.type === 'character' && <Users className="h-4 w-4" />}
            {result.type === 'location' && <MapPin className="h-4 w-4" />}
            {result.type === 'chapter' && <BookOpen className="h-4 w-4" />}
            {result.name}
          </CardTitle>
          <div className="flex items-center gap-2">
            {getStatusIcon(result.status)}
            <Badge className={getStatusColor(result.status)}>
              {getStatusText(result.status)}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {result.status === 'conflict' && result.differences && (
          <Alert className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <strong>Differences found:</strong>
              <ul className="list-disc list-inside mt-1">
                {result.differences.map((diff, idx) => (
                  <li key={idx}>{diff}</li>
                ))}
              </ul>
            </AlertDescription>
          </Alert>
        )}
        
        <div className="grid md:grid-cols-2 gap-4">
          {result.databaseVersion && (
            <div>
              <h4 className="font-medium mb-2">Database Version</h4>
              <div className="text-sm space-y-1">
                <p><strong>Description:</strong> {result.databaseVersion.description || 'No description'}</p>
                {result.databaseVersion.occupation && (
                  <p><strong>Occupation:</strong> {result.databaseVersion.occupation}</p>
                )}
              </div>
            </div>
          )}
          
          {result.outlineVersion && (
            <div>
              <h4 className="font-medium mb-2">Outline Version</h4>
              <div className="text-sm space-y-1">
                <p><strong>Description:</strong> {result.outlineVersion.description || 'No description'}</p>
                {result.outlineVersion.occupation && (
                  <p><strong>Occupation:</strong> {result.outlineVersion.occupation}</p>
                )}
              </div>
            </div>
          )}
        </div>
        
        <div className="mt-3 text-sm text-muted-foreground">
          Confidence: {Math.round(result.confidence * 100)}%
        </div>
      </CardContent>
    </Card>
  );
}