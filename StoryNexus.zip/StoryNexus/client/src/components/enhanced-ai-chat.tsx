import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Bot, User, Brain, Users, MapPin, BookOpen, Sparkles } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ChatMessage, Character, Location, Chapter } from "@shared/schema";

interface EnhancedAiChatProps {
  projectId: number;
}

export default function EnhancedAiChat({ projectId }: EnhancedAiChatProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [message, setMessage] = useState("");
  const [selectedModel, setSelectedModel] = useState("openai/gpt-4o-mini");
  const [includeContext, setIncludeContext] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: messages = [], isLoading } = useQuery<ChatMessage[]>({
    queryKey: [`/api/projects/${projectId}/chat`],
  });

  const { data: characters = [] } = useQuery<Character[]>({
    queryKey: [`/api/projects/${projectId}/characters`],
    enabled: includeContext,
  });

  const { data: locations = [] } = useQuery<Location[]>({
    queryKey: [`/api/projects/${projectId}/locations`],
    enabled: includeContext,
  });

  const { data: chapters = [] } = useQuery<Chapter[]>({
    queryKey: [`/api/projects/${projectId}/chapters`],
    enabled: includeContext,
  });

  const aiModels = [
    { value: "openai/gpt-4o-mini", label: "GPT-4o Mini (Fast & Creative)" },
    { value: "anthropic/claude-3-haiku", label: "Claude-3 Haiku (Quick Analysis)" },
    { value: "anthropic/claude-3-sonnet", label: "Claude-3 Sonnet (Balanced)" },
    { value: "meta-llama/llama-3.1-8b-instruct", label: "Llama-3.1 8B (Fast)" },
    { value: "meta-llama/llama-3.1-70b-instruct", label: "Llama-3.1 70B (Advanced)" },
    { value: "mistralai/mistral-7b-instruct", label: "Mistral-7B (Efficient)" },
    { value: "mistralai/mixtral-8x7b-instruct", label: "Mixtral 8x7B (Powerful)" },
    { value: "google/gemini-flash-1.5", label: "Gemini Flash (Google)" },
    { value: "microsoft/wizardlm-2-8x22b", label: "WizardLM-2 (Microsoft)" },
    { value: "nvidia/nemotron-4-340b-instruct", label: "Nemotron-4 340B (NVIDIA)" },
  ];

  const buildStoryContext = () => {
    if (!includeContext) return "";

    const context = [];
    
    context.push("# Wrecked - Story Context");
    context.push("A raw, emotional story about Lilah Carter and Lucas Reeves - childhood friends whose love story was shattered by trauma. When Lilah returns home after six years, they must navigate the wreckage of their past while confronting the wounds that drove them apart.");
    
    if (characters.length > 0) {
      context.push("\n## Main Characters:");
      characters.forEach(char => {
        context.push(`**${char.name}** (${char.age}): ${char.description}`);
        if (char.notes) {
          const voiceGuide = char.notes.includes("VOICE CALIBRATION") ? 
            char.notes.split("VOICE CALIBRATION")[1]?.substring(0, 200) + "..." : "";
          if (voiceGuide) context.push(`Voice: ${voiceGuide}`);
        }
      });
    }

    if (locations.length > 0) {
      context.push("\n## Key Locations:");
      locations.forEach(loc => {
        context.push(`**${loc.name}**: ${loc.description}`);
      });
    }

    if (chapters.length > 0) {
      context.push("\n## Story Structure:");
      context.push(`${chapters.length} chapters planned/written`);
      const recentChapters = chapters.slice(-3);
      recentChapters.forEach(chapter => {
        context.push(`- ${chapter.title}: ${chapter.content?.substring(0, 150)}...`);
      });
    }

    context.push("\n## Key Themes & Elements:");
    context.push("- Trauma & healing, emotional repression, unresolved love");
    context.push("- Power dynamics in intimacy, running from the past");
    context.push("- Dual first-person POV with distinct voice patterns");
    context.push("- Small town setting, shared history, second chances");

    return context.join("\n");
  };

  const sendMessageMutation = useMutation({
    mutationFn: async () => {
      const storyContext = buildStoryContext();
      const contextualMessage = includeContext ? 
        `${storyContext}\n\n---\n\nUser Question: ${message}` : message;

      return apiRequest("/api/chat", "POST", {
        projectId,
        content: contextualMessage,
        model: selectedModel,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/chat`] });
      setMessage("");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const clearChatMutation = useMutation({
    mutationFn: () => apiRequest(`/api/projects/${projectId}/chat`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/chat`] });
      toast({
        title: "Chat cleared",
        description: "All messages have been removed.",
      });
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !sendMessageMutation.isPending) {
      sendMessageMutation.mutate();
    }
  };

  const quickPrompts = [
    { text: "Help me develop this character's voice", icon: Users },
    { text: "Analyze the emotional arc of this chapter", icon: BookOpen },
    { text: "Suggest ways to increase tension in this scene", icon: Sparkles },
    { text: "Review the pacing and flow", icon: Brain },
  ];

  return (
    <div className="flex-1 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-charcoal">AI Story Assistant</h2>
            <p className="text-sm text-gray-500">
              Get writing help with full story context and character knowledge
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <label className="flex items-center space-x-2 text-sm">
              <input
                type="checkbox"
                checked={includeContext}
                onChange={(e) => setIncludeContext(e.target.checked)}
                className="rounded"
              />
              <span>Include story context</span>
            </label>
            <Button
              variant="outline"
              size="sm"
              onClick={() => clearChatMutation.mutate()}
              disabled={clearChatMutation.isPending}
            >
              Clear Chat
            </Button>
          </div>
        </div>
        
        {/* Model Selection */}
        <div className="mt-3 flex items-center space-x-3">
          <span className="text-sm font-medium">AI Model:</span>
          <select
            value={selectedModel}
            onChange={(e) => setSelectedModel(e.target.value)}
            className="text-sm border border-gray-300 rounded px-2 py-1"
          >
            {aiModels.map((model) => (
              <option key={model.value} value={model.value}>
                {model.label}
              </option>
            ))}
          </select>
          {includeContext && (
            <Badge variant="secondary" className="text-xs">
              <Brain className="h-3 w-3 mr-1" />
              Context: {characters.length}c, {locations.length}l, {chapters.length}ch
            </Badge>
          )}
        </div>
      </div>

      {/* Quick Prompts */}
      <div className="bg-gray-50 border-b border-gray-200 px-6 py-3">
        <div className="flex flex-wrap gap-2">
          {quickPrompts.map((prompt, index) => {
            const Icon = prompt.icon;
            return (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => setMessage(prompt.text)}
                className="text-xs"
              >
                <Icon className="h-3 w-3 mr-1" />
                {prompt.text}
              </Button>
            );
          })}
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-6">
        <div className="space-y-4">
          {messages.length === 0 ? (
            <div className="text-center py-8">
              <Bot className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Ready to help with your story</h3>
              <p className="text-gray-500 mb-4">
                Ask about character development, plot structure, scene analysis, or writing techniques.
                {includeContext && " I have full access to your story context."}
              </p>
              <div className="text-sm text-gray-400">
                Try asking: "How can I make Lilah's voice more authentic?" or "Analyze the tension in Chapter 10"
              </div>
            </div>
          ) : (
            messages.map((msg) => (
              <Card key={msg.id} className={`${msg.role === "user" ? "ml-12" : "mr-12"}`}>
                <CardHeader className="pb-2">
                  <div className="flex items-center space-x-2">
                    {msg.role === "user" ? (
                      <User className="h-4 w-4 text-blue-600" />
                    ) : (
                      <Bot className="h-4 w-4 text-green-600" />
                    )}
                    <span className="text-sm font-medium capitalize">{msg.role}</span>
                    {msg.modelUsed && (
                      <Badge variant="outline" className="text-xs">
                        {msg.modelUsed.split('/')[1] || msg.modelUsed}
                      </Badge>
                    )}
                    <span className="text-xs text-gray-500">
                      {msg.createdAt ? new Date(msg.createdAt).toLocaleTimeString() : ""}
                    </span>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="prose prose-sm max-w-none">
                    {msg.content.split('\n').map((line, i) => (
                      <p key={i} className="mb-2 last:mb-0">{line}</p>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="bg-white border-t border-gray-200 p-6">
        <form onSubmit={handleSubmit} className="space-y-3">
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder={includeContext ? 
              "Ask about character development, plot analysis, writing techniques... I know your full story context." :
              "Ask me anything about writing, storytelling, or creative techniques..."
            }
            rows={3}
            disabled={sendMessageMutation.isPending}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSubmit(e);
              }
            }}
          />
          <div className="flex justify-between items-center">
            <div className="text-xs text-gray-500">
              Press Enter to send, Shift+Enter for new line
            </div>
            <Button
              type="submit"
              disabled={!message.trim() || sendMessageMutation.isPending}
            >
              {sendMessageMutation.isPending ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
              ) : (
                <Send className="h-4 w-4" />
              )}
              <span className="ml-2">Send</span>
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}