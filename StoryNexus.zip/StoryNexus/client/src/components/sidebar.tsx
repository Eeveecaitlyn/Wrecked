import { useQuery } from "@tanstack/react-query";
import { Settings, Users, MapPin, Clock, Scroll, Bot, BarChart3, PenTool, Map, StickyNote, Image, Network, Shield, Lightbulb, Database, GitCompare } from "lucide-react";
import type { Project, Chapter } from "@shared/schema";

interface SidebarProps {
  project?: Project;
  currentView: string;
  onViewChange: (view: string) => void;
  onChapterSelect: (chapterId: number) => void;
}

const navigationItems = [
  {
    category: "Writing",
    items: [
      { id: "manuscript", label: "Manuscript", icon: PenTool },
      { id: "outline", label: "Story Outline", icon: Map },
      { id: "notes", label: "Research & Notes", icon: StickyNote },
      { id: "prompts", label: "Writing Prompts", icon: Lightbulb },
    ]
  },
  {
    category: "World-Building",
    items: [
      { id: "characters", label: "Characters", icon: Users },
      { id: "locations", label: "Locations", icon: MapPin },
      { id: "visuals", label: "Visuals & Art", icon: Image },
      { id: "timeline", label: "Timeline", icon: Clock },
      { id: "lore", label: "Lore Database", icon: Scroll },
      { id: "relationships", label: "Relationship Web", icon: Network },
    ]
  },
  {
    category: "AI Tools",
    items: [
      { id: "ai-chat", label: "AI Assistant", icon: Bot },
      { id: "ai-editor", label: "Database Editor", icon: Database },
      { id: "outline-comparison", label: "Outline Comparison", icon: GitCompare },
      { id: "consistency", label: "Consistency Check", icon: Shield },
      { id: "analysis", label: "Style Analysis", icon: BarChart3 },
    ]
  }
];

export default function Sidebar({ project, currentView, onViewChange, onChapterSelect }: SidebarProps) {
  const { data: chapters = [] } = useQuery<Chapter[]>({
    queryKey: [`/api/projects/${project?.id}/chapters`],
    enabled: !!project?.id,
  });

  const recentChapters = chapters.slice(-2);

  return (
    <div className="w-80 bg-white border-r border-gray-200 flex flex-col">
      {/* Project Header */}
      <div className="p-5 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h1 className="font-bold text-xl text-charcoal font-serif">NovelForge</h1>
          <button className="text-gray-400 hover:text-charcoal transition-colors">
            <Settings className="h-5 w-5" />
          </button>
        </div>
        
        {project && (
          <div className="bg-gray-50 rounded-lg p-3">
            <h2 className="font-medium text-sm text-charcoal mb-1">{project.title}</h2>
            <p className="text-xs text-gray-500">
              {project.wordCount?.toLocaleString() || 0} words • {project.chapterCount || 0} chapters
            </p>
          </div>
        )}
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 p-5 space-y-1 overflow-y-auto custom-scrollbar">
        {navigationItems.map((section) => (
          <div key={section.category} className="mb-6">
            <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-2">
              {section.category}
            </h3>
            <div className="space-y-1">
              {section.items.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onViewChange(item.id)}
                  className={`sidebar-nav-item w-full ${
                    currentView === item.id ? "active" : ""
                  }`}
                >
                  <item.icon className="mr-3 h-4 w-4" />
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        ))}
      </nav>

      {/* Recent Chapters */}
      {recentChapters.length > 0 && (
        <div className="p-5 border-t border-gray-200">
          <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-3">
            Recent Chapters
          </h3>
          <div className="space-y-2">
            {recentChapters.map((chapter) => (
              <button
                key={chapter.id}
                onClick={() => {
                  onViewChange("manuscript");
                  onChapterSelect(chapter.id);
                }}
                className="w-full flex items-center justify-between p-2 hover:bg-gray-50 rounded cursor-pointer text-left"
              >
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-charcoal truncate">
                    {chapter.title}
                  </p>
                  <p className="text-xs text-gray-500">
                    {chapter.wordCount?.toLocaleString() || 0} words
                  </p>
                </div>
                <PenTool className="h-3 w-3 text-gray-400 ml-2 flex-shrink-0" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
