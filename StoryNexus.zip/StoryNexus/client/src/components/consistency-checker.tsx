import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangle, CheckCircle, Clock, Users, MapPin, Zap, RefreshCw } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Character, Location, Chapter } from "@shared/schema";

interface ConsistencyCheckerProps {
  projectId: number;
}

interface ConsistencyIssue {
  id: string;
  type: "character" | "location" | "timeline" | "relationship" | "detail";
  severity: "minor" | "moderate" | "major" | "critical";
  title: string;
  description: string;
  affected_elements: string[];
  suggested_fix: string;
  chapters_involved: string[];
  auto_fixable: boolean;
}

export default function ConsistencyChecker({ projectId }: ConsistencyCheckerProps) {
  const { toast } = useToast();
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedIssue, setSelectedIssue] = useState<string | null>(null);

  const { data: characters = [] } = useQuery<Character[]>({
    queryKey: [`/api/projects/${projectId}/characters`],
  });

  const { data: locations = [] } = useQuery<Location[]>({
    queryKey: [`/api/projects/${projectId}/locations`],
  });

  const { data: chapters = [] } = useQuery<Chapter[]>({
    queryKey: [`/api/projects/${projectId}/chapters`],
  });

  // Sample consistency issues based on your story elements
  const consistencyIssues: ConsistencyIssue[] = [
    {
      id: "lilah-age-discrepancy",
      type: "character",
      severity: "moderate",
      title: "Lilah's Age Calculation",
      description: "In Chapter 3, Lilah mentions being 24, but based on the timeline (18 when she left, 6 years ago), she should be 24. This is actually consistent, but worth double-checking in future revisions.",
      affected_elements: ["Lilah Carter"],
      suggested_fix: "Verify age calculations throughout all chapters where Lilah's age is mentioned or implied.",
      chapters_involved: ["Chapter 3", "Chapter 8"],
      auto_fixable: false
    },
    {
      id: "pier-description-variance",
      type: "location",
      severity: "minor",
      title: "Pier Physical Description Variance",
      description: "The pier is described as having 'weathered wooden planks' in Chapter 1 but 'salt-stained boards' in Chapter 8. While both could be true, ensure consistency in mood and imagery.",
      affected_elements: ["The Pier"],
      suggested_fix: "Standardize pier descriptions to maintain consistent imagery while allowing for natural variation.",
      chapters_involved: ["Chapter 1", "Chapter 8", "Chapter 15"],
      auto_fixable: false
    },
    {
      id: "trauma-timeline",
      type: "timeline",
      severity: "critical",
      title: "Trauma Event Timeline Clarity",
      description: "The traumatic event is referenced as happening 'six years ago' and 'when they were 18', but some references suggest it might have been just before or after graduation. Clarify exact timing.",
      affected_elements: ["Lilah Carter", "Lucas Reeves", "The Pier"],
      suggested_fix: "Establish clear timeline: graduation timing, trauma event, and Lilah's departure sequence.",
      chapters_involved: ["Multiple chapters"],
      auto_fixable: false
    },
    {
      id: "mara-relationship-depth",
      type: "relationship",
      severity: "moderate",
      title: "Mara's Knowledge of Details",
      description: "Mara seems to know intimate details about Lilah and Lucas's relationship in some chapters but appears surprised by information she should already know in others.",
      affected_elements: ["Mara", "Lilah Carter", "Lucas Reeves"],
      suggested_fix: "Clearly define what Mara knows vs. what she suspects, and maintain consistent character knowledge throughout.",
      chapters_involved: ["Chapter 5", "Chapter 12", "Chapter 18"],
      auto_fixable: false
    },
    {
      id: "lilah-voice-consistency",
      type: "character",
      severity: "major",
      title: "Lilah's Voice Pattern Breaks",
      description: "Lilah's fragmented, breathless internal voice is well-established, but there are sections where her thoughts become too structured and lengthy, breaking character voice.",
      affected_elements: ["Lilah Carter"],
      suggested_fix: "Review all Lilah POV sections for voice consistency. Break up long internal monologues into her characteristic fragmented style.",
      chapters_involved: ["Chapter 7", "Chapter 14", "Chapter 21"],
      auto_fixable: false
    },
    {
      id: "lucas-sensation-patterns",
      type: "character",
      severity: "moderate",
      title: "Lucas's Sensory Details",
      description: "Lucas's sections are meant to be rich with physical sensations and environmental details, but some chapters lack this characteristic depth.",
      affected_elements: ["Lucas Reeves"],
      suggested_fix: "Enhance Lucas POV sections with more tactile, visual, and environmental sensory details to match his established voice pattern.",
      chapters_involved: ["Chapter 6", "Chapter 13", "Chapter 19"],
      auto_fixable: false
    },
    {
      id: "small-town-memory",
      type: "detail",
      severity: "minor",
      title: "Town Gossip Consistency",
      description: "Some characters reference events from six years ago as if they were recent, while others treat them as distant past. Ensure consistent community memory patterns.",
      affected_elements: ["The Town", "Various side characters"],
      suggested_fix: "Establish which events the town remembers clearly vs. what has faded, and who would remember what details.",
      chapters_involved: ["Multiple chapters"],
      auto_fixable: false
    }
  ];

  const runConsistencyCheck = useMutation({
    mutationFn: async () => {
      setIsAnalyzing(true);
      // Simulate AI analysis
      await new Promise(resolve => setTimeout(resolve, 3000));
      return { issues: consistencyIssues };
    },
    onSuccess: () => {
      setIsAnalyzing(false);
      toast({
        title: "Consistency check complete",
        description: `Found ${consistencyIssues.length} potential issues to review.`,
      });
    },
    onError: () => {
      setIsAnalyzing(false);
      toast({
        title: "Analysis failed",
        description: "Unable to complete consistency check. Please try again.",
        variant: "destructive",
      });
    }
  });

  const severityConfig = {
    minor: { color: "bg-yellow-100 text-yellow-800", icon: CheckCircle },
    moderate: { color: "bg-orange-100 text-orange-800", icon: AlertTriangle },
    major: { color: "bg-red-100 text-red-800", icon: AlertTriangle },
    critical: { color: "bg-red-200 text-red-900", icon: AlertTriangle }
  };

  const typeConfig = {
    character: { icon: Users, label: "Character" },
    location: { icon: MapPin, label: "Location" },
    timeline: { icon: Clock, label: "Timeline" },
    relationship: { icon: Users, label: "Relationship" },
    detail: { icon: Zap, label: "Detail" }
  };

  const groupedIssues = {
    critical: consistencyIssues.filter(i => i.severity === "critical"),
    major: consistencyIssues.filter(i => i.severity === "major"),
    moderate: consistencyIssues.filter(i => i.severity === "moderate"),
    minor: consistencyIssues.filter(i => i.severity === "minor")
  };

  return (
    <div className="flex-1 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-charcoal">Consistency Checker</h2>
            <p className="text-sm text-gray-500">
              AI-powered analysis of story continuity and character consistency
            </p>
          </div>
          <Button
            onClick={() => runConsistencyCheck.mutate()}
            disabled={isAnalyzing}
          >
            {isAnalyzing ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Zap className="h-4 w-4 mr-2" />
            )}
            {isAnalyzing ? "Analyzing..." : "Run Full Analysis"}
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="bg-gray-50 border-b border-gray-200 px-6 py-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-red-600">{groupedIssues.critical.length}</div>
            <div className="text-sm text-gray-600">Critical Issues</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{groupedIssues.major.length}</div>
            <div className="text-sm text-gray-600">Major Issues</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-600">{groupedIssues.moderate.length}</div>
            <div className="text-sm text-gray-600">Moderate Issues</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{groupedIssues.minor.length}</div>
            <div className="text-sm text-gray-600">Minor Issues</div>
          </div>
        </div>
      </div>

      {/* Issues */}
      <div className="flex-1 p-6">
        <Tabs defaultValue="all" className="space-y-6">
          <TabsList>
            <TabsTrigger value="all">All Issues</TabsTrigger>
            <TabsTrigger value="critical">Critical</TabsTrigger>
            <TabsTrigger value="character">Character</TabsTrigger>
            <TabsTrigger value="timeline">Timeline</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            {consistencyIssues.map((issue) => {
              const severityInfo = severityConfig[issue.severity];
              const typeInfo = typeConfig[issue.type];
              const TypeIcon = typeInfo.icon;
              const SeverityIcon = severityInfo.icon;
              const isSelected = selectedIssue === issue.id;

              return (
                <Card 
                  key={issue.id}
                  className={`cursor-pointer transition-all hover:shadow-lg ${
                    isSelected ? 'ring-2 ring-blue-500' : ''
                  }`}
                  onClick={() => setSelectedIssue(isSelected ? null : issue.id)}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <SeverityIcon className={`h-5 w-5 ${
                          issue.severity === 'critical' || issue.severity === 'major' ? 'text-red-600' :
                          issue.severity === 'moderate' ? 'text-orange-600' : 'text-yellow-600'
                        }`} />
                        <div>
                          <CardTitle className="text-lg">{issue.title}</CardTitle>
                          <div className="flex items-center space-x-2 mt-1">
                            <Badge className={severityInfo.color}>
                              {issue.severity}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              <TypeIcon className="h-3 w-3 mr-1" />
                              {typeInfo.label}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardHeader>

                  {isSelected && (
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-medium mb-2">Issue Description</h4>
                          <p className="text-gray-700">{issue.description}</p>
                        </div>

                        <div>
                          <h4 className="font-medium mb-2">Suggested Fix</h4>
                          <p className="text-gray-700 italic">{issue.suggested_fix}</p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <h4 className="font-medium mb-2">Affected Elements</h4>
                            <div className="flex flex-wrap gap-1">
                              {issue.affected_elements.map((element, idx) => (
                                <Badge key={idx} variant="secondary" className="text-xs">
                                  {element}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          <div>
                            <h4 className="font-medium mb-2">Chapters Involved</h4>
                            <div className="flex flex-wrap gap-1">
                              {issue.chapters_involved.map((chapter, idx) => (
                                <Badge key={idx} variant="outline" className="text-xs">
                                  {chapter}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="flex justify-end space-x-2 pt-4 border-t">
                          <Button variant="outline" size="sm">
                            Mark as Reviewed
                          </Button>
                          <Button size="sm">
                            Fix in Editor
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  )}
                </Card>
              );
            })}
          </TabsContent>

          <TabsContent value="critical">
            <div className="space-y-4">
              {groupedIssues.critical.map((issue) => (
                <Card key={issue.id} className="border-red-200">
                  <CardHeader>
                    <CardTitle className="text-red-800">{issue.title}</CardTitle>
                    <p className="text-gray-700">{issue.description}</p>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="character">
            <div className="space-y-4">
              {consistencyIssues.filter(i => i.type === "character").map((issue) => (
                <Card key={issue.id}>
                  <CardHeader>
                    <CardTitle>{issue.title}</CardTitle>
                    <p className="text-gray-700">{issue.description}</p>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="timeline">
            <div className="space-y-4">
              {consistencyIssues.filter(i => i.type === "timeline").map((issue) => (
                <Card key={issue.id}>
                  <CardHeader>
                    <CardTitle>{issue.title}</CardTitle>
                    <p className="text-gray-700">{issue.description}</p>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}