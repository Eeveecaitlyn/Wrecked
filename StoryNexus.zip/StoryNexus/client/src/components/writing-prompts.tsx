import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Lightbulb, Shuffle, Heart, Users, Zap, Brain, Clock, Search, Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Character, Location } from "@shared/schema";

interface WritingPromptsProps {
  projectId: number;
}

interface WritingPrompt {
  id: string;
  title: string;
  prompt: string;
  category: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  type: "character" | "plot" | "scene" | "dialogue" | "worldbuilding" | "conflict" | "emotion" | "general";
  tags: string[];
  story_specific?: boolean;
}

export default function WritingPrompts({ projectId }: WritingPromptsProps) {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [randomPrompt, setRandomPrompt] = useState<WritingPrompt | null>(null);

  const { data: characters = [] } = useQuery<Character[]>({
    queryKey: [`/api/projects/${projectId}/characters`],
  });

  const { data: locations = [] } = useQuery<Location[]>({
    queryKey: [`/api/projects/${projectId}/locations`],
  });

  const writingPrompts: WritingPrompt[] = [
    // Story-specific prompts for "Wrecked"
    {
      id: "lilah-pier-memory",
      title: "Lilah's Pier Memory",
      prompt: "Write a scene where Lilah stands at the pier and remembers a specific moment from her childhood with Lucas. Focus on sensory details that trigger the memory and how her body responds to being back in this space.",
      category: "Character Development",
      difficulty: "intermediate",
      type: "scene",
      tags: ["memory", "trauma", "sensory", "pier"],
      story_specific: true
    },
    {
      id: "lucas-waiting",
      title: "Lucas's Six Years",
      prompt: "Explore a scene from Lucas's perspective during the six years Lilah was gone. Show how he's changed, what he's built, and what he's destroyed in her absence. Use his characteristic focus on physical sensations.",
      category: "Character Development",
      difficulty: "advanced",
      type: "character",
      tags: ["backstory", "growth", "loneliness", "healing"],
      story_specific: true
    },
    {
      id: "mara-perspective",
      title: "Mara's Dilemma",
      prompt: "Write from Mara's point of view as she watches Lilah and Lucas navigate their reunion. What does she see that they don't? What does she know that she's not saying?",
      category: "Supporting Characters",
      difficulty: "intermediate",
      type: "character",
      tags: ["friendship", "observation", "secrets", "loyalty"],
      story_specific: true
    },
    {
      id: "town-gossip",
      title: "The Town Remembers",
      prompt: "Create a scene where two townspeople discuss Lilah's return. Reveal information about the past through gossip, showing how the town's memory works and what versions of the truth survive.",
      category: "Worldbuilding",
      difficulty: "beginner",
      type: "dialogue",
      tags: ["gossip", "community", "past", "perspective"],
      story_specific: true
    },
    {
      id: "carter-house-secrets",
      title: "Carter House Memories",
      prompt: "Lilah explores her childhood home and finds something that triggers a specific memory. Write the discovery and the memory it unlocks, showing how physical objects can hold emotional weight.",
      category: "Setting & Atmosphere",
      difficulty: "intermediate",
      type: "scene",
      tags: ["home", "memory", "objects", "nostalgia"],
      story_specific: true
    },

    // General writing prompts
    {
      id: "dialogue-subtext",
      title: "What They Don't Say",
      prompt: "Write a dialogue scene where two characters are discussing something mundane (weather, work, food) but the subtext reveals a deep emotional conflict between them. Show tension through what's NOT said.",
      category: "Dialogue Mastery",
      difficulty: "advanced",
      type: "dialogue",
      tags: ["subtext", "tension", "conflict", "communication"]
    },
    {
      id: "sensory-overload",
      title: "Five Senses Scene",
      prompt: "Write a scene that intensely engages all five senses. Place your character in a specific environment and use sensory details to convey their emotional state without directly stating it.",
      category: "Descriptive Writing",
      difficulty: "intermediate",
      type: "scene",
      tags: ["senses", "description", "emotion", "environment"]
    },
    {
      id: "character-fear",
      title: "Facing the Fear",
      prompt: "Write about a character confronting their deepest fear. Don't just show the fear - show how their body reacts, what thoughts race through their mind, and how they find (or don't find) courage.",
      category: "Character Development",
      difficulty: "advanced",
      type: "character",
      tags: ["fear", "courage", "psychology", "growth"]
    },
    {
      id: "memory-trigger",
      title: "Triggered Memory",
      prompt: "A character encounters something (a smell, song, object, person) that instantly transports them to a pivotal moment from their past. Write both the present moment and the memory it triggers.",
      category: "Character Development",
      difficulty: "intermediate",
      type: "character",
      tags: ["memory", "past", "triggers", "emotion"]
    },
    {
      id: "power-dynamics",
      title: "Shifting Power",
      prompt: "Write a scene where the power dynamic between two characters shifts. Start with one character in control and end with the other holding the power. Show this change through body language, dialogue, and action.",
      category: "Conflict & Tension",
      difficulty: "advanced",
      type: "scene",
      tags: ["power", "dynamics", "control", "shift"]
    },
    {
      id: "internal-external",
      title: "Inner vs Outer Storm",
      prompt: "Write a scene where a character's internal emotional state is reflected in the external environment (weather, setting, atmosphere). Make the environment almost a character itself.",
      category: "Setting & Atmosphere",
      difficulty: "intermediate",
      type: "scene",
      tags: ["environment", "emotion", "atmosphere", "reflection"]
    },
    {
      id: "secret-revealed",
      title: "The Secret Emerges",
      prompt: "A character reveals a secret they've been keeping. Focus on the moments leading up to the revelation - the internal struggle, the decision point, and the immediate aftermath.",
      category: "Plot Development",
      difficulty: "intermediate",
      type: "plot",
      tags: ["secrets", "revelation", "truth", "decision"]
    },
    {
      id: "body-language",
      title: "Silent Communication",
      prompt: "Write a scene where two characters communicate primarily through body language and micro-expressions. Use minimal dialogue but maximum physical awareness between them.",
      category: "Character Interaction",
      difficulty: "advanced",
      type: "scene",
      tags: ["body language", "communication", "awareness", "tension"]
    },
    {
      id: "childhood-echo",
      title: "Childhood Echoes",
      prompt: "Write a scene where an adult character's current behavior is influenced by a childhood experience. Show how the past lives in the present without flashbacks - just echoes.",
      category: "Character Development",
      difficulty: "advanced",
      type: "character",
      tags: ["childhood", "influence", "behavior", "past"]
    },
    {
      id: "healing-moment",
      title: "Small Healing",
      prompt: "Write about a tiny moment of healing - not a grand revelation, but a small step forward. Show how healing happens in increments, in moments so small they're almost missable.",
      category: "Emotional Journey",
      difficulty: "intermediate",
      type: "emotion",
      tags: ["healing", "progress", "small moments", "growth"]
    },
    {
      id: "place-memory",
      title: "Memory in a Place",
      prompt: "A character returns to a significant location from their past. Write about how the place has changed, how they've changed, and what remains the same. Let the setting tell part of the story.",
      category: "Setting & Memory",
      difficulty: "intermediate",
      type: "worldbuilding",
      tags: ["place", "memory", "change", "time"]
    },
    {
      id: "trust-building",
      title: "Building Trust",
      prompt: "Write a scene where two characters take a small step toward trusting each other. Focus on the vulnerability, the risk, and the tiny gestures that build bridges between people.",
      category: "Relationship Dynamics",
      difficulty: "intermediate",
      type: "emotion",
      tags: ["trust", "vulnerability", "relationships", "bridges"]
    },
    {
      id: "breaking-point",
      title: "At the Breaking Point",
      prompt: "Write about a character who has reached their emotional limit. Show the moment they either break or find unexpected strength. Focus on the internal experience and physical manifestations.",
      category: "Emotional Intensity",
      difficulty: "advanced",
      type: "character",
      tags: ["breaking point", "strength", "emotion", "resilience"]
    }
  ];

  const categories = [
    "Character Development",
    "Dialogue Mastery", 
    "Descriptive Writing",
    "Plot Development",
    "Setting & Atmosphere",
    "Conflict & Tension",
    "Emotional Journey",
    "Supporting Characters",
    "Worldbuilding",
    "Character Interaction",
    "Relationship Dynamics",
    "Emotional Intensity"
  ];

  const filteredPrompts = writingPrompts.filter(prompt => {
    const matchesSearch = prompt.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         prompt.prompt.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         prompt.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === "all" || prompt.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getRandomPrompt = () => {
    const randomIndex = Math.floor(Math.random() * writingPrompts.length);
    setRandomPrompt(writingPrompts[randomIndex]);
  };

  const copyPrompt = (prompt: string) => {
    navigator.clipboard.writeText(prompt);
    toast({
      title: "Prompt copied",
      description: "Writing prompt copied to clipboard.",
    });
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-green-100 text-green-800";
      case "intermediate": return "bg-yellow-100 text-yellow-800";
      case "advanced": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "character": return Users;
      case "dialogue": return Brain;
      case "scene": return Zap;
      case "emotion": return Heart;
      case "plot": return Clock;
      default: return Lightbulb;
    }
  };

  return (
    <div className="flex-1 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-charcoal">Writing Prompts</h2>
            <p className="text-sm text-gray-500">
              Comprehensive prompt database for creative inspiration and skill development
            </p>
          </div>
          <Button onClick={getRandomPrompt} className="bg-purple-600 hover:bg-purple-700">
            <Shuffle className="h-4 w-4 mr-2" />
            Random Prompt
          </Button>
        </div>
      </div>

      {/* Random Prompt Display */}
      {randomPrompt && (
        <div className="bg-purple-50 border-b border-purple-200 p-6">
          <Card className="border-purple-200">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-purple-800">{randomPrompt.title}</CardTitle>
                <div className="flex items-center space-x-2">
                  <Badge className={getDifficultyColor(randomPrompt.difficulty)}>
                    {randomPrompt.difficulty}
                  </Badge>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => copyPrompt(randomPrompt.prompt)}
                  >
                    <Copy className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-3">{randomPrompt.prompt}</p>
              <div className="flex flex-wrap gap-1">
                {randomPrompt.tags.map((tag, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters */}
      <div className="bg-gray-50 border-b border-gray-200 px-6 py-3">
        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search prompts..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md"
          >
            <option value="all">All categories</option>
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Prompt Categories */}
      <div className="flex-1 p-6">
        <Tabs defaultValue="all" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all">All Prompts</TabsTrigger>
            <TabsTrigger value="story-specific">Story-Specific</TabsTrigger>
            <TabsTrigger value="general">General Writing</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            {filteredPrompts.length === 0 ? (
              <div className="text-center py-12">
                <Lightbulb className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No matching prompts</h3>
                <p className="text-gray-500">Try adjusting your search terms or category filter.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredPrompts.map((prompt) => {
                  const TypeIcon = getTypeIcon(prompt.type);
                  
                  return (
                    <Card key={prompt.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="flex items-center space-x-2">
                            <TypeIcon className="h-5 w-5 text-blue-600" />
                            <CardTitle className="text-lg">{prompt.title}</CardTitle>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge className={getDifficultyColor(prompt.difficulty)}>
                              {prompt.difficulty}
                            </Badge>
                            {prompt.story_specific && (
                              <Badge className="bg-purple-100 text-purple-800 text-xs">
                                Wrecked
                              </Badge>
                            )}
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => copyPrompt(prompt.prompt)}
                            >
                              <Copy className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                        <Badge variant="outline" className="w-fit text-xs">
                          {prompt.category}
                        </Badge>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-700 mb-4">{prompt.prompt}</p>
                        <div className="flex flex-wrap gap-1">
                          {prompt.tags.map((tag, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          <TabsContent value="story-specific">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {writingPrompts.filter(p => p.story_specific).map((prompt) => {
                const TypeIcon = getTypeIcon(prompt.type);
                
                return (
                  <Card key={prompt.id} className="hover:shadow-lg transition-shadow border-purple-200">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-2">
                          <TypeIcon className="h-5 w-5 text-purple-600" />
                          <CardTitle className="text-lg">{prompt.title}</CardTitle>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyPrompt(prompt.prompt)}
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 mb-4">{prompt.prompt}</p>
                      <div className="flex flex-wrap gap-1">
                        {prompt.tags.map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="general">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {writingPrompts.filter(p => !p.story_specific).map((prompt) => {
                const TypeIcon = getTypeIcon(prompt.type);
                
                return (
                  <Card key={prompt.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-2">
                          <TypeIcon className="h-5 w-5 text-blue-600" />
                          <CardTitle className="text-lg">{prompt.title}</CardTitle>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={getDifficultyColor(prompt.difficulty)}>
                            {prompt.difficulty}
                          </Badge>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyPrompt(prompt.prompt)}
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 mb-4">{prompt.prompt}</p>
                      <div className="flex flex-wrap gap-1">
                        {prompt.tags.map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}