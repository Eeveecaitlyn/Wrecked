import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Bot, Edit3, Check, X, AlertCircle, Users, MapPin, BookOpen, 
  Wand2, RefreshCw, Database, MessageSquare, Upload, FileText, Eye, Save
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Character, Location, Chapter } from "@shared/schema";

interface AiDatabaseEditorProps {
  projectId: number;
}

interface SuggestionItem {
  id: string;
  type: "character" | "location" | "chapter";
  action: "update" | "create" | "merge" | "delete";
  current: any;
  suggested: any;
  reasoning: string;
  confidence: number;
}

interface EditableItem {
  id: string;
  type: "character" | "location" | "chapter" | "unknown";
  name: string;
  description: string;
  age?: string;
  notes: string;
  isCanon: boolean;
  isSelected: boolean;
  category?: string; // For unknown items to specify what they might be
}

export default function AiDatabaseEditor({ projectId }: AiDatabaseEditorProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [suggestions, setSuggestions] = useState<SuggestionItem[]>([]);
  const [customPrompt, setCustomPrompt] = useState("");
  const [selectedSuggestion, setSelectedSuggestion] = useState<SuggestionItem | null>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [fileAnalysis, setFileAnalysis] = useState<any>(null);
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [editableItems, setEditableItems] = useState<EditableItem[]>([]);
  const [isReviewMode, setIsReviewMode] = useState(false);
  const [editingItem, setEditingItem] = useState<EditableItem | null>(null);

  const { data: characters = [] } = useQuery<Character[]>({
    queryKey: [`/api/projects/${projectId}/characters`],
  });

  const { data: locations = [] } = useQuery<Location[]>({
    queryKey: [`/api/projects/${projectId}/locations`],
  });

  const { data: chapters = [] } = useQuery<Chapter[]>({
    queryKey: [`/api/projects/${projectId}/chapters`],
  });

  const analyzeDatabaseMutation = useMutation({
    mutationFn: async (prompt?: string) => {
      const response = await fetch(`/api/ai/analyze-database`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          projectId,
          characters,
          locations,
          chapters,
          customPrompt: prompt
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to analyze database');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      setSuggestions(data.suggestions || []);
      setIsAnalyzing(false);
    },
    onError: () => {
      toast({
        title: "Analysis failed",
        description: "Could not analyze database. Please try again.",
        variant: "destructive"
      });
      setIsAnalyzing(false);
    }
  });

  const applySuggestionMutation = useMutation({
    mutationFn: async (suggestion: SuggestionItem) => {
      let endpoint = "";
      let method = "POST";
      let body = suggestion.suggested;

      switch (suggestion.type) {
        case "character":
          if (suggestion.action === "update") {
            endpoint = `/api/projects/${projectId}/characters/${suggestion.current.id}`;
            method = "PATCH";
          } else if (suggestion.action === "create") {
            endpoint = `/api/projects/${projectId}/characters`;
            method = "POST";
          } else if (suggestion.action === "delete") {
            endpoint = `/api/projects/${projectId}/characters/${suggestion.current.id}`;
            method = "DELETE";
            body = null;
          }
          break;
        case "location":
          if (suggestion.action === "update") {
            endpoint = `/api/projects/${projectId}/locations/${suggestion.current.id}`;
            method = "PATCH";
          } else if (suggestion.action === "create") {
            endpoint = `/api/projects/${projectId}/locations`;
            method = "POST";
          } else if (suggestion.action === "delete") {
            endpoint = `/api/projects/${projectId}/locations/${suggestion.current.id}`;
            method = "DELETE";
            body = null;
          }
          break;
        case "chapter":
          if (suggestion.action === "update") {
            endpoint = `/api/projects/${projectId}/chapters/${suggestion.current.id}`;
            method = "PATCH";
          } else if (suggestion.action === "create") {
            endpoint = `/api/projects/${projectId}/chapters`;
            method = "POST";
          }
          break;
      }

      const response = await fetch(endpoint, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: body ? JSON.stringify(body) : undefined
      });
      
      if (!response.ok) {
        throw new Error('Failed to apply suggestion');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/characters`] });
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/locations`] });
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/chapters`] });
      toast({
        title: "Changes applied",
        description: "Database has been updated successfully."
      });
      setSuggestions(prev => prev.filter(s => s.id !== selectedSuggestion?.id));
      setSelectedSuggestion(null);
    },
    onError: () => {
      toast({
        title: "Update failed",
        description: "Could not apply changes. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleAnalyzeDatabase = () => {
    setIsAnalyzing(true);
    analyzeDatabaseMutation.mutate();
  };

  const handleCustomAnalysis = () => {
    if (!customPrompt.trim()) return;
    setIsAnalyzing(true);
    analyzeDatabaseMutation.mutate(customPrompt);
    setCustomPrompt("");
  };

  const analyzeFileMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('projectId', projectId.toString());
      formData.append('analysisOnly', 'true');
      
      const response = await fetch('/api/ai/analyze-file', {
        method: 'POST',
        body: formData
      });
      
      if (!response.ok) {
        throw new Error('Failed to analyze file');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      setFileAnalysis(data);
      setSuggestions(data.suggestions || []);
      
      // Convert suggestions to editable items for review
      const editableItemsFromSuggestions = (data.suggestions || []).map((suggestion: SuggestionItem) => ({
        id: suggestion.id,
        type: suggestion.type,
        name: suggestion.suggested.name || '',
        description: suggestion.suggested.description || '',
        age: suggestion.suggested.age || '',
        notes: suggestion.suggested.notes || '',
        isCanon: suggestion.suggested.notes?.includes('CANON') || false,
        isSelected: true, // Default to selected for review
      }));
      
      setEditableItems(editableItemsFromSuggestions);
      setIsReviewMode(true);
      setIsAnalyzing(false);
    },
    onError: () => {
      toast({
        title: "File analysis failed",
        description: "Could not analyze the uploaded file. Please try again.",
        variant: "destructive"
      });
      setIsAnalyzing(false);
    }
  });

  const handleFileUpload = (file: File) => {
    setUploadedFile(file);
    setIsAnalyzing(true);
    analyzeFileMutation.mutate(file);
  };

  // Review mode functions
  const updateEditableItem = (id: string, updates: Partial<EditableItem>) => {
    setEditableItems(prev => prev.map(item => 
      item.id === id ? { ...item, ...updates } : item
    ));
  };

  const toggleItemSelection = (id: string) => {
    setEditableItems(prev => prev.map(item => 
      item.id === id ? { ...item, isSelected: !item.isSelected } : item
    ));
  };

  const selectAllItems = () => {
    setEditableItems(prev => prev.map(item => ({ ...item, isSelected: true })));
  };

  const deselectAllItems = () => {
    setEditableItems(prev => prev.map(item => ({ ...item, isSelected: false })));
  };

  const removeItem = (id: string) => {
    setEditableItems(prev => prev.filter(item => item.id !== id));
  };

  const applySelectedItems = async () => {
    const selectedItems = editableItems.filter(item => item.isSelected);
    let successCount = 0;
    let failureCount = 0;
    
    for (const item of selectedItems) {
      try {
        // Determine what type to create based on user's classification
        let itemType = item.type;
        if (item.type === "unknown" && item.category) {
          // If user specified a category, try to map it to a known type
          const categoryLower = item.category.toLowerCase();
          if (categoryLower.includes('character') || categoryLower.includes('person') || categoryLower.includes('protagonist')) {
            itemType = "character";
          } else if (categoryLower.includes('location') || categoryLower.includes('place') || categoryLower.includes('setting')) {
            itemType = "location";
          } else if (categoryLower.includes('chapter') || categoryLower.includes('scene')) {
            itemType = "chapter";
          }
        }

        // Skip unknown items that couldn't be classified
        if (itemType === "unknown") {
          console.log(`Skipping unknown item: ${item.name} - no valid classification`);
          continue;
        }

        // Create the item directly via API
        let endpoint = "";
        let body: any = {
          projectId,
          name: item.name,
          description: item.description,
          notes: item.notes
        };

        switch (itemType) {
          case "character":
            endpoint = `/api/projects/${projectId}/characters`;
            if (item.age) body.age = item.age;
            break;
          case "location":
            endpoint = `/api/projects/${projectId}/locations`;
            break;
          case "chapter":
            endpoint = `/api/projects/${projectId}/chapters`;
            body.title = item.name;
            body.content = item.description;
            body.orderIndex = 999; // Put at end by default
            delete body.name; // Chapters use 'title' not 'name'
            break;
        }

        const response = await fetch(endpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(body)
        });
        
        if (!response.ok) {
          const errorText = await response.text();
          console.error(`Failed to create ${itemType}:`, errorText);
          failureCount++;
        } else {
          successCount++;
          console.log(`Successfully created ${itemType}: ${item.name}`);
        }
      } catch (error) {
        console.error('Failed to apply item:', item.name, error);
        failureCount++;
      }
    }
    
    // Refresh the data
    queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/characters`] });
    queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/locations`] });
    queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/chapters`] });
    
    // Reset review mode
    setIsReviewMode(false);
    setEditableItems([]);
    setSuggestions([]);
    
    toast({
      title: successCount > 0 ? "Items applied successfully" : "Application failed",
      description: `${successCount} items added to database${failureCount > 0 ? `, ${failureCount} failed` : ''}.`,
      variant: failureCount > 0 ? "destructive" : "default"
    });
  };

  const getActionColor = (action: string) => {
    switch (action) {
      case "create": return "bg-green-100 text-green-800";
      case "update": return "bg-blue-100 text-blue-800";
      case "merge": return "bg-purple-100 text-purple-800";
      case "delete": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "character": return <Users className="h-4 w-4" />;
      case "location": return <MapPin className="h-4 w-4" />;
      case "chapter": return <BookOpen className="h-4 w-4" />;
      default: return <Database className="h-4 w-4" />;
    }
  };

  return (
    <div className="flex-1 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-charcoal flex items-center">
              <Bot className="h-5 w-5 mr-2 text-blue-600" />
              AI Database Editor
            </h2>
            <p className="text-sm text-gray-500">
              Let AI analyze and suggest improvements to your story database
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload & Analyze
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Upload File for AI Analysis</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <p className="text-sm text-gray-600">
                    Upload story documents, character sheets, or reference materials. The AI will analyze the content and suggest database improvements before making any changes.
                  </p>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    {uploadedFile ? (
                      <div>
                        <FileText className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                        <p className="text-sm font-medium">{uploadedFile.name}</p>
                        <p className="text-xs text-gray-500">
                          {(uploadedFile.size / 1024).toFixed(1)} KB
                        </p>
                        {fileAnalysis && (
                          <div className="mt-3 p-3 bg-green-50 rounded-lg">
                            <p className="text-sm text-green-800">
                              Analysis complete! Found {fileAnalysis.extractedData?.characters?.length || 0} characters, 
                              {fileAnalysis.extractedData?.locations?.length || 0} locations
                            </p>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div>
                        <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-sm text-gray-600">Choose a file to analyze</p>
                        <p className="text-xs text-gray-500 mt-1">Supports .docx, .txt, and .md files</p>
                      </div>
                    )}
                    <input
                      type="file"
                      accept=".docx,.txt,.md"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleFileUpload(file);
                      }}
                      className="mt-4"
                      disabled={isAnalyzing}
                    />
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => {
                      setIsUploadDialogOpen(false);
                      setUploadedFile(null);
                      setFileAnalysis(null);
                    }}>
                      Close
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            <Button 
              onClick={handleAnalyzeDatabase}
              disabled={isAnalyzing}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Wand2 className="h-4 w-4 mr-2" />
                  Analyze Database
                </>
              )}
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 p-6">
        <Tabs defaultValue="suggestions" className="space-y-6">
          <TabsList>
            <TabsTrigger value="suggestions">AI Suggestions</TabsTrigger>
            <TabsTrigger value="file-analysis">File Analysis</TabsTrigger>
            <TabsTrigger value="custom">Custom Analysis</TabsTrigger>
            <TabsTrigger value="overview">Database Overview</TabsTrigger>
          </TabsList>

          <TabsContent value="suggestions" className="space-y-4">
            {isReviewMode ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Review Extracted Content</h3>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={selectAllItems}>
                      Select All
                    </Button>
                    <Button variant="outline" size="sm" onClick={deselectAllItems}>
                      Deselect All
                    </Button>
                    <Button 
                      onClick={applySelectedItems}
                      disabled={editableItems.filter(item => item.isSelected).length === 0}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      Apply Selected ({editableItems.filter(item => item.isSelected).length})
                    </Button>
                    <Button variant="outline" onClick={() => setIsReviewMode(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
                
                <ScrollArea className="h-96">
                  <div className="grid gap-4 pr-4">
                  {editableItems.map((item) => (
                    <Card key={item.id} className={`${item.isSelected ? 'ring-2 ring-blue-500' : ''}`}>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          <input
                            type="checkbox"
                            checked={item.isSelected}
                            onChange={() => toggleItemSelection(item.id)}
                            className="mt-1"
                          />
                          <div className="flex-1 space-y-3">
                            <div className="flex items-center gap-2">
                              {item.type === "character" && <Users className="h-4 w-4" />}
                              {item.type === "location" && <MapPin className="h-4 w-4" />}
                              {item.type === "chapter" && <BookOpen className="h-4 w-4" />}
                              {item.type === "unknown" && <AlertCircle className="h-4 w-4" />}
                              <Badge variant={item.isCanon ? "default" : item.type === "unknown" ? "destructive" : "secondary"}>
                                {item.isCanon ? "CANON" : item.type === "unknown" ? "UNKNOWN" : item.type}
                              </Badge>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setEditingItem(item)}
                              >
                                <Edit3 className="h-3 w-3" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeItem(item.id)}
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            </div>
                            
                            <div>
                              <Label className="text-sm font-medium">Name</Label>
                              <Input
                                value={item.name}
                                onChange={(e) => updateEditableItem(item.id, { name: e.target.value })}
                                className="mt-1"
                              />
                            </div>
                            
                            <div>
                              <Label className="text-sm font-medium">Description</Label>
                              <Textarea
                                value={item.description}
                                onChange={(e) => updateEditableItem(item.id, { description: e.target.value })}
                                className="mt-1"
                                rows={2}
                              />
                            </div>
                            
                            {item.type === "character" && (
                              <div>
                                <Label className="text-sm font-medium">Age</Label>
                                <Input
                                  value={item.age || ''}
                                  onChange={(e) => updateEditableItem(item.id, { age: e.target.value })}
                                  className="mt-1"
                                  placeholder="Optional"
                                />
                              </div>
                            )}
                            
                            {item.type === "unknown" && (
                              <div>
                                <Label className="text-sm font-medium">Category (What might this be?)</Label>
                                <Input
                                  value={item.category || ''}
                                  onChange={(e) => updateEditableItem(item.id, { category: e.target.value })}
                                  className="mt-1"
                                  placeholder="e.g., theme, motif, relationship, event, object..."
                                />
                              </div>
                            )}
                            
                            <div>
                              <Label className="text-sm font-medium">Notes</Label>
                              <Textarea
                                value={item.notes}
                                onChange={(e) => updateEditableItem(item.id, { notes: e.target.value })}
                                className="mt-1"
                                rows={1}
                              />
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  </div>
                </ScrollArea>
              </div>
            ) : suggestions.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <Bot className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No suggestions yet</h3>
                  <p className="text-gray-500 mb-4">
                    Upload files or analyze your database to get suggestions for improvement
                  </p>
                  <Button onClick={handleAnalyzeDatabase} disabled={isAnalyzing}>
                    {isAnalyzing ? "Analyzing..." : "Start Analysis"}
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {suggestions.map((suggestion) => (
                  <Card key={suggestion.id} className="overflow-hidden">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          {getTypeIcon(suggestion.type)}
                          <div>
                            <CardTitle className="text-base">
                              {suggestion.action === "create" ? "Create" :
                               suggestion.action === "update" ? "Update" :
                               suggestion.action === "merge" ? "Merge" : "Delete"} {suggestion.type}
                            </CardTitle>
                            <CardDescription>
                              {suggestion.current?.name || suggestion.suggested?.name || "New item"}
                            </CardDescription>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={getActionColor(suggestion.action)}>
                            {suggestion.action}
                          </Badge>
                          <Badge variant="outline">
                            {Math.round(suggestion.confidence * 100)}% confident
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <p className="text-sm text-gray-600">{suggestion.reasoning}</p>
                        
                        {suggestion.action !== "delete" && (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {suggestion.current && (
                              <div>
                                <h4 className="text-sm font-medium text-gray-700 mb-2">Current</h4>
                                <div className="bg-gray-50 rounded-lg p-3 text-sm">
                                  <div><strong>Name:</strong> {suggestion.current.name}</div>
                                  <div><strong>Description:</strong> {suggestion.current.description || "None"}</div>
                                  {suggestion.current.age && <div><strong>Age:</strong> {suggestion.current.age}</div>}
                                </div>
                              </div>
                            )}
                            <div>
                              <h4 className="text-sm font-medium text-gray-700 mb-2">Suggested</h4>
                              <div className="bg-blue-50 rounded-lg p-3 text-sm">
                                <div><strong>Name:</strong> {suggestion.suggested.name}</div>
                                <div><strong>Description:</strong> {suggestion.suggested.description || "None"}</div>
                                {suggestion.suggested.age && <div><strong>Age:</strong> {suggestion.suggested.age}</div>}
                              </div>
                            </div>
                          </div>
                        )}

                        <div className="flex justify-end space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSuggestions(prev => prev.filter(s => s.id !== suggestion.id))}
                          >
                            <X className="h-4 w-4 mr-1" />
                            Dismiss
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => {
                              setSelectedSuggestion(suggestion);
                              applySuggestionMutation.mutate(suggestion);
                            }}
                            disabled={applySuggestionMutation.isPending}
                          >
                            <Check className="h-4 w-4 mr-1" />
                            Apply
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="file-analysis" className="space-y-4">
            {!fileAnalysis ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No file analyzed yet</h3>
                  <p className="text-gray-500 mb-4">
                    Upload a story document to see AI analysis and suggestions before integrating into your database
                  </p>
                  <Button onClick={() => setIsUploadDialogOpen(true)}>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload File
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <FileText className="h-5 w-5 mr-2" />
                      File Analysis Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">{fileAnalysis.analysis?.charactersFound || 0}</div>
                        <div className="text-sm text-gray-500">Characters Found</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">{fileAnalysis.analysis?.locationsFound || 0}</div>
                        <div className="text-sm text-gray-500">Locations Found</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-amber-600">{fileAnalysis.analysis?.conflictsDetected || 0}</div>
                        <div className="text-sm text-gray-500">Conflicts Detected</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-600">{fileAnalysis.analysis?.newItemsFound || 0}</div>
                        <div className="text-sm text-gray-500">New Items</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Users className="h-5 w-5 mr-2" />
                        Characters in File
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-64">
                        <div className="space-y-3">
                          {fileAnalysis.extractedData?.characters?.map((char: any, index: number) => (
                            <div key={index} className="border rounded-lg p-3">
                              <div className="font-medium">{char.name}</div>
                              <div className="text-sm text-gray-600 mt-1">{char.description}</div>
                              {char.age && <div className="text-xs text-gray-500 mt-1">Age: {char.age}</div>}
                            </div>
                          )) || []}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <MapPin className="h-5 w-5 mr-2" />
                        Locations in File
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-64">
                        <div className="space-y-3">
                          {fileAnalysis.extractedData?.locations?.map((loc: any, index: number) => (
                            <div key={index} className="border rounded-lg p-3">
                              <div className="font-medium">{loc.name}</div>
                              <div className="text-sm text-gray-600 mt-1">{loc.description}</div>
                            </div>
                          )) || []}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>Integration Preview</CardTitle>
                    <CardDescription>
                      Review these suggestions before applying changes to your database
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between mb-4">
                      <div className="text-sm text-gray-600">
                        {suggestions.filter(s => s.action === "create").length} new items, 
                        {suggestions.filter(s => s.action === "update").length} updates suggested
                      </div>
                      <Button 
                        size="sm"
                        onClick={() => {
                          // Apply all file suggestions
                          suggestions.forEach(suggestion => {
                            applySuggestionMutation.mutate(suggestion);
                          });
                        }}
                        disabled={suggestions.length === 0 || applySuggestionMutation.isPending}
                      >
                        Apply All File Changes
                      </Button>
                    </div>
                    {suggestions.length === 0 ? (
                      <p className="text-center text-gray-500 py-4">
                        No conflicts or new items detected. File content matches existing database.
                      </p>
                    ) : (
                      <div className="space-y-3">
                        {suggestions.slice(0, 5).map((suggestion) => (
                          <div key={suggestion.id} className="border rounded-lg p-3 bg-gray-50">
                            <div className="flex items-center justify-between">
                              <div>
                                <div className="font-medium text-sm">
                                  {suggestion.action === "create" ? "Add" : "Update"} {suggestion.type}: {suggestion.suggested.name}
                                </div>
                                <div className="text-xs text-gray-600">{suggestion.reasoning}</div>
                              </div>
                              <Badge className={getActionColor(suggestion.action)}>
                                {suggestion.action}
                              </Badge>
                            </div>
                          </div>
                        ))}
                        {suggestions.length > 5 && (
                          <div className="text-center text-sm text-gray-500">
                            +{suggestions.length - 5} more suggestions available in the AI Suggestions tab
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="custom" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageSquare className="h-5 w-5 mr-2" />
                  Custom Analysis Request
                </CardTitle>
                <CardDescription>
                  Describe what you'd like the AI to help you fix or organize in your database
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder="For example: 'Fix character ages to be consistent with the timeline' or 'Merge duplicate locations' or 'Update character descriptions to match their story arcs'"
                  value={customPrompt}
                  onChange={(e) => setCustomPrompt(e.target.value)}
                  className="min-h-[100px]"
                />
                <Button 
                  onClick={handleCustomAnalysis}
                  disabled={!customPrompt.trim() || isAnalyzing}
                  className="w-full"
                >
                  {isAnalyzing ? "Analyzing..." : "Analyze & Suggest"}
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Common Issues to Check</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {[
                    "Fix inconsistent character ages",
                    "Merge duplicate characters",
                    "Update character relationships",
                    "Fix location descriptions",
                    "Organize chapter progression",
                    "Update character development arcs"
                  ].map((suggestion, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      onClick={() => setCustomPrompt(suggestion)}
                      className="justify-start text-left"
                    >
                      {suggestion}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="h-5 w-5 mr-2" />
                    Characters
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">{characters.length}</div>
                  <div className="text-sm text-gray-500">
                    {characters.filter(c => c.description && c.description.length > 50).length} with detailed descriptions
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <MapPin className="h-5 w-5 mr-2" />
                    Locations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{locations.length}</div>
                  <div className="text-sm text-gray-500">
                    {locations.filter(l => l.description && l.description.length > 50).length} with detailed descriptions
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BookOpen className="h-5 w-5 mr-2" />
                    Chapters
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-600">{chapters.length}</div>
                  <div className="text-sm text-gray-500">
                    {chapters.filter(c => c.content && c.content.length > 100).length} with content
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Potential Issues</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {characters.filter(c => !c.description || c.description.length < 20).length > 0 && (
                    <div className="flex items-center space-x-2 text-amber-600">
                      <AlertCircle className="h-4 w-4" />
                      <span className="text-sm">
                        {characters.filter(c => !c.description || c.description.length < 20).length} characters need better descriptions
                      </span>
                    </div>
                  )}
                  {locations.filter(l => !l.description || l.description.length < 20).length > 0 && (
                    <div className="flex items-center space-x-2 text-amber-600">
                      <AlertCircle className="h-4 w-4" />
                      <span className="text-sm">
                        {locations.filter(l => !l.description || l.description.length < 20).length} locations need better descriptions
                      </span>
                    </div>
                  )}
                  {chapters.filter(c => !c.content || c.content.length < 100).length > 0 && (
                    <div className="flex items-center space-x-2 text-amber-600">
                      <AlertCircle className="h-4 w-4" />
                      <span className="text-sm">
                        {chapters.filter(c => !c.content || c.content.length < 100).length} chapters need content
                      </span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}