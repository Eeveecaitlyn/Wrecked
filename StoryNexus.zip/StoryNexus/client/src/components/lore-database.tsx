import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, BookOpen, Search, Tag, Link, Clock, Heart, Zap } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface LoreDatabaseProps {
  projectId: number;
}

interface LoreEntry {
  id: number;
  title: string;
  content: string;
  category: string;
  tags: string[];
  connections: { type: string; id: number; title: string }[];
  importance: "low" | "medium" | "high" | "critical";
  timeline: string;
  secrets: boolean;
  createdAt: string;
}

export default function LoreDatabase({ projectId }: LoreDatabaseProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  const [newLore, setNewLore] = useState({
    title: "",
    content: "",
    category: "worldbuilding",
    tags: "",
    importance: "medium" as const,
    timeline: "",
    secrets: false
  });

  // Mock data for demonstration - replace with actual API calls
  const loreEntries: LoreEntry[] = [
    {
      id: 1,
      title: "The Pier's Symbolic Meaning",
      content: "The pier represents the boundary between past and present, safety and risk. It's where Lilah and Lucas shared their most intimate moments before everything fell apart. The weathered wood mirrors their relationship - once strong, now showing signs of wear but still standing.",
      category: "symbolism",
      tags: ["pier", "symbolism", "past", "intimacy"],
      connections: [
        { type: "location", id: 1, title: "The Pier" },
        { type: "character", id: 1, title: "Lilah Carter" },
        { type: "character", id: 2, title: "Lucas Reeves" }
      ],
      importance: "critical",
      timeline: "Throughout story",
      secrets: false,
      createdAt: "2025-06-12"
    },
    {
      id: 2,
      title: "Trauma Response Patterns",
      content: "Lilah exhibits freeze/fawn responses - emotional shutdown and people-pleasing. Lucas shows fight/flight - aggression or complete withdrawal. These patterns were established in childhood and resurface in their adult relationship.",
      category: "psychology",
      tags: ["trauma", "psychology", "character development", "healing"],
      connections: [
        { type: "character", id: 1, title: "Lilah Carter" },
        { type: "character", id: 2, title: "Lucas Reeves" }
      ],
      importance: "critical",
      timeline: "Childhood to present",
      secrets: true,
      createdAt: "2025-06-12"
    },
    {
      id: 3,
      title: "Small Town Gossip Network",
      content: "Everyone knows everyone's business. The Carter family scandal still echoes six years later. Mrs. Henderson runs the informal information network through the grocery store. Town memory is long and forgiveness is rare.",
      category: "worldbuilding",
      tags: ["small town", "gossip", "social dynamics", "reputation"],
      connections: [
        { type: "location", id: 3, title: "The Town" },
        { type: "character", id: 3, title: "Mara" }
      ],
      importance: "high",
      timeline: "Past and present",
      secrets: false,
      createdAt: "2025-06-12"
    }
  ];

  const categories = [
    { value: "worldbuilding", label: "World Building", icon: BookOpen },
    { value: "symbolism", label: "Symbols & Themes", icon: Heart },
    { value: "psychology", label: "Character Psychology", icon: Zap },
    { value: "timeline", label: "Timeline & Events", icon: Clock },
    { value: "relationships", label: "Relationship Dynamics", icon: Link },
    { value: "secrets", label: "Plot Secrets", icon: Tag }
  ];

  const importanceLevels = [
    { value: "low", label: "Minor Detail", color: "bg-gray-100 text-gray-800" },
    { value: "medium", label: "Notable", color: "bg-blue-100 text-blue-800" },
    { value: "high", label: "Important", color: "bg-yellow-100 text-yellow-800" },
    { value: "critical", label: "Core Element", color: "bg-red-100 text-red-800" }
  ];

  const filteredEntries = loreEntries.filter(entry => {
    const matchesSearch = entry.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         entry.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         entry.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = !selectedCategory || entry.category === selectedCategory;
    const matchesTab = activeTab === "all" || 
                      (activeTab === "secrets" && entry.secrets) ||
                      (activeTab === "critical" && entry.importance === "critical");
    return matchesSearch && matchesCategory && matchesTab;
  });

  return (
    <div className="flex-1 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-charcoal">Lore Database</h2>
            <p className="text-sm text-gray-500">
              Track world building, character psychology, symbols, and story connections
            </p>
          </div>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Lore Entry
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>Create Lore Entry</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Title</label>
                    <Input
                      value={newLore.title}
                      onChange={(e) => setNewLore(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Symbolic meaning, character trait, world rule..."
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Category</label>
                    <select
                      value={newLore.category}
                      onChange={(e) => setNewLore(prev => ({ ...prev, category: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    >
                      {categories.map(cat => (
                        <option key={cat.value} value={cat.value}>{cat.label}</option>
                      ))}
                    </select>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Content</label>
                  <Textarea
                    value={newLore.content}
                    onChange={(e) => setNewLore(prev => ({ ...prev, content: e.target.value }))}
                    placeholder="Detailed explanation, significance, connections to other story elements..."
                    rows={6}
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Importance</label>
                    <select
                      value={newLore.importance}
                      onChange={(e) => setNewLore(prev => ({ ...prev, importance: e.target.value as any }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    >
                      {importanceLevels.map(level => (
                        <option key={level.value} value={level.value}>{level.label}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Timeline</label>
                    <Input
                      value={newLore.timeline}
                      onChange={(e) => setNewLore(prev => ({ ...prev, timeline: e.target.value }))}
                      placeholder="Past, Chapter 5, Throughout..."
                    />
                  </div>
                  <div className="flex items-center space-x-2 pt-6">
                    <input
                      type="checkbox"
                      id="secrets"
                      checked={newLore.secrets}
                      onChange={(e) => setNewLore(prev => ({ ...prev, secrets: e.target.checked }))}
                      className="rounded"
                    />
                    <label htmlFor="secrets" className="text-sm font-medium">Plot Secret</label>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Tags</label>
                  <Input
                    value={newLore.tags}
                    onChange={(e) => setNewLore(prev => ({ ...prev, tags: e.target.value }))}
                    placeholder="trauma, symbolism, character arc, world building"
                  />
                </div>

                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                    Cancel
                  </Button>
                  <Button
                    onClick={() => {
                      toast({
                        title: "Lore entry saved",
                        description: "Your lore has been added to the database.",
                      });
                      setIsCreateOpen(false);
                    }}
                    disabled={!newLore.title || !newLore.content}
                  >
                    Save Lore
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Filters and Tabs */}
      <div className="bg-gray-50 border-b border-gray-200 px-6 py-3">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all">All Lore</TabsTrigger>
            <TabsTrigger value="critical">Critical Elements</TabsTrigger>
            <TabsTrigger value="secrets">Plot Secrets</TabsTrigger>
          </TabsList>
        </Tabs>
        
        <div className="flex items-center gap-4 mt-3">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search lore..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md"
          >
            <option value="">All categories</option>
            {categories.map(cat => (
              <option key={cat.value} value={cat.value}>{cat.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Lore Entries */}
      <div className="flex-1 p-6">
        {filteredEntries.length === 0 ? (
          <div className="text-center py-12">
            <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {searchTerm || selectedCategory ? "No matching lore" : "No lore entries yet"}
            </h3>
            <p className="text-gray-500 mb-6">
              Start building your story's knowledge base with character psychology, world rules, and symbolic meanings.
            </p>
            {!searchTerm && !selectedCategory && (
              <Button onClick={() => setIsCreateOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create Your First Lore Entry
              </Button>
            )}
          </div>
        ) : (
          <div className="space-y-6">
            {filteredEntries.map((entry) => {
              const categoryConfig = categories.find(cat => cat.value === entry.category);
              const importanceConfig = importanceLevels.find(level => level.value === entry.importance);
              const CategoryIcon = categoryConfig?.icon || BookOpen;
              
              return (
                <Card key={entry.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-2">
                        <CategoryIcon className="h-5 w-5 text-blue-600" />
                        <CardTitle className="text-lg">{entry.title}</CardTitle>
                        {entry.secrets && (
                          <Badge variant="destructive" className="text-xs">SECRET</Badge>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge className={`text-xs ${importanceConfig?.color}`}>
                          {importanceConfig?.label}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {categoryConfig?.label}
                        </Badge>
                      </div>
                    </div>
                    {entry.timeline && (
                      <div className="flex items-center text-sm text-gray-500">
                        <Clock className="h-4 w-4 mr-1" />
                        {entry.timeline}
                      </div>
                    )}
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="mb-4 whitespace-pre-line">
                      {entry.content}
                    </CardDescription>
                    
                    {entry.connections.length > 0 && (
                      <div className="mb-4">
                        <h4 className="text-sm font-medium mb-2 flex items-center">
                          <Link className="h-4 w-4 mr-1" />
                          Connected to:
                        </h4>
                        <div className="flex flex-wrap gap-1">
                          {entry.connections.map((connection, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {connection.type}: {connection.title}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {entry.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-3">
                        {entry.tags.map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            <Tag className="h-2 w-2 mr-1" />
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    )}
                    
                    <div className="text-xs text-gray-500">
                      Added {new Date(entry.createdAt).toLocaleDateString()}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}