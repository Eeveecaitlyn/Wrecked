import { useState, useEffect, useRef, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Users, Lock, Unlock, GitBranch, Save, History, 
  Eye, AlertCircle, CheckCircle, Clock, Merge
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Chapter } from "@shared/schema";

interface CollaborativeEditorProps {
  chapterId: number;
  projectId: number;
}

interface CollaborationUser {
  id: string;
  name: string;
  color: string;
  cursor?: { line: number; column: number };
  selection?: { start: { line: number; column: number }; end: { line: number; column: number } };
  isActive: boolean;
}

interface DocumentVersion {
  id: string;
  authorId: string;
  timestamp: Date;
  commitMessage?: string;
  branchName: string;
}

export default function CollaborativeEditor({ chapterId, projectId }: CollaborativeEditorProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const wsRef = useRef<WebSocket | null>(null);
  const editorRef = useRef<HTMLTextAreaElement>(null);
  
  const [content, setContent] = useState("");
  const [isConnected, setIsConnected] = useState(false);
  const [collaborators, setCollaborators] = useState<CollaborationUser[]>([]);
  const [isLocked, setIsLocked] = useState(false);
  const [lockOwner, setLockOwner] = useState<string | null>(null);
  const [currentBranch, setCurrentBranch] = useState("main");
  const [versions, setVersions] = useState<DocumentVersion[]>([]);
  const [branches, setBranches] = useState<string[]>(["main"]);
  const [isVersionDialogOpen, setIsVersionDialogOpen] = useState(false);
  const [isBranchDialogOpen, setIsBranchDialogOpen] = useState(false);
  const [newBranchName, setNewBranchName] = useState("");
  const [commitMessage, setCommitMessage] = useState("");

  const currentUser = {
    id: "user-" + Math.random().toString(36).substr(2, 9),
    name: "You",
    color: "#3B82F6"
  };

  const { data: chapter } = useQuery<Chapter>({
    queryKey: [`/api/chapters/${chapterId}`],
  });

  useEffect(() => {
    if (chapter && !isConnected) {
      setContent(chapter.content || "");
    }
  }, [chapter, isConnected]);

  // WebSocket connection
  useEffect(() => {
    if (!chapterId) return;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${window.location.host}/collaboration`);
    wsRef.current = ws;

    ws.onopen = () => {
      setIsConnected(true);
      ws.send(JSON.stringify({
        type: 'join',
        chapterId,
        user: currentUser
      }));
    };

    ws.onmessage = (event) => {
      const message = JSON.parse(event.data);
      handleWebSocketMessage(message);
    };

    ws.onclose = () => {
      setIsConnected(false);
      toast({
        title: "Disconnected",
        description: "Lost connection to collaboration server",
        variant: "destructive"
      });
    };

    ws.onerror = () => {
      toast({
        title: "Connection Error",
        description: "Failed to connect to collaboration server",
        variant: "destructive"
      });
    };

    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close();
      }
    };
  }, [chapterId]);

  const handleWebSocketMessage = (message: any) => {
    switch (message.type) {
      case 'session_state':
        setCollaborators(message.users.filter((u: any) => u.id !== currentUser.id));
        setLockOwner(message.lockOwner);
        setIsLocked(!!message.lockOwner);
        break;

      case 'user_joined':
        if (message.user.id !== currentUser.id) {
          setCollaborators(prev => [...prev, message.user]);
          toast({
            title: "User joined",
            description: `${message.user.name} joined the session`
          });
        }
        break;

      case 'user_left':
        setCollaborators(prev => prev.filter(u => u.id !== message.userId));
        break;

      case 'document_changes':
        if (message.authorId !== currentUser.id) {
          applyChanges(message.changes);
        }
        break;

      case 'cursor_update':
        setCollaborators(prev => prev.map(user => 
          user.id === message.userId 
            ? { ...user, cursor: message.cursor, selection: message.selection }
            : user
        ));
        break;

      case 'document_locked':
        setIsLocked(true);
        setLockOwner(message.lockOwner);
        if (message.lockOwner !== currentUser.id) {
          toast({
            title: "Document locked",
            description: "Another user is editing this chapter"
          });
        }
        break;

      case 'document_unlocked':
        setIsLocked(false);
        setLockOwner(null);
        break;

      case 'version_created':
        setVersions(prev => [...prev, message.version]);
        toast({
          title: "Version saved",
          description: message.version.commitMessage || "Document version created"
        });
        break;

      case 'branch_created':
        setBranches(prev => [...prev, message.branchName]);
        break;

      case 'edit_rejected':
        toast({
          title: "Edit rejected",
          description: message.reason,
          variant: "destructive"
        });
        break;
    }
  };

  const applyChanges = (changes: any[]) => {
    // Simplified change application - in production, use operational transformation
    setContent(prevContent => {
      let newContent = prevContent;
      changes.forEach(change => {
        if (change.type === 'insert') {
          newContent = newContent.slice(0, change.position) + 
                      change.content + 
                      newContent.slice(change.position);
        } else if (change.type === 'delete') {
          newContent = newContent.slice(0, change.position) + 
                      newContent.slice(change.position + change.length);
        }
      });
      return newContent;
    });
  };

  const handleContentChange = (newContent: string) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
    
    setContent(newContent);
    
    // Send changes to other collaborators
    const changes = [{
      id: Math.random().toString(36),
      type: 'replace',
      position: 0,
      length: content.length,
      content: newContent,
      authorId: currentUser.id,
      timestamp: new Date()
    }];

    wsRef.current.send(JSON.stringify({
      type: 'edit',
      changes
    }));
  };

  const handleCursorChange = useCallback(() => {
    if (!wsRef.current || !editorRef.current) return;

    const textarea = editorRef.current;
    const position = textarea.selectionStart;
    const lines = textarea.value.substring(0, position).split('\n');
    const cursor = {
      line: lines.length - 1,
      column: lines[lines.length - 1].length
    };

    wsRef.current.send(JSON.stringify({
      type: 'cursor',
      cursor: { position: cursor }
    }));
  }, []);

  const requestLock = () => {
    if (wsRef.current) {
      wsRef.current.send(JSON.stringify({ type: 'lock' }));
    }
  };

  const releaseLock = () => {
    if (wsRef.current) {
      wsRef.current.send(JSON.stringify({ type: 'unlock' }));
    }
  };

  const createVersion = () => {
    if (wsRef.current) {
      wsRef.current.send(JSON.stringify({
        type: 'create_version',
        content,
        commitMessage
      }));
      setCommitMessage("");
    }
  };

  const createBranch = () => {
    if (wsRef.current && newBranchName.trim()) {
      wsRef.current.send(JSON.stringify({
        type: 'create_branch',
        branchName: newBranchName.trim()
      }));
      setNewBranchName("");
      setIsBranchDialogOpen(false);
    }
  };

  const saveChapter = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/chapters/${chapterId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content })
      });
      if (!response.ok) throw new Error('Failed to save');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/chapters/${chapterId}`] });
      toast({
        title: "Chapter saved",
        description: "Your changes have been saved to the database"
      });
    }
  });

  return (
    <div className="flex-1 flex flex-col">
      {/* Collaboration Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
              <span className="text-sm font-medium">
                {isConnected ? 'Connected' : 'Disconnected'}
              </span>
            </div>

            {collaborators.length > 0 && (
              <div className="flex items-center space-x-2">
                <Users className="h-4 w-4 text-gray-500" />
                <div className="flex -space-x-2">
                  {collaborators.slice(0, 3).map((user) => (
                    <div
                      key={user.id}
                      className="w-8 h-8 rounded-full border-2 border-white flex items-center justify-center text-xs font-medium text-white"
                      style={{ backgroundColor: user.color }}
                      title={user.name}
                    >
                      {user.name.charAt(0)}
                    </div>
                  ))}
                  {collaborators.length > 3 && (
                    <div className="w-8 h-8 rounded-full border-2 border-white bg-gray-500 flex items-center justify-center text-xs font-medium text-white">
                      +{collaborators.length - 3}
                    </div>
                  )}
                </div>
              </div>
            )}

            {isLocked && (
              <Badge variant={lockOwner === currentUser.id ? "default" : "destructive"}>
                <Lock className="h-3 w-3 mr-1" />
                {lockOwner === currentUser.id ? "You have lock" : "Locked by other user"}
              </Badge>
            )}
          </div>

          <div className="flex items-center space-x-2">
            <Badge variant="outline">
              <GitBranch className="h-3 w-3 mr-1" />
              {currentBranch}
            </Badge>

            {!isLocked ? (
              <Button size="sm" variant="outline" onClick={requestLock}>
                <Lock className="h-4 w-4 mr-1" />
                Request Lock
              </Button>
            ) : lockOwner === currentUser.id ? (
              <Button size="sm" variant="outline" onClick={releaseLock}>
                <Unlock className="h-4 w-4 mr-1" />
                Release Lock
              </Button>
            ) : null}

            <Dialog open={isVersionDialogOpen} onOpenChange={setIsVersionDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline">
                  <Save className="h-4 w-4 mr-1" />
                  Save Version
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Save Document Version</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Commit Message</label>
                    <Input
                      value={commitMessage}
                      onChange={(e) => setCommitMessage(e.target.value)}
                      placeholder="Describe your changes..."
                    />
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setIsVersionDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={createVersion}>
                      Save Version
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            <Dialog open={isBranchDialogOpen} onOpenChange={setIsBranchDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline">
                  <GitBranch className="h-4 w-4 mr-1" />
                  New Branch
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Branch</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Branch Name</label>
                    <Input
                      value={newBranchName}
                      onChange={(e) => setNewBranchName(e.target.value)}
                      placeholder="feature/new-ending, draft/revision-2..."
                    />
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setIsBranchDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={createBranch} disabled={!newBranchName.trim()}>
                      Create Branch
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            <Button 
              size="sm" 
              onClick={() => saveChapter.mutate()}
              disabled={saveChapter.isPending}
            >
              <Save className="h-4 w-4 mr-1" />
              Save to DB
            </Button>
          </div>
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1 relative">
        <Textarea
          ref={editorRef}
          value={content}
          onChange={(e) => handleContentChange(e.target.value)}
          onSelect={handleCursorChange}
          onKeyUp={handleCursorChange}
          className="w-full h-full resize-none border-0 focus:ring-0 text-base leading-relaxed p-6"
          placeholder="Start writing your chapter..."
          disabled={isLocked && lockOwner !== currentUser.id}
        />

        {/* Collaborator cursors would be rendered here in a production implementation */}
        {collaborators.map((user) => (
          user.cursor && (
            <div
              key={`cursor-${user.id}`}
              className="absolute pointer-events-none"
              style={{
                // Cursor positioning would be calculated based on text metrics
                left: `${user.cursor.column * 8}px`,
                top: `${user.cursor.line * 24}px`,
                borderLeft: `2px solid ${user.color}`
              }}
            >
              <div
                className="text-xs px-1 py-0.5 rounded text-white"
                style={{ backgroundColor: user.color }}
              >
                {user.name}
              </div>
            </div>
          )
        ))}
      </div>

      {/* Version History Sidebar */}
      {versions.length > 0 && (
        <div className="w-80 border-l border-gray-200 bg-gray-50">
          <div className="p-4">
            <h3 className="font-medium mb-4 flex items-center">
              <History className="h-4 w-4 mr-2" />
              Version History
            </h3>
            <ScrollArea className="h-64">
              <div className="space-y-2">
                {versions.map((version) => (
                  <Card key={version.id} className="p-3 text-sm">
                    <div className="flex items-center justify-between mb-1">
                      <Badge variant="outline" className="text-xs">
                        {version.branchName}
                      </Badge>
                      <span className="text-xs text-gray-500">
                        {new Date(version.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    {version.commitMessage && (
                      <p className="text-gray-700">{version.commitMessage}</p>
                    )}
                    <p className="text-xs text-gray-500 mt-1">
                      by {version.authorId === currentUser.id ? 'You' : version.authorId}
                    </p>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </div>
        </div>
      )}
    </div>
  );
}