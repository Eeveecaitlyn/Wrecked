import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { User, MapPin, Calendar } from "lucide-react";
import type { Character, Location } from "@shared/schema";

interface ReferenceModalProps {
  isOpen: boolean;
  type: string;
  elementId: number;
  onClose: () => void;
}

export default function ReferenceModal({ isOpen, type, elementId, onClose }: ReferenceModalProps) {
  const { data: character } = useQuery<Character>({
    queryKey: [`/api/characters/${elementId}`],
    enabled: isOpen && type === "character" && elementId > 0,
  });

  const { data: location } = useQuery<Location>({
    queryKey: [`/api/locations/${elementId}`],
    enabled: isOpen && type === "location" && elementId > 0,
  });

  const renderCharacterDetails = () => {
    if (!character) return null;

    return (
      <>
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <User className="h-5 w-5 text-success" />
            <span>Character Profile</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex items-start space-x-4">
            {character.imageUrl && (
              <img 
                src={character.imageUrl} 
                alt={character.name}
                className="w-20 h-20 rounded-lg object-cover"
              />
            )}
            <div className="flex-1">
              <h3 className="font-medium text-gray-900 text-lg">{character.name}</h3>
              <div className="flex items-center space-x-2 mb-2">
                {character.age && <Badge variant="secondary">{character.age}</Badge>}
                {character.occupation && <Badge variant="outline">{character.occupation}</Badge>}
              </div>
              {character.description && (
                <p className="text-sm text-gray-900">{character.description}</p>
              )}
            </div>
          </div>

          {(character.relationships || character.appearances || character.notes) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-gray-200">
              {character.relationships && Array.isArray(character.relationships) && character.relationships.length > 0 && (
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Relationships</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {character.relationships.map((rel: any, index: number) => (
                      <li key={index}>• {String(rel)}</li>
                    ))}
                  </ul>
                </div>
              )}

              {character.appearances && Array.isArray(character.appearances) && character.appearances.length > 0 && (
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Appearances</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {character.appearances.map((app: any, index: number) => (
                      <li key={index}>• {String(app)}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {character.notes && (
            <div className="pt-4 border-t border-gray-200">
              <h4 className="font-medium text-gray-900 mb-2">Notes</h4>
              <p className="text-sm text-gray-600 whitespace-pre-wrap">{character.notes}</p>
            </div>
          )}
        </div>
      </>
    );
  };

  const renderLocationDetails = () => {
    if (!location) return null;

    return (
      <>
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <MapPin className="h-5 w-5 text-primary" />
            <span>Location Details</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex items-start space-x-4">
            {location.imageUrl && (
              <img 
                src={location.imageUrl} 
                alt={location.name}
                className="w-20 h-20 rounded-lg object-cover"
              />
            )}
            <div className="flex-1">
              <h3 className="font-medium text-gray-900 text-lg">{location.name}</h3>
              <div className="flex items-center space-x-2 mb-2">
                {location.type && <Badge variant="secondary">{location.type}</Badge>}
              </div>
              {location.description && (
                <p className="text-sm text-charcoal">{location.description}</p>
              )}
            </div>
          </div>

          {(location.connections || location.appearances || location.notes) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-gray-200">
              {location.connections && Array.isArray(location.connections) && location.connections.length > 0 && (
                <div>
                  <h4 className="font-medium text-charcoal mb-2">Connected Locations</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {location.connections.map((conn: any, index: number) => (
                      <li key={index}>• {conn}</li>
                    ))}
                  </ul>
                </div>
              )}

              {location.appearances && Array.isArray(location.appearances) && location.appearances.length > 0 && (
                <div>
                  <h4 className="font-medium text-charcoal mb-2">Appearances</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {location.appearances.map((app: any, index: number) => (
                      <li key={index}>• {app}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {location.notes && (
            <div className="pt-4 border-t border-gray-200">
              <h4 className="font-medium text-charcoal mb-2">Notes</h4>
              <p className="text-sm text-gray-600 whitespace-pre-wrap">{location.notes}</p>
            </div>
          )}
        </div>
      </>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-96 overflow-y-auto">
        {type === "character" && renderCharacterDetails()}
        {type === "location" && renderLocationDetails()}
        {!character && !location && isOpen && (
          <div className="text-center py-8">
            <p className="text-gray-500">Loading reference details...</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
