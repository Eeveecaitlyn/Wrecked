import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, Users, MapPin, BookOpen, Heart, ArrowRight } from "lucide-react";
import type { Character, Location, Chapter } from "@shared/schema";

interface InteractiveTimelineProps {
  projectId: number;
}

interface TimelineEvent {
  id: string;
  title: string;
  description: string;
  timeframe: string;
  type: "past" | "chapter" | "relationship" | "trauma" | "healing";
  characters: string[];
  locations: string[];
  importance: "low" | "medium" | "high" | "critical";
  emotional_weight: number; // 1-10 scale
  chapter_reference?: string;
}

export default function InteractiveTimeline({ projectId }: InteractiveTimelineProps) {
  const [selectedFilter, setSelectedFilter] = useState("all");
  const [selectedEvent, setSelectedEvent] = useState<string | null>(null);

  const { data: characters = [] } = useQuery<Character[]>({
    queryKey: [`/api/projects/${projectId}/characters`],
  });

  const { data: locations = [] } = useQuery<Location[]>({
    queryKey: [`/api/projects/${projectId}/locations`],
  });

  const { data: chapters = [] } = useQuery<Chapter[]>({
    queryKey: [`/api/projects/${projectId}/chapters`],
  });

  // Timeline events based on your story
  const timelineEvents: TimelineEvent[] = [
    {
      id: "childhood-bond",
      title: "Childhood Friendship Begins",
      description: "Lilah and Lucas meet as children and form an inseparable bond. Their friendship becomes the foundation for everything that follows.",
      timeframe: "Age 8-12",
      type: "past",
      characters: ["Lilah Carter", "Lucas Reeves"],
      locations: ["The Town", "The Pier"],
      importance: "critical",
      emotional_weight: 8,
    },
    {
      id: "teenage-romance",
      title: "First Love Emerges",
      description: "Their childhood friendship evolves into first love. Intense, passionate, and all-consuming. They share their deepest secrets and dreams.",
      timeframe: "Age 16-18",
      type: "relationship",
      characters: ["Lilah Carter", "Lucas Reeves"],
      locations: ["The Pier", "Carter House"],
      importance: "critical",
      emotional_weight: 9,
    },
    {
      id: "the-trauma",
      title: "The Breaking Point",
      description: "The traumatic event that shatters everything. Details deliberately kept vague here to avoid spoilers, but this is the wound that never healed.",
      timeframe: "Age 18",
      type: "trauma",
      characters: ["Lilah Carter", "Lucas Reeves"],
      locations: ["The Pier"],
      importance: "critical",
      emotional_weight: 10,
    },
    {
      id: "the-leaving",
      title: "Lilah's Escape",
      description: "Unable to face the aftermath, Lilah leaves town without a word. Lucas is left behind to deal with the wreckage alone.",
      timeframe: "6 years ago",
      type: "past",
      characters: ["Lilah Carter", "Lucas Reeves"],
      locations: ["The Town"],
      importance: "critical",
      emotional_weight: 9,
    },
    {
      id: "six-years-apart",
      title: "Years of Separation",
      description: "Both struggle with their own healing journeys. Lilah builds walls, Lucas becomes hardened. Neither fully moves on.",
      timeframe: "Past 6 years",
      type: "healing",
      characters: ["Lilah Carter", "Lucas Reeves"],
      locations: [],
      importance: "high",
      emotional_weight: 7,
    },
    {
      id: "return-home",
      title: "Lilah Returns",
      description: "Circumstances force Lilah back to town. The confrontation she's been avoiding for six years can no longer be delayed.",
      timeframe: "Present - Chapter 1",
      type: "chapter",
      characters: ["Lilah Carter"],
      locations: ["The Town", "Carter House"],
      importance: "critical",
      emotional_weight: 8,
      chapter_reference: "Chapter 1"
    },
    {
      id: "first-encounter",
      title: "The First Look",
      description: "Lilah and Lucas see each other for the first time in six years. All the buried emotions surge to the surface.",
      timeframe: "Present - Chapter 3",
      type: "chapter",
      characters: ["Lilah Carter", "Lucas Reeves"],
      locations: ["The Town"],
      importance: "critical",
      emotional_weight: 9,
      chapter_reference: "Chapter 3"
    },
    {
      id: "pier-confrontation",
      title: "Return to the Pier",
      description: "They end up at their old spot - the pier where everything began and ended. Raw confrontation of their shared past.",
      timeframe: "Present - Chapter 8",
      type: "chapter",
      characters: ["Lilah Carter", "Lucas Reeves"],
      locations: ["The Pier"],
      importance: "critical",
      emotional_weight: 10,
      chapter_reference: "Chapter 8"
    },
    {
      id: "healing-begins",
      title: "First Steps Toward Healing",
      description: "They begin to address the trauma and its aftermath. Painful but necessary conversations about what happened.",
      timeframe: "Present - Chapter 15",
      type: "healing",
      characters: ["Lilah Carter", "Lucas Reeves"],
      locations: ["The Pier"],
      importance: "critical",
      emotional_weight: 8,
      chapter_reference: "Chapter 15"
    },
    {
      id: "second-chance",
      title: "Rebuilding Trust",
      description: "Slow, careful steps toward rebuilding what was lost. Learning to love each other's damaged parts.",
      timeframe: "Present - Final chapters",
      type: "healing",
      characters: ["Lilah Carter", "Lucas Reeves"],
      locations: ["The Pier", "Carter House"],
      importance: "critical",
      emotional_weight: 9,
      chapter_reference: "Final Arc"
    }
  ];

  const eventTypes = [
    { value: "all", label: "All Events", color: "bg-gray-100" },
    { value: "past", label: "Past Events", color: "bg-blue-100" },
    { value: "chapter", label: "Story Chapters", color: "bg-green-100" },
    { value: "relationship", label: "Relationship", color: "bg-pink-100" },
    { value: "trauma", label: "Trauma", color: "bg-red-100" },
    { value: "healing", label: "Healing", color: "bg-purple-100" }
  ];

  const filteredEvents = selectedFilter === "all" 
    ? timelineEvents 
    : timelineEvents.filter(event => event.type === selectedFilter);

  const getEventIcon = (type: string) => {
    switch (type) {
      case "past": return Clock;
      case "chapter": return BookOpen;
      case "relationship": return Heart;
      case "trauma": return Users;
      case "healing": return Calendar;
      default: return Calendar;
    }
  };

  const getEmotionalColor = (weight: number) => {
    if (weight >= 9) return "bg-red-500";
    if (weight >= 7) return "bg-orange-500";
    if (weight >= 5) return "bg-yellow-500";
    return "bg-green-500";
  };

  return (
    <div className="flex-1 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-charcoal">Interactive Timeline</h2>
            <p className="text-sm text-gray-500">
              Visualize the emotional journey of Lilah and Lucas across time
            </p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-gray-50 border-b border-gray-200 px-6 py-3">
        <div className="flex flex-wrap gap-2">
          {eventTypes.map((type) => (
            <Button
              key={type.value}
              variant={selectedFilter === type.value ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedFilter(type.value)}
              className={selectedFilter === type.value ? "" : type.color}
            >
              {type.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Timeline */}
      <div className="flex-1 p-6">
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gray-300"></div>
          
          <div className="space-y-8">
            {filteredEvents.map((event, index) => {
              const Icon = getEventIcon(event.type);
              const isSelected = selectedEvent === event.id;
              
              return (
                <div key={event.id} className="relative flex items-start">
                  {/* Timeline dot */}
                  <div className={`relative z-10 flex items-center justify-center w-16 h-16 rounded-full border-4 border-white shadow-lg ${
                    event.importance === 'critical' ? 'bg-red-500' :
                    event.importance === 'high' ? 'bg-orange-500' :
                    event.importance === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                  }`}>
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  
                  {/* Event card */}
                  <Card 
                    className={`ml-6 flex-1 cursor-pointer transition-all hover:shadow-lg ${
                      isSelected ? 'ring-2 ring-blue-500' : ''
                    }`}
                    onClick={() => setSelectedEvent(isSelected ? null : event.id)}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg">{event.title}</CardTitle>
                          <div className="flex items-center space-x-2 mt-1">
                            <Badge variant="outline" className="text-xs">
                              {event.timeframe}
                            </Badge>
                            <Badge variant="secondary" className="text-xs">
                              {event.type}
                            </Badge>
                            {event.chapter_reference && (
                              <Badge className="text-xs bg-blue-100 text-blue-800">
                                {event.chapter_reference}
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className={`w-3 h-3 rounded-full ${getEmotionalColor(event.emotional_weight)}`} 
                               title={`Emotional Impact: ${event.emotional_weight}/10`}></div>
                          <ArrowRight className={`h-4 w-4 transition-transform ${
                            isSelected ? 'rotate-90' : ''
                          }`} />
                        </div>
                      </div>
                    </CardHeader>
                    
                    {isSelected && (
                      <CardContent>
                        <p className="text-gray-700 mb-4">{event.description}</p>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {event.characters.length > 0 && (
                            <div>
                              <h4 className="text-sm font-medium mb-2 flex items-center">
                                <Users className="h-4 w-4 mr-1" />
                                Characters Involved:
                              </h4>
                              <div className="flex flex-wrap gap-1">
                                {event.characters.map((char, idx) => (
                                  <Badge key={idx} variant="outline" className="text-xs">
                                    {char}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}
                          
                          {event.locations.length > 0 && (
                            <div>
                              <h4 className="text-sm font-medium mb-2 flex items-center">
                                <MapPin className="h-4 w-4 mr-1" />
                                Locations:
                              </h4>
                              <div className="flex flex-wrap gap-1">
                                {event.locations.map((loc, idx) => (
                                  <Badge key={idx} variant="outline" className="text-xs">
                                    {loc}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                        
                        <div className="mt-4 pt-3 border-t border-gray-200">
                          <div className="flex items-center justify-between text-xs text-gray-500">
                            <span>Emotional Impact: {event.emotional_weight}/10</span>
                            <span>Importance: {event.importance}</span>
                          </div>
                        </div>
                      </CardContent>
                    )}
                  </Card>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}