import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Users, Heart, Zap, Shield, ArrowRight, Eye } from "lucide-react";
import type { Character } from "@shared/schema";

interface RelationshipWebProps {
  projectId: number;
}

interface Relationship {
  from: string;
  to: string;
  type: "love" | "family" | "friendship" | "conflict" | "professional" | "past";
  status: "current" | "past" | "complicated" | "healing" | "broken";
  intensity: number; // 1-10
  description: string;
  trauma_involved: boolean;
  power_dynamic: "equal" | "dominant" | "submissive" | "shifting";
  development_arc: string;
}

export default function RelationshipWeb({ projectId }: RelationshipWebProps) {
  const [selectedRelationship, setSelectedRelationship] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"web" | "list">("web");

  const { data: characters = [] } = useQuery<Character[]>({
    queryKey: [`/api/projects/${projectId}/characters`],
  });

  // Relationship data based on your story
  const relationships: Relationship[] = [
    {
      from: "Lilah Carter",
      to: "Lucas Reeves",
      type: "love",
      status: "complicated",
      intensity: 10,
      description: "Childhood friends turned first loves, torn apart by trauma. Six years of separation couldn't kill what they had, but it changed everything. They're bound by shared wounds and unresolved passion.",
      trauma_involved: true,
      power_dynamic: "shifting",
      development_arc: "Childhood bond → First love → Traumatic separation → Tentative reconnection → Healing together"
    },
    {
      from: "Lilah Carter",
      to: "Mara",
      type: "friendship",
      status: "current",
      intensity: 7,
      description: "Mara is Lilah's anchor to normalcy and her connection to home. She represents the life Lilah could have had if she'd stayed, but also the judgment of the town.",
      trauma_involved: false,
      power_dynamic: "equal",
      development_arc: "Childhood friends → Maintained connection despite distance → Support system"
    },
    {
      from: "Lucas Reeves",
      to: "Mara",
      type: "friendship",
      status: "current",
      intensity: 6,
      description: "Connected through their shared concern for Lilah. Mara serves as a bridge between Lucas and the outside world when he withdraws.",
      trauma_involved: false,
      power_dynamic: "equal",
      development_arc: "Acquaintances → Friends through Lilah → Mutual support"
    },
    {
      from: "Lilah Carter",
      to: "Carter Family",
      type: "family",
      status: "complicated",
      intensity: 8,
      description: "Complex family dynamics marked by expectations, disappointment, and the weight of family reputation. Lilah's leaving affected everyone.",
      trauma_involved: true,
      power_dynamic: "submissive",
      development_arc: "Loving family → Pressure and expectations → Disappointment → Gradual reconciliation"
    },
    {
      from: "Lucas Reeves",
      to: "Reeves Family",
      type: "family",
      status: "past",
      intensity: 5,
      description: "Working-class family with different expectations. Lucas feels the divide between his background and Lilah's, which affects his self-worth.",
      trauma_involved: false,
      power_dynamic: "equal",
      development_arc: "Supportive family → Class consciousness → Independence"
    },
    {
      from: "Lilah Carter",
      to: "The Town",
      type: "professional",
      status: "broken",
      intensity: 6,
      description: "The town remembers everything. Lilah's return means facing the gossip, judgment, and memories she tried to escape.",
      trauma_involved: true,
      power_dynamic: "submissive",
      development_arc: "Beloved daughter → Scandal → Exile → Reluctant return"
    },
    {
      from: "Lucas Reeves",
      to: "The Town",
      type: "professional",
      status: "current",
      intensity: 4,
      description: "Lucas stayed and built a life here, but he's still marked by what happened. People see him as either a victim or someone to be pitied.",
      trauma_involved: true,
      power_dynamic: "equal",
      development_arc: "Local boy → Trauma survivor → Established resident"
    }
  ];

  const getRelationshipIcon = (type: string) => {
    switch (type) {
      case "love": return Heart;
      case "family": return Users;
      case "friendship": return Shield;
      case "conflict": return Zap;
      default: return Users;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "current": return "bg-green-100 text-green-800";
      case "past": return "bg-gray-100 text-gray-800";
      case "complicated": return "bg-yellow-100 text-yellow-800";
      case "healing": return "bg-blue-100 text-blue-800";
      case "broken": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getIntensityColor = (intensity: number) => {
    if (intensity >= 8) return "bg-red-500";
    if (intensity >= 6) return "bg-orange-500";
    if (intensity >= 4) return "bg-yellow-500";
    return "bg-green-500";
  };

  const selectedRel = relationships.find(rel => 
    selectedRelationship === `${rel.from}-${rel.to}`
  );

  return (
    <div className="flex-1 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-charcoal">Relationship Web</h2>
            <p className="text-sm text-gray-500">
              Map the complex emotional connections in your story
            </p>
          </div>
          <div className="flex space-x-2">
            <Button
              variant={viewMode === "web" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("web")}
            >
              Web View
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("list")}
            >
              List View
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 p-6">
        {viewMode === "web" ? (
          /* Web View */
          <div className="h-full relative">
            <div className="grid grid-cols-3 gap-8 h-full">
              {/* Central character nodes */}
              <div className="flex flex-col justify-center space-y-8">
                <Card className="p-4 bg-pink-50 border-pink-200">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-pink-500 rounded-full mx-auto mb-2 flex items-center justify-center">
                      <Users className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="font-semibold">Lilah Carter</h3>
                    <p className="text-xs text-gray-600">Protagonist</p>
                  </div>
                </Card>
              </div>

              <div className="flex flex-col justify-center space-y-4">
                <Card className="p-4 bg-blue-50 border-blue-200">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-blue-500 rounded-full mx-auto mb-2 flex items-center justify-center">
                      <Users className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="font-semibold">Lucas Reeves</h3>
                    <p className="text-xs text-gray-600">Love Interest</p>
                  </div>
                </Card>

                <Card className="p-4 bg-green-50 border-green-200">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-green-500 rounded-full mx-auto mb-2 flex items-center justify-center">
                      <Users className="h-6 w-6 text-white" />
                    </div>
                    <h3 className="font-medium text-sm">Mara</h3>
                    <p className="text-xs text-gray-600">Friend</p>
                  </div>
                </Card>
              </div>

              <div className="flex flex-col justify-center space-y-8">
                <Card className="p-3 bg-gray-50 border-gray-200">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-gray-500 rounded-full mx-auto mb-2 flex items-center justify-center">
                      <Users className="h-6 w-6 text-white" />
                    </div>
                    <h3 className="font-medium text-sm">The Town</h3>
                    <p className="text-xs text-gray-600">Setting</p>
                  </div>
                </Card>
              </div>
            </div>

            {/* Connection lines overlay would go here in a more advanced implementation */}
            <div className="absolute inset-0 pointer-events-none">
              <svg className="w-full h-full">
                {/* SVG lines connecting the nodes would be rendered here */}
              </svg>
            </div>
          </div>
        ) : (
          /* List View */
          <div className="space-y-4">
            {relationships.map((rel, index) => {
              const Icon = getRelationshipIcon(rel.type);
              const relId = `${rel.from}-${rel.to}`;
              const isSelected = selectedRelationship === relId;
              
              return (
                <Card 
                  key={index} 
                  className={`cursor-pointer transition-all hover:shadow-lg ${
                    isSelected ? 'ring-2 ring-blue-500' : ''
                  }`}
                  onClick={() => setSelectedRelationship(isSelected ? null : relId)}
                >
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Icon className="h-5 w-5 text-blue-600" />
                        <div>
                          <CardTitle className="text-lg">
                            {rel.from} → {rel.to}
                          </CardTitle>
                          <div className="flex items-center space-x-2 mt-1">
                            <Badge variant="outline" className="text-xs">
                              {rel.type}
                            </Badge>
                            <Badge className={`text-xs ${getStatusColor(rel.status)}`}>
                              {rel.status}
                            </Badge>
                            {rel.trauma_involved && (
                              <Badge variant="destructive" className="text-xs">
                                Trauma
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className={`w-3 h-3 rounded-full ${getIntensityColor(rel.intensity)}`} 
                             title={`Intensity: ${rel.intensity}/10`}></div>
                        <ArrowRight className={`h-4 w-4 transition-transform ${
                          isSelected ? 'rotate-90' : ''
                        }`} />
                      </div>
                    </div>
                  </CardHeader>
                  
                  {isSelected && (
                    <CardContent>
                      <p className="text-gray-700 mb-4">{rel.description}</p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div>
                          <h4 className="text-sm font-medium mb-1">Power Dynamic</h4>
                          <Badge variant="outline" className="text-xs">
                            {rel.power_dynamic}
                          </Badge>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium mb-1">Emotional Intensity</h4>
                          <div className="flex items-center space-x-2">
                            <div className={`w-4 h-4 rounded-full ${getIntensityColor(rel.intensity)}`}></div>
                            <span className="text-sm">{rel.intensity}/10</span>
                          </div>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium mb-1">Trauma Factor</h4>
                          <Badge className={rel.trauma_involved ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}>
                            {rel.trauma_involved ? "Present" : "None"}
                          </Badge>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium mb-2">Development Arc</h4>
                        <p className="text-sm text-gray-600 italic">{rel.development_arc}</p>
                      </div>
                    </CardContent>
                  )}
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}