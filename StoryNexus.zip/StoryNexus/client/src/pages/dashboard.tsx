import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import ManuscriptEditor from "@/components/manuscript-editor";
import AiChatPanel from "@/components/ai-chat-panel";
import EnhancedAiChat from "@/components/enhanced-ai-chat";
import CharacterDatabase from "@/components/character-database";
import LocationDatabase from "@/components/location-database";
import VisualsGallery from "@/components/visuals-gallery";
import StoryOutline from "@/components/story-outline-fixed";
import ResearchNotes from "@/components/research-notes";
import LoreDatabase from "@/components/lore-database";
import InteractiveTimeline from "@/components/interactive-timeline";
import RelationshipWeb from "@/components/relationship-web";
import ConsistencyChecker from "@/components/consistency-checker";
import WritingPrompts from "@/components/writing-prompts";
import AiDatabaseEditor from "@/components/ai-database-editor";
import OutlineComparison from "@/components/outline-comparison";
import ReferenceModal from "@/components/reference-modal";
import type { Project } from "@shared/schema";

type ViewType = "manuscript" | "characters" | "locations" | "visuals" | "timeline" | "lore" | "ai-chat" | "analysis" | "outline" | "notes" | "relationships" | "consistency" | "prompts" | "ai-editor" | "outline-comparison";

export default function Dashboard() {
  const [currentView, setCurrentView] = useState<ViewType>("manuscript");
  const [selectedChapterId, setSelectedChapterId] = useState<number | null>(null);
  const [isChatOpen, setIsChatOpen] = useState(true);
  const [referenceModal, setReferenceModal] = useState<{
    isOpen: boolean;
    type: string;
    id: number;
  }>({ isOpen: false, type: "", id: 0 });

  const projectId = 1; // Default project

  const { data: project, isLoading: isProjectLoading } = useQuery<Project>({
    queryKey: [`/api/projects/${projectId}`],
  });

  const renderMainContent = () => {
    switch (currentView) {
      case "manuscript":
        return (
          <ManuscriptEditor 
            projectId={projectId}
            selectedChapterId={selectedChapterId}
            onChapterSelect={setSelectedChapterId}
            onReferenceClick={(type, id) => setReferenceModal({ isOpen: true, type, id })}
          />
        );
      case "characters":
        return <CharacterDatabase projectId={projectId} />;
      case "locations":
        return <LocationDatabase projectId={projectId} />;
      case "visuals":
        return <VisualsGallery projectId={projectId} />;
      case "outline":
        return <StoryOutline projectId={projectId} />;
      case "notes":
        return <ResearchNotes projectId={projectId} />;
      case "ai-chat":
        return <EnhancedAiChat projectId={projectId} />;
      case "timeline":
        return <InteractiveTimeline projectId={projectId} />;
      case "lore":
        return <LoreDatabase projectId={projectId} />;
      case "relationships":
        return <RelationshipWeb projectId={projectId} />;
      case "consistency":
        return <ConsistencyChecker projectId={projectId} />;
      case "prompts":
        return <WritingPrompts projectId={projectId} />;
      case "ai-editor":
        return <AiDatabaseEditor projectId={projectId} />;
      case "outline-comparison":
        return <OutlineComparison projectId={projectId} />;
      case "analysis":
        return (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Style Analysis</h2>
              <p className="text-gray-600">Writing analytics and style insights coming soon.</p>
            </div>
          </div>
        );
      default:
        return (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Coming Soon</h2>
              <p className="text-gray-600">This feature is under development.</p>
            </div>
          </div>
        );
    }
  };

  if (isProjectLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your novel workspace...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="h-screen flex overflow-hidden bg-background">
        <Sidebar 
          project={project}
          currentView={currentView}
          onViewChange={(view) => setCurrentView(view as ViewType)}
          onChapterSelect={setSelectedChapterId}
        />
        
        <div className="flex-1 flex min-w-0">
          <div className="flex-1 flex flex-col">
            {renderMainContent()}
          </div>
          
          {isChatOpen && currentView === "manuscript" && (
            <AiChatPanel 
              projectId={projectId}
              onToggle={() => setIsChatOpen(!isChatOpen)}
            />
          )}
        </div>
      </div>

      <ReferenceModal 
        isOpen={referenceModal.isOpen}
        type={referenceModal.type}
        elementId={referenceModal.id}
        onClose={() => setReferenceModal({ isOpen: false, type: "", id: 0 })}
      />
    </>
  );
}
