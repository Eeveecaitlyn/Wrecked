import { Extensions } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';
import { Mark, mergeAttributes } from '@tiptap/core';

// Custom extension for character references
const CharacterReference = Mark.create({
  name: 'characterReference',
  
  addOptions() {
    return {
      HTMLAttributes: {},
    };
  },

  addAttributes() {
    return {
      characterId: {
        default: null,
        parseHTML: element => element.getAttribute('data-character-id'),
        renderHTML: attributes => {
          if (!attributes.characterId) {
            return {};
          }
          return {
            'data-character-id': attributes.characterId,
          };
        },
      },
    };
  },

  parseHTML() {
    return [
      {
        tag: 'span[data-character-id]',
        getAttrs: element => {
          const characterId = (element as HTMLElement).getAttribute('data-character-id');
          return characterId ? { characterId } : false;
        },
      },
    ];
  },

  renderHTML({ HTMLAttributes }) {
    return ['span', mergeAttributes(this.options.HTMLAttributes, HTMLAttributes, {
      class: 'character-reference bg-green-50 text-success px-1 rounded cursor-pointer hover:bg-green-100 transition-colors',
    }), 0];
  },
});

// Custom extension for location references
const LocationReference = Mark.create({
  name: 'locationReference',
  
  addOptions() {
    return {
      HTMLAttributes: {},
    };
  },

  addAttributes() {
    return {
      locationId: {
        default: null,
        parseHTML: element => element.getAttribute('data-location-id'),
        renderHTML: attributes => {
          if (!attributes.locationId) {
            return {};
          }
          return {
            'data-location-id': attributes.locationId,
          };
        },
      },
    };
  },

  parseHTML() {
    return [
      {
        tag: 'span[data-location-id]',
        getAttrs: element => {
          const locationId = (element as HTMLElement).getAttribute('data-location-id');
          return locationId ? { locationId } : false;
        },
      },
    ];
  },

  renderHTML({ HTMLAttributes }) {
    return ['span', mergeAttributes(this.options.HTMLAttributes, HTMLAttributes, {
      class: 'location-reference bg-blue-50 text-primary px-1 rounded cursor-pointer hover:bg-blue-100 transition-colors',
    }), 0];
  },
});

// Custom extension for artifact references
const ArtifactReference = Mark.create({
  name: 'artifactReference',
  
  addOptions() {
    return {
      HTMLAttributes: {},
    };
  },

  addAttributes() {
    return {
      artifactId: {
        default: null,
        parseHTML: element => element.getAttribute('data-artifact-id'),
        renderHTML: attributes => {
          if (!attributes.artifactId) {
            return {};
          }
          return {
            'data-artifact-id': attributes.artifactId,
          };
        },
      },
    };
  },

  parseHTML() {
    return [
      {
        tag: 'span[data-artifact-id]',
        getAttrs: element => {
          const artifactId = (element as HTMLElement).getAttribute('data-artifact-id');
          return artifactId ? { artifactId } : false;
        },
      },
    ];
  },

  renderHTML({ HTMLAttributes }) {
    return ['span', mergeAttributes(this.options.HTMLAttributes, HTMLAttributes, {
      class: 'artifact-reference bg-purple-50 text-secondary px-1 rounded cursor-pointer hover:bg-purple-100 transition-colors',
    }), 0];
  },
});

// Default TipTap configuration for the novel editor
export const createTipTapExtensions = (): Extensions => [
  StarterKit.configure({
    heading: {
      levels: [1, 2, 3],
    },
    paragraph: {
      HTMLAttributes: {
        class: 'mb-4',
      },
    },
    blockquote: {
      HTMLAttributes: {
        class: 'border-l-4 border-primary pl-4 my-4 italic',
      },
    },
  }),
  Placeholder.configure({
    placeholder: ({ node }) => {
      if (node.type.name === 'heading') {
        return 'Chapter title...';
      }
      return 'Start writing your story...';
    },
    includeChildren: true,
  }),
  CharacterReference,
  LocationReference,
  ArtifactReference,
];

// Editor attributes configuration
export const editorAttributes = {
  class: 'prose-writing min-h-96 focus:outline-none max-w-none',
  spellcheck: 'true',
};

// Default editor options
export const defaultEditorOptions = {
  extensions: createTipTapExtensions(),
  editorProps: {
    attributes: editorAttributes,
  },
  parseOptions: {
    preserveWhitespace: 'full',
  },
};

// Utility functions for working with references
export const insertCharacterReference = (editor: any, characterId: number, characterName: string) => {
  if (!editor) return;
  
  editor
    .chain()
    .focus()
    .setMark('characterReference', { characterId })
    .insertContent(characterName)
    .unsetMark('characterReference')
    .insertContent(' ')
    .run();
};

export const insertLocationReference = (editor: any, locationId: number, locationName: string) => {
  if (!editor) return;
  
  editor
    .chain()
    .focus()
    .setMark('locationReference', { locationId })
    .insertContent(locationName)
    .unsetMark('locationReference')
    .insertContent(' ')
    .run();
};

export const insertArtifactReference = (editor: any, artifactId: number, artifactName: string) => {
  if (!editor) return;
  
  editor
    .chain()
    .focus()
    .setMark('artifactReference', { artifactId })
    .insertContent(artifactName)
    .unsetMark('artifactReference')
    .insertContent(' ')
    .run();
};

// Utility to extract references from editor content
export const extractReferences = (content: string) => {
  const parser = new DOMParser();
  const doc = parser.parseFromString(content, 'text/html');
  
  const characterRefs = Array.from(doc.querySelectorAll('[data-character-id]')).map(el => ({
    type: 'character',
    id: parseInt(el.getAttribute('data-character-id') || '0'),
    name: el.textContent || '',
  }));
  
  const locationRefs = Array.from(doc.querySelectorAll('[data-location-id]')).map(el => ({
    type: 'location',
    id: parseInt(el.getAttribute('data-location-id') || '0'),
    name: el.textContent || '',
  }));
  
  const artifactRefs = Array.from(doc.querySelectorAll('[data-artifact-id]')).map(el => ({
    type: 'artifact',
    id: parseInt(el.getAttribute('data-artifact-id') || '0'),
    name: el.textContent || '',
  }));
  
  return [...characterRefs, ...locationRefs, ...artifactRefs];
};

// Word count utility
export const getWordCount = (content: string): number => {
  const text = content.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
  return text ? text.split(' ').length : 0;
};

// Character count utility
export const getCharacterCount = (content: string): number => {
  const text = content.replace(/<[^>]*>/g, '');
  return text.length;
};

// Reading time estimation (average 200 words per minute)
export const getReadingTime = (content: string): number => {
  const wordCount = getWordCount(content);
  return Math.ceil(wordCount / 200);
};

export default {
  createTipTapExtensions,
  editorAttributes,
  defaultEditorOptions,
  insertCharacterReference,
  insertLocationReference,
  insertArtifactReference,
  extractReferences,
  getWordCount,
  getCharacterCount,
  getReadingTime,
};
