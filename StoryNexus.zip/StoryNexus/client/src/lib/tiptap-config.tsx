import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';
import { Bold, Italic, Link, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { Character, Location } from '@shared/schema';

interface TipTapEditorProps {
  content: string;
  onUpdate: (content: string) => void;
  characters: Character[];
  locations: Location[];
  onReferenceClick: (type: string, id: number) => void;
}

export default function TipTapEditor({ 
  content, 
  onUpdate, 
  characters, 
  locations, 
  onReferenceClick 
}: TipTapEditorProps) {
  const editor = useEditor({
    extensions: [
      StarterKit,
      Placeholder.configure({
        placeholder: 'Start writing your story...',
      }),
    ],
    content,
    onUpdate: ({ editor }) => {
      onUpdate(editor.getHTML());
    },
    editorProps: {
      attributes: {
        class: 'prose-writing min-h-96 focus:outline-none',
      },
    },
  });

  const insertCharacterReference = (character: Character) => {
    if (!editor) return;
    
    editor
      .chain()
      .focus()
      .insertContent(
        `<span class="character-reference" data-character-id="${character.id}">${character.name}</span> `
      )
      .run();
  };

  const insertLocationReference = (location: Location) => {
    if (!editor) return;
    
    editor
      .chain()
      .focus()
      .insertContent(
        `<span class="location-reference" data-location-id="${location.id}">${location.name}</span> `
      )
      .run();
  };

  if (!editor) return null;

  return (
    <div className="border border-gray-200 rounded-lg focus-within:border-primary focus-within:ring-1 focus-within:ring-primary">
      {/* Editor Toolbar */}
      <div className="flex items-center justify-between border-b border-gray-200 p-3">
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => editor.chain().focus().toggleBold().run()}
            className={`editor-toolbar-button ${editor.isActive('bold') ? 'active' : ''}`}
          >
            <Bold className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => editor.chain().focus().toggleItalic().run()}
            className={`editor-toolbar-button ${editor.isActive('italic') ? 'active' : ''}`}
          >
            <Italic className="h-4 w-4" />
          </Button>
          <div className="w-px h-6 bg-gray-200"></div>
          <Button
            variant="ghost"
            size="sm"
            className="editor-toolbar-button"
          >
            <Link className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="editor-toolbar-button"
          >
            <MessageSquare className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex items-center space-x-2">
          {/* Quick Insert Dropdowns */}
          <select 
            className="text-sm border border-gray-200 rounded px-2 py-1"
            onChange={(e) => {
              if (e.target.value) {
                const character = characters.find(c => c.id === parseInt(e.target.value));
                if (character) insertCharacterReference(character);
                e.target.value = '';
              }
            }}
          >
            <option value="">Insert Character</option>
            {characters.map(character => (
              <option key={character.id} value={character.id}>{character.name}</option>
            ))}
          </select>

          <select 
            className="text-sm border border-gray-200 rounded px-2 py-1"
            onChange={(e) => {
              if (e.target.value) {
                const location = locations.find(l => l.id === parseInt(e.target.value));
                if (location) insertLocationReference(location);
                e.target.value = '';
              }
            }}
          >
            <option value="">Insert Location</option>
            {locations.map(location => (
              <option key={location.id} value={location.id}>{location.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Editor Content */}
      <div 
        className="p-6"
        onClick={(e) => {
          const target = e.target as HTMLElement;
          if (target.classList.contains('character-reference')) {
            const characterId = target.getAttribute('data-character-id');
            if (characterId) {
              onReferenceClick('character', parseInt(characterId));
            }
          } else if (target.classList.contains('location-reference')) {
            const locationId = target.getAttribute('data-location-id');
            if (locationId) {
              onReferenceClick('location', parseInt(locationId));
            }
          }
        }}
      >
        <EditorContent editor={editor} />
      </div>
    </div>
  );
}
