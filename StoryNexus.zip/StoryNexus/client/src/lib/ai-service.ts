export interface AiSuggestion {
  type: "improvement" | "completion" | "character" | "plot";
  content: string;
  context?: string;
}

export interface AiModel {
  id: string;
  name: string;
  description: string;
  provider: "openrouter" | "huggingface";
}

export const AI_MODELS: AiModel[] = [
  {
    id: "openai/gpt-4o-mini",
    name: "GPT-4o Mini",
    description: "Fast and creative writing assistance",
    provider: "openrouter",
  },
  {
    id: "anthropic/claude-3-haiku",
    name: "Claude-3 Haiku",
    description: "Quick and insightful feedback",
    provider: "openrouter",
  },
  {
    id: "anthropic/claude-3-sonnet",
    name: "Claude-3 Sonnet",
    description: "Balanced performance and capability",
    provider: "openrouter",
  },
  {
    id: "meta-llama/llama-3.1-8b-instruct",
    name: "Llama-3.1 8B",
    description: "Fast open-source model",
    provider: "openrouter",
  },
  {
    id: "meta-llama/llama-3.1-70b-instruct",
    name: "Llama-3.1 70B",
    description: "Advanced open-source model",
    provider: "openrouter",
  },
  {
    id: "meta-llama/llama-3.2-3b-instruct",
    name: "Llama-3.2 3B",
    description: "Efficient latest model",
    provider: "openrouter",
  },
  {
    id: "mistralai/mistral-7b-instruct",
    name: "Mistral-7B",
    description: "Efficient European model",
    provider: "openrouter",
  },
  {
    id: "mistralai/mixtral-8x7b-instruct",
    name: "Mixtral 8x7B",
    description: "Powerful mixture-of-experts",
    provider: "openrouter",
  },
  {
    id: "google/gemini-flash-1.5",
    name: "Gemini Flash",
    description: "Google's fast multimodal model",
    provider: "openrouter",
  },
  {
    id: "qwen/qwen-2-7b-instruct",
    name: "Qwen-2 7B",
    description: "Alibaba's advanced model",
    provider: "openrouter",
  },
  {
    id: "microsoft/wizardlm-2-8x22b",
    name: "WizardLM-2",
    description: "Microsoft's reasoning model",
    provider: "openrouter",
  },
  {
    id: "nvidia/nemotron-4-340b-instruct",
    name: "Nemotron-4 340B",
    description: "NVIDIA's largest model",
    provider: "openrouter",
  },
];

class AiService {
  private baseUrl = "/api";

  async sendChatMessage(
    projectId: number,
    content: string,
    model: string = "openai/gpt-3.5-turbo",
    context: Record<string, any> = {}
  ) {
    const response = await fetch(`${this.baseUrl}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({
        projectId,
        content,
        model,
        context,
      }),
    });

    if (!response.ok) {
      throw new Error(`Chat API error: ${response.status}`);
    }

    return response.json();
  }

  async getSuggestions(
    text: string,
    context: Record<string, any> = {},
    model: string = "openai/gpt-3.5-turbo"
  ): Promise<AiSuggestion[]> {
    const response = await fetch(`${this.baseUrl}/ai/suggestions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ text, context, model }),
    });

    if (!response.ok) {
      throw new Error(`Suggestions API error: ${response.status}`);
    }

    const data = await response.json();
    return this.parseSuggestions(data.suggestions);
  }

  async getAutoComplete(
    text: string,
    model: string = "openai/gpt-3.5-turbo"
  ): Promise<string> {
    const response = await fetch(`${this.baseUrl}/ai/autocomplete`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ text, model }),
    });

    if (!response.ok) {
      throw new Error(`Autocomplete API error: ${response.status}`);
    }

    const data = await response.json();
    return data.completion;
  }

  async analyzeSentiment(text: string) {
    const response = await fetch(`${this.baseUrl}/analyze/sentiment`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ text }),
    });

    if (!response.ok) {
      throw new Error(`Sentiment analysis API error: ${response.status}`);
    }

    return response.json();
  }

  private parseSuggestions(rawSuggestions: string): AiSuggestion[] {
    // Parse the AI response into structured suggestions
    const lines = rawSuggestions.split('\n').filter(line => line.trim());
    const suggestions: AiSuggestion[] = [];

    lines.forEach(line => {
      if (line.startsWith('•') || line.startsWith('-') || line.match(/^\d+\./)) {
        suggestions.push({
          type: "improvement",
          content: line.replace(/^[•\-\d.]\s*/, '').trim(),
        });
      }
    });

    return suggestions.length > 0 ? suggestions : [{
      type: "improvement",
      content: rawSuggestions,
    }];
  }

  getModelById(modelId: string): AiModel | undefined {
    return AI_MODELS.find(model => model.id === modelId);
  }

  getModelsByProvider(provider: "openrouter" | "huggingface"): AiModel[] {
    return AI_MODELS.filter(model => model.provider === provider);
  }
}

export const aiService = new AiService();
