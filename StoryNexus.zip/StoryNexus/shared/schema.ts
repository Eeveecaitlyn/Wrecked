import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  wordCount: integer("word_count").default(0),
  chapterCount: integer("chapter_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const chapters = pgTable("chapters", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  title: text("title").notNull(),
  content: text("content").default(""),
  wordCount: integer("word_count").default(0),
  orderIndex: integer("order_index").notNull(),
  status: text("status").default("draft"), // draft, complete, review
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const characters = pgTable("characters", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  age: text("age"),
  occupation: text("occupation"),
  relationships: jsonb("relationships").default([]),
  appearances: jsonb("appearances").default([]), // chapter references
  notes: text("notes"),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const locations = pgTable("locations", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  type: text("type"), // city, building, region, etc.
  connections: jsonb("connections").default([]), // connected locations
  appearances: jsonb("appearances").default([]), // chapter references
  notes: text("notes"),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  role: text("role").notNull(), // user, assistant
  content: text("content").notNull(),
  context: jsonb("context").default({}), // referenced elements
  modelUsed: text("model_used"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const references = pgTable("references", {
  id: serial("id").primaryKey(),
  chapterId: integer("chapter_id").notNull(),
  elementType: text("element_type").notNull(), // character, location, artifact
  elementId: integer("element_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const visuals = pgTable("visuals", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  imageUrl: text("image_url"),
  tags: jsonb("tags").default([]),
  connections: jsonb("connections").default({}),
  visualType: text("visual_type"), // character_ref, location_ref, mood_board, scene_inspiration
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const symbols = pgTable("symbols", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  meaning: text("meaning"),
  category: text("category"), // object, color, number, nature, action, etc.
  occurrences: jsonb("occurrences").default([]), // chapter/scene references with context
  connections: jsonb("connections").default([]), // related symbols/motifs
  significance: text("significance"), // major, minor, recurring
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const motifs = pgTable("motifs", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  pattern: text("pattern"), // how it repeats/manifests
  function: text("function"), // thematic purpose
  examples: jsonb("examples").default([]), // specific instances with context
  evolution: text("evolution"), // how it changes throughout story
  connections: jsonb("connections").default([]), // related themes/symbols
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const themes = pgTable("themes", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category"), // love, trauma, growth, identity, etc.
  development: text("development"), // how it's explored
  manifestations: jsonb("manifestations").default([]), // how it appears in story
  conflicts: jsonb("conflicts").default([]), // opposing themes
  resolution: text("resolution"), // how it's resolved/concluded
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const emotionalPatterns = pgTable("emotional_patterns", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  trigger: text("trigger"), // what causes this pattern
  response: text("response"), // how characters react
  characters: jsonb("characters").default([]), // which characters exhibit this
  progression: text("progression"), // how it changes over time
  context: jsonb("context").default([]), // when/where it appears
  significance: text("significance"), // why it matters to the story
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const lore = pgTable("lore", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category"), // backstory, worldbuilding, history, rules, culture, etc.
  importance: text("importance"), // critical, relevant, background
  connections: jsonb("connections").default([]), // related lore elements
  sources: jsonb("sources").default([]), // where it's mentioned/revealed
  timeline: text("timeline"), // when it occurs relative to main story
  impact: text("impact"), // how it affects the current story
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertChapterSchema = createInsertSchema(chapters).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCharacterSchema = createInsertSchema(characters).omit({
  id: true,
  createdAt: true,
});

export const insertLocationSchema = createInsertSchema(locations).omit({
  id: true,
  createdAt: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
}).extend({
  context: z.any().optional(),
});

export const insertReferenceSchema = createInsertSchema(references).omit({
  id: true,
  createdAt: true,
});

export const insertVisualSchema = createInsertSchema(visuals).omit({
  id: true,
  createdAt: true,
}).extend({
  tags: z.any().optional(),
  connections: z.any().optional(),
});

// Types
export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;

export type Chapter = typeof chapters.$inferSelect;
export type InsertChapter = z.infer<typeof insertChapterSchema>;

export type Character = typeof characters.$inferSelect;
export type InsertCharacter = z.infer<typeof insertCharacterSchema>;

export type Location = typeof locations.$inferSelect;
export type InsertLocation = z.infer<typeof insertLocationSchema>;

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;

export type Reference = typeof references.$inferSelect;
export type InsertReference = z.infer<typeof insertReferenceSchema>;

export type Visual = typeof visuals.$inferSelect;
export type InsertVisual = z.infer<typeof insertVisualSchema>;

export const insertSymbolSchema = createInsertSchema(symbols).omit({
  id: true,
  createdAt: true,
}).extend({
  occurrences: z.any().optional(),
  connections: z.any().optional(),
});

export const insertMotifSchema = createInsertSchema(motifs).omit({
  id: true,
  createdAt: true,
}).extend({
  examples: z.any().optional(),
  connections: z.any().optional(),
});

export const insertThemeSchema = createInsertSchema(themes).omit({
  id: true,
  createdAt: true,
}).extend({
  manifestations: z.any().optional(),
  conflicts: z.any().optional(),
});

export const insertEmotionalPatternSchema = createInsertSchema(emotionalPatterns).omit({
  id: true,
  createdAt: true,
}).extend({
  characters: z.any().optional(),
  context: z.any().optional(),
});

export const insertLoreSchema = createInsertSchema(lore).omit({
  id: true,
  createdAt: true,
}).extend({
  connections: z.any().optional(),
  sources: z.any().optional(),
});

export type Symbol = typeof symbols.$inferSelect;
export type InsertSymbol = z.infer<typeof insertSymbolSchema>;

export type Motif = typeof motifs.$inferSelect;
export type InsertMotif = z.infer<typeof insertMotifSchema>;

export type Theme = typeof themes.$inferSelect;
export type InsertTheme = z.infer<typeof insertThemeSchema>;

export type EmotionalPattern = typeof emotionalPatterns.$inferSelect;
export type InsertEmotionalPattern = z.infer<typeof insertEmotionalPatternSchema>;

export type Lore = typeof lore.$inferSelect;
export type InsertLore = z.infer<typeof insertLoreSchema>;
